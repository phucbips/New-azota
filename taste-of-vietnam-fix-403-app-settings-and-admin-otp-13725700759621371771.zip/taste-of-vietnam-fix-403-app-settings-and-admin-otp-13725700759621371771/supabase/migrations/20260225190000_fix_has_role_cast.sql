-- Fix has_role function to handle text to enum casting properly

CREATE OR REPLACE FUNCTION public.has_role(user_id uuid, role_name text)
RETURNS boolean AS $$
DECLARE
  retval boolean;
BEGIN
  -- Check if the user has the specified role in user_roles table
  -- Cast role_name text to app_role enum for comparison
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles ur
    WHERE ur.user_id = has_role.user_id AND ur.role = has_role.role_name::public.app_role
  ) INTO retval;
  RETURN retval;
EXCEPTION
  -- Handle invalid enum values gracefully
  WHEN invalid_text_representation THEN
    RETURN false;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Grant execute permission on the function to public (anon/authenticated)
GRANT EXECUTE ON FUNCTION public.has_role(uuid, text) TO public;
