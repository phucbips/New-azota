import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import nodemailer from "npm:nodemailer@6.9.10";
import { getRequiredEnv, corsHeaders } from "../_shared/utils.ts";

function generateCode(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

interface EmailTemplateConfig {
  subject: string;
  title: string;
  description: string;
  header_color: string;
}

// --- GIAO DIỆN EMAIL CŨ CỦA BẠN (GIỮ NGUYÊN) ---
function buildEmailHtml(code: string, config: EmailTemplateConfig): string {
  const headerColor = config.header_color || "#2d5a27";
  return `
<!DOCTYPE html>
<html lang="vi">
<head><meta charset="UTF-8"></head>
<body style="margin: 0; padding: 0; background-color: #f4f1eb; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;">
  <div style="max-width: 480px; margin: 40px auto; background: #fffdf8; border-radius: 20px; overflow: hidden; box-shadow: 0 4px 24px rgba(0,0,0,0.08);">
    <div style="background: linear-gradient(135deg, ${headerColor} 0%, ${headerColor}cc 100%); padding: 32px 24px; text-align: center;">
      <div style="font-size: 36px; margin-bottom: 8px;">🍪</div>
      <h1 style="color: #fff; font-size: 20px; margin: 0; font-weight: 700;">Nova Cookie</h1>
      <p style="color: rgba(255,255,255,0.8); font-size: 12px; margin: 4px 0 0 0;">Bánh quy thủ công tự nhiên</p>
    </div>
    <div style="padding: 32px 28px;">
      <h2 style="color: ${headerColor}; font-size: 18px; margin: 0 0 8px 0; font-weight: 700;">${config.title}</h2>
      <p style="color: #6b5e4f; font-size: 14px; line-height: 1.6; margin: 0 0 24px 0;">${config.description}</p>
      <div style="background: linear-gradient(135deg, #f0f7ee 0%, #e8f0e4 100%); border: 2px dashed ${headerColor}; border-radius: 16px; padding: 24px; text-align: center; margin-bottom: 24px;">
        <p style="color: #6b5e4f; font-size: 12px; margin: 0 0 8px 0; text-transform: uppercase; letter-spacing: 2px; font-weight: 600;">Mã xác thực</p>
        <div style="font-size: 36px; font-weight: 800; letter-spacing: 8px; color: ${headerColor}; font-family: 'Courier New', monospace;">${code}</div>
      </div>
      <div style="background: #fff8f0; border-left: 3px solid #e8a84c; padding: 12px 16px; border-radius: 0 8px 8px 0; margin-bottom: 24px;">
        <p style="color: #8b6914; font-size: 13px; margin: 0; font-weight: 500;">⏱ Mã có hiệu lực trong <strong>5 phút</strong></p>
      </div>
      <p style="color: #999; font-size: 12px; line-height: 1.5; margin: 0;">Nếu bạn không yêu cầu mã này, vui lòng bỏ qua email này. Không chia sẻ mã với bất kỳ ai.</p>
    </div>
    <div style="background: #f9f6f0; padding: 16px 28px; text-align: center; border-top: 1px solid #e8e0d4;">
      <p style="color: #b0a08a; font-size: 11px; margin: 0;">© Nova Cookie · Bánh quy thủ công tự nhiên 🌿</p>
    </div>
  </div>
</body>
</html>`;
}

const DEFAULT_TEMPLATES: Record<string, EmailTemplateConfig> = {
  signup_verify: {
    subject: "✉️ Xác thực email đăng ký - Nova Cookie",
    title: "Xác thực email đăng ký",
    description: "Vui lòng nhập mã bên dưới để hoàn tất đăng ký tài khoản Nova Cookie.",
    header_color: "#2d5a27",
  },
  password_reset: {
    subject: "🔑 Mã đặt lại mật khẩu - Nova Cookie",
    title: "Đặt lại mật khẩu",
    description: "Vui lòng nhập mã bên dưới để đặt lại mật khẩu của bạn.",
    header_color: "#2d5a27",
  },
  admin_login: {
    subject: "🔐 Mã xác thực đăng nhập Admin - Nova Cookie",
    title: "Xác thực đăng nhập Admin",
    description: "Vui lòng nhập mã bên dưới để hoàn tất đăng nhập vào trang quản trị.",
    header_color: "#2d5a27",
  },
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { email, type } = await req.json();
    if (!email || !type) throw new Error("Email và type là bắt buộc");

    // 1. Cấu hình Transporter (Nodemailer) với SMTP Gmail
    const SMTP_HOST = getRequiredEnv("SMTP_HOSTNAME");
    const SMTP_PORT = parseInt(getRequiredEnv("SMTP_PORT"));
    const SMTP_USER = getRequiredEnv("SMTP_USERNAME");
    const SMTP_PASS = getRequiredEnv("SMTP_PASSWORD");

    const transporter = nodemailer.createTransport({
      host: SMTP_HOST,
      port: SMTP_PORT,
      secure: SMTP_PORT === 465, // True for 465, false for 587
      auth: {
        user: SMTP_USER,
        pass: SMTP_PASS,
      },
    });

    // 2. Kết nối Database
    const supabase = createClient(
      getRequiredEnv("SUPABASE_URL"),
      getRequiredEnv("SUPABASE_SERVICE_ROLE_KEY")
    );

    // 3. Tạo mã & Lưu DB
    const code = generateCode();
    const { error: insertError } = await supabase.from("verification_codes").insert({
      email, code, type,
      expires_at: new Date(Date.now() + 5 * 60 * 1000).toISOString(),
    });

    if (insertError) throw new Error("Lỗi lưu mã: " + insertError.message);

    // 4. Gửi Email (Hoàn toàn qua Gmail SMTP)
    const templateConfig = DEFAULT_TEMPLATES[type] || DEFAULT_TEMPLATES.password_reset;
    const html = buildEmailHtml(code, templateConfig);

    await transporter.sendMail({
      from: `"Nova Cookie" <${SMTP_USER}>`,
      to: email,
      subject: templateConfig.subject,
      html: html,
    });

    console.log(`✅ Email sent to ${email} via Gmail SMTP`);

    return new Response(JSON.stringify({ success: true }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });

  } catch (error: any) {
    console.error("Error:", error.message);
    return new Response(JSON.stringify({ success: false, error: error.message }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});
