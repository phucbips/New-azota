import { useState } from "react";
import { toast } from "sonner";

export interface GeoCoords {
  lat: number;
  lng: number;
}

export const useGeolocation = (onAddress: (address: string) => void) => {
  const [loading, setLoading] = useState(false);
  const [searchLoading, setSearchLoading] = useState(false);
  const [coords, setCoords] = useState<GeoCoords | null>(null);

  const getLocation = () => {
    if (!navigator.geolocation) {
      toast.error("Trình duyệt của bạn không hỗ trợ định vị. Vui lòng nhập địa chỉ thủ công.");
      return;
    }

    setLoading(true);
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        try {
          const { latitude, longitude } = pos.coords;
          setCoords({ lat: latitude, lng: longitude });
          const res = await fetch(
            `https://nominatim.openstreetmap.org/reverse?lat=${latitude}&lon=${longitude}&format=json&accept-language=vi`,
            { headers: { "User-Agent": "NovaCookie/1.0" } }
          );
          if (!res.ok) throw new Error("Nominatim error");
          const data = await res.json();
          if (data.display_name) {
            onAddress(data.display_name);
            toast.success("Đã lấy vị trí hiện tại!");
          } else {
            toast.error("Không thể xác định địa chỉ. Vui lòng nhập thủ công.");
          }
        } catch {
          toast.error("Không thể chuyển đổi tọa độ thành địa chỉ. Vui lòng nhập thủ công.");
        } finally {
          setLoading(false);
        }
      },
      (err) => {
        setLoading(false);
        switch (err.code) {
          case err.PERMISSION_DENIED:
            toast.error("Bạn đã từ chối quyền truy cập vị trí. Vui lòng bật lại trong cài đặt trình duyệt.");
            break;
          case err.POSITION_UNAVAILABLE:
            toast.error("Không thể xác định vị trí hiện tại. Vui lòng nhập địa chỉ thủ công.");
            break;
          case err.TIMEOUT:
            toast.error("Quá thời gian lấy vị trí. Vui lòng thử lại.");
            break;
          default:
            toast.error("Lỗi không xác định khi lấy vị trí.");
        }
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 60000 }
    );
  };

  // Try searching Nominatim with progressively simpler queries
  const searchNominatim = async (query: string): Promise<any[] | null> => {
    const res = await fetch(
      `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(query)}&format=json&limit=3&accept-language=vi&countrycodes=vn`,
      { headers: { "User-Agent": "NovaCookie/1.0" } }
    );
    if (!res.ok) return null;
    return await res.json();
  };

  // Geocode an address string to coordinates and show on map
  const geocodeAddress = async (address: string) => {
    if (!address || address.length < 5) {
      toast.error("Vui lòng nhập ít nhất 5 ký tự để tìm kiếm.");
      return;
    }
    setSearchLoading(true);
    try {
      // Try full address first
      let data = await searchNominatim(address);
      
      // If not found, try progressively shorter versions
      if (!data?.length) {
        // Remove numbers and try again
        const withoutNumbers = address.replace(/\d+/g, "").replace(/\s+/g, " ").trim();
        if (withoutNumbers.length >= 5) {
          data = await searchNominatim(withoutNumbers);
        }
      }
      
      if (!data?.length) {
        // Try last 2-3 parts (city/province level)
        const parts = address.split(/[,\s]+/).filter(p => p.length > 1);
        if (parts.length > 2) {
          const shortQuery = parts.slice(-3).join(" ");
          data = await searchNominatim(shortQuery);
        }
      }

      if (data?.[0]) {
        const newCoords = { lat: parseFloat(data[0].lat), lng: parseFloat(data[0].lon) };
        setCoords(newCoords);
        if (data[0].display_name) {
          onAddress(data[0].display_name);
        }
        toast.success("Đã tìm thấy vị trí trên bản đồ! Nhấn vào bản đồ để chọn chính xác hơn.");
      } else {
        toast.error("Không tìm thấy địa chỉ. Hãy thử nhập tên đường, phường/xã, quận/huyện.");
      }
    } catch {
      toast.error("Lỗi khi tìm kiếm địa chỉ. Vui lòng thử lại.");
    } finally {
      setSearchLoading(false);
    }
  };

  // Reverse geocode from coords (when user clicks on map)
  const reverseGeocode = async (newCoords: GeoCoords) => {
    setCoords(newCoords);
    try {
      const res = await fetch(
        `https://nominatim.openstreetmap.org/reverse?lat=${newCoords.lat}&lon=${newCoords.lng}&format=json&accept-language=vi`,
        { headers: { "User-Agent": "NovaCookie/1.0" } }
      );
      if (!res.ok) return;
      const data = await res.json();
      if (data.display_name) {
        onAddress(data.display_name);
        toast.success("Đã cập nhật địa chỉ từ bản đồ!");
      }
    } catch {
      // silently fail
    }
  };

  const clearCoords = () => setCoords(null);

  return { getLocation, loading, searchLoading, coords, geocodeAddress, reverseGeocode, clearCoords };
};
