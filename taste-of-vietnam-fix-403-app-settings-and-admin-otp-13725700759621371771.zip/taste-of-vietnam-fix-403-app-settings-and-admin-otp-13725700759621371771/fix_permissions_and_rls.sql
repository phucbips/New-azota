-- FIX SCRIPT: RUN EACH BLOCK SEPARATELY OR ALL AT ONCE (ENSURE SEMICOLONS)

-- 1. Ensure 'admin' role (Idempotent: Uses INSERT ... ON CONFLICT)
-- Note: Requires `user_roles` to have a unique constraint on (user_id, role)
INSERT INTO public.user_roles (user_id, role)
SELECT id, 'admin'::app_role
FROM auth.users
WHERE email = 'thanhphucn4u@gmail.com'
ON CONFLICT (user_id, role) DO UPDATE SET role = 'admin'::app_role;

-- 2. Ensure Helper function exists
CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role app_role)
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 3. Enable RLS on all relevant tables (Idempotent)
DO $$
BEGIN
  ALTER TABLE IF EXISTS public.financial_transactions ENABLE ROW LEVEL SECURITY;
  ALTER TABLE IF EXISTS public.order_surcharges ENABLE ROW LEVEL SECURITY;
  ALTER TABLE IF EXISTS public.order_items ENABLE ROW LEVEL SECURITY;
  ALTER TABLE IF EXISTS public.user_vouchers ENABLE ROW LEVEL SECURITY;
  ALTER TABLE IF EXISTS public.voucher_templates ENABLE ROW LEVEL SECURITY;
  ALTER TABLE IF EXISTS public.feedback ENABLE ROW LEVEL SECURITY;
  ALTER TABLE IF EXISTS public.profiles ENABLE ROW LEVEL SECURITY;
  ALTER TABLE IF EXISTS public.app_settings ENABLE ROW LEVEL SECURITY;
  ALTER TABLE IF EXISTS public.page_views ENABLE ROW LEVEL SECURITY;
  ALTER TABLE IF EXISTS public.votes ENABLE ROW LEVEL SECURITY;
  ALTER TABLE IF EXISTS public.verification_codes ENABLE ROW LEVEL SECURITY;
  ALTER TABLE IF EXISTS public.orders ENABLE ROW LEVEL SECURITY;
  ALTER TABLE IF EXISTS public.monthly_menu ENABLE ROW LEVEL SECURITY;
END $$;

-- 4. Drop and Re-create Policies (Grouped by Table)

-- --- Financial Transactions ---
DROP POLICY IF EXISTS "Admins can manage financial transactions" ON public.financial_transactions;
CREATE POLICY "Admins can manage financial transactions" ON public.financial_transactions FOR ALL USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- --- Order Surcharges ---
DROP POLICY IF EXISTS "Admins can manage surcharges" ON public.order_surcharges;
CREATE POLICY "Admins can manage surcharges" ON public.order_surcharges FOR ALL USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Public can view active surcharges" ON public.order_surcharges;
CREATE POLICY "Public can view active surcharges" ON public.order_surcharges FOR SELECT USING (true);

-- --- Order Items ---
DROP POLICY IF EXISTS "Admins can view all order items" ON public.order_items;
CREATE POLICY "Admins can view all order items" ON public.order_items FOR SELECT USING (public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Users can view their own order items" ON public.order_items;
CREATE POLICY "Users can view their own order items" ON public.order_items FOR SELECT USING (EXISTS (SELECT 1 FROM public.orders WHERE orders.id = order_items.order_id AND orders.user_id = auth.uid()));

-- --- Voucher Templates ---
DROP POLICY IF EXISTS "Admins can manage voucher templates" ON public.voucher_templates;
CREATE POLICY "Admins can manage voucher templates" ON public.voucher_templates FOR ALL USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Public can view active voucher templates" ON public.voucher_templates;
CREATE POLICY "Public can view active voucher templates" ON public.voucher_templates FOR SELECT USING (is_active = true);

-- --- User Vouchers ---
DROP POLICY IF EXISTS "Admins can manage all user vouchers" ON public.user_vouchers;
CREATE POLICY "Admins can manage all user vouchers" ON public.user_vouchers FOR ALL USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Users can view their own vouchers" ON public.user_vouchers;
CREATE POLICY "Users can view their own vouchers" ON public.user_vouchers FOR SELECT USING (user_id = auth.uid());

DROP POLICY IF EXISTS "Users can insert their own vouchers (claiming)" ON public.user_vouchers;
CREATE POLICY "Users can insert their own vouchers (claiming)" ON public.user_vouchers FOR INSERT WITH CHECK (user_id = auth.uid());

-- --- Feedback ---
DROP POLICY IF EXISTS "Admins can manage feedback" ON public.feedback;
CREATE POLICY "Admins can manage feedback" ON public.feedback FOR ALL USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Users can insert feedback" ON public.feedback;
CREATE POLICY "Users can insert feedback" ON public.feedback FOR INSERT WITH CHECK (true);

DROP POLICY IF EXISTS "Public can view feedback" ON public.feedback;
CREATE POLICY "Public can view feedback" ON public.feedback FOR SELECT USING (true);

-- --- Profiles ---
DROP POLICY IF EXISTS "Users can view their own profile" ON public.profiles;
CREATE POLICY "Users can view their own profile" ON public.profiles FOR SELECT USING (user_id = auth.uid());

DROP POLICY IF EXISTS "Users can update their own profile" ON public.profiles;
CREATE POLICY "Users can update their own profile" ON public.profiles FOR UPDATE USING (user_id = auth.uid());

DROP POLICY IF EXISTS "Admins can view all profiles" ON public.profiles;
CREATE POLICY "Admins can view all profiles" ON public.profiles FOR SELECT USING (public.has_role(auth.uid(), 'admin'));

-- --- App Settings ---
DROP POLICY IF EXISTS "Admins can manage app settings" ON public.app_settings;
CREATE POLICY "Admins can manage app settings" ON public.app_settings FOR ALL USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Public can view public settings" ON public.app_settings;
CREATE POLICY "Public can view public settings" ON public.app_settings FOR SELECT USING (true);

-- --- Page Views ---
DROP POLICY IF EXISTS "Admins can view page views" ON public.page_views;
CREATE POLICY "Admins can view page views" ON public.page_views FOR SELECT USING (public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Public can insert page views" ON public.page_views;
CREATE POLICY "Public can insert page views" ON public.page_views FOR INSERT WITH CHECK (true);

-- --- Votes ---
DROP POLICY IF EXISTS "Public can view votes" ON public.votes;
CREATE POLICY "Public can view votes" ON public.votes FOR SELECT USING (true);

DROP POLICY IF EXISTS "Public can insert votes" ON public.votes;
CREATE POLICY "Public can insert votes" ON public.votes FOR INSERT WITH CHECK (true);

-- --- Orders ---
DROP POLICY IF EXISTS "Admins can manage all orders" ON public.orders;
CREATE POLICY "Admins can manage all orders" ON public.orders FOR ALL USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Users can view their own orders" ON public.orders;
CREATE POLICY "Users can view their own orders" ON public.orders FOR SELECT USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can create orders" ON public.orders;
CREATE POLICY "Users can create orders" ON public.orders FOR INSERT WITH CHECK (auth.uid() = user_id OR user_id IS NULL);

-- --- Monthly Menu ---
DROP POLICY IF EXISTS "Admins can manage menu" ON public.monthly_menu;
CREATE POLICY "Admins can manage menu" ON public.monthly_menu FOR ALL USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Public can view active menu" ON public.monthly_menu;
CREATE POLICY "Public can view active menu" ON public.monthly_menu FOR SELECT USING (is_active = true);
