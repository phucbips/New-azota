
CREATE OR REPLACE FUNCTION get_top_cookies(
  p_limit int DEFAULT 3,
  p_month_year text DEFAULT NULL
)
RETURNS TABLE(cookie_name text, total_sold bigint, avg_rating numeric)
AS $$
  SELECT
    oi.cookie_name,
    SUM(oi.quantity) as total_sold,
    COALESCE(AVG(f.rating), 0) as avg_rating
  FROM order_items oi
  JOIN orders o ON oi.order_id = o.id
  LEFT JOIN feedback f ON o.order_code = f.order_code
  WHERE o.status = 'delivered'
    AND (p_month_year IS NULL
         OR to_char(o.created_at, 'MM/YYYY') = p_month_year)
  GROUP BY oi.cookie_name
  ORDER BY total_sold DESC, avg_rating DESC
  LIMIT p_limit;
$$ LANGUAGE sql STABLE SECURITY DEFINER
SET search_path = public;
