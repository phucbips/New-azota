import { motion } from "framer-motion";
import { TreePine } from "lucide-react";
import { FloatingLeaf, VineBorder, DetailedLotus, BananaLeaf } from "@/components/decorations/VietnameseMotifs";

const GreenFundSection = () => {
  return (
    <section className="relative overflow-hidden bg-primary py-20 text-primary-foreground md:py-28">
      {/* Vine borders */}
      <VineBorder className="absolute left-0 top-0 opacity-30" />
      <VineBorder className="absolute bottom-0 left-0 opacity-30" flip />

      {/* Floating leaves */}
      <FloatingLeaf className="absolute left-[5%] top-[20%] h-20 w-14 opacity-20" delay={0} />
      <FloatingLeaf className="absolute right-[10%] top-[30%] h-16 w-10 opacity-15" delay={2} />
      <FloatingLeaf className="absolute left-[60%] bottom-[10%] h-18 w-12 opacity-20" delay={1} />

      {/* Lotus background decoration */}
      <DetailedLotus className="absolute -left-8 bottom-[10%] h-40 w-48 opacity-[0.08] md:h-56 md:w-64" size="lg" />
      <DetailedLotus className="absolute -right-6 top-[5%] h-32 w-40 opacity-[0.06]" size="md" />

      {/* Banana leaves */}
      <BananaLeaf className="absolute -left-6 top-[5%] hidden h-52 w-28 opacity-[0.1] md:block" />
      <BananaLeaf className="absolute -right-6 bottom-[5%] hidden h-52 w-28 opacity-[0.08] md:block" flip />

      <div className="container relative mx-auto px-4">
        <div className="mx-auto max-w-3xl text-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
          >
            <div className="mx-auto mb-6 flex h-20 w-20 items-center justify-center rounded-full bg-primary-foreground/20">
              <TreePine className="h-10 w-10" />
            </div>
            <h2 className="mb-4 font-display text-4xl font-extrabold md:text-5xl">
              Quỹ Trồng Cây Xanh
            </h2>
            <p className="text-xl leading-relaxed opacity-90">
              <span className="font-extrabold text-secondary">5%</span> từ mỗi đơn hàng được trích vào quỹ trồng cây xanh.
              Mỗi chiếc cookie bạn thưởng thức đều góp phần xanh hóa Việt Nam 🌱
            </p>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default GreenFundSection;
