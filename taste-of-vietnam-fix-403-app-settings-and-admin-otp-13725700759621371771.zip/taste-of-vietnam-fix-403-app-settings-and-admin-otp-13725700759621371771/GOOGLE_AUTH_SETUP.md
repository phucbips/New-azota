# Hướng dẫn cấu hình Google Login cho Supabase

Để chức năng Google Login hoạt động trên ứng dụng Nova Cookie (cả Local và Vercel), bạn cần thực hiện các bước sau để lấy **Google Client ID** và **Client Secret**.

## Bước 1: Tạo Google Cloud Project

1.  Truy cập [Google Cloud Console](https://console.cloud.google.com/).
2.  Đăng nhập bằng tài khoản Google của bạn.
3.  Bấm vào dropdown tên project (góc trên trái) -> Bấm **New Project**.
4.  Đặt tên project (ví dụ: `Nova Cookie Auth`) -> Bấm **Create**.
5.  Đợi project tạo xong, chọn project đó.

## Bước 2: Cấu hình OAuth Consent Screen

1.  Trong menu bên trái, chọn **APIs & Services** -> **OAuth consent screen**.
2.  Chọn **External** (Để cho phép user ngoài tổ chức đăng nhập) -> Bấm **Create**.
3.  Điền thông tin:
    *   **App name:** Nova Cookie
    *   **User support email:** Chọn email của bạn.
    *   **Developer contact information:** Nhập email của bạn.
    *   Bấm **Save and Continue**.
4.  Phần **Scopes**, không cần thêm gì đặc biệt, cứ bấm **Save and Continue**.
5.  Phần **Test users**, không cần thêm, bấm **Save and Continue**.
6.  Xem lại thông tin rồi bấm **Back to Dashboard**.
7.  Quan trọng: Bấm nút **PUBLISH APP** để chuyển trạng thái từ *Testing* sang *Production* (nếu không user khác sẽ không đăng nhập được).

## Bước 3: Tạo Credentials (Client ID & Secret)

1.  Chọn menu **Credentials** (bên trái).
2.  Bấm **+ CREATE CREDENTIALS** -> Chọn **OAuth client ID**.
3.  **Application type:** Chọn **Web application**.
4.  **Name:** Đặt tên tùy ý (ví dụ: `Supabase Auth`).
5.  **Authorized JavaScript origins:** (Thêm tất cả các domain chạy app)
    *   `http://localhost:5173`
    *   `https://nova-cookie.vercel.app`
    *   `https://vttcklvliliesbfudgjz.supabase.co` (Đây là domain Supabase Auth của bạn)
6.  **Authorized redirect URIs:** (Quan trọng nhất)
    *   `https://vttcklvliliesbfudgjz.supabase.co/auth/v1/callback`
    *(Lưu ý: Thay `vttcklvliliesbfudgjz` bằng Project ID mới nếu bạn tạo project mới).*
7.  Bấm **Create**.
8.  Một hộp thoại hiện ra chứa **Your Client ID** và **Your Client Secret**. Hãy copy và lưu lại.

## Bước 4: Cấu hình Supabase

1.  Truy cập [Supabase Dashboard](https://supabase.com/dashboard) -> Chọn Project của bạn.
2.  Vào **Authentication** -> **Providers**.
3.  Tìm **Google** và bấm vào nó.
4.  Bật switch **Enable Google**.
5.  Paste **Client ID** vào ô *Client ID*.
6.  Paste **Client Secret** vào ô *Client Secret*.
7.  Bấm **Save**.

## Bước 5: Cấu hình URL Redirect trong Supabase

1.  Vào **Authentication** -> **URL Configuration**.
2.  **Site URL:** Nhập `https://nova-cookie.vercel.app`.
3.  **Redirect URLs:** Thêm các dòng sau:
    *   `http://localhost:5173`
    *   `https://nova-cookie.vercel.app`
    *   `https://nova-cookie.vercel.app/`
    *   `https://nova-cookie.vercel.app/**`

---
Sau khi hoàn tất, bạn có thể thử đăng nhập lại trên Local hoặc Vercel. Nếu gặp lỗi "Redirect mismatch", hãy kiểm tra kỹ Bước 3 (phần Authorized redirect URIs) và Bước 5.
