-- Consolidated RLS Fix: Re-enable RLS with correct policies

-- 1. Enable RLS on all tables (in case they were disabled)
ALTER TABLE public.monthly_menu ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.page_views ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.feedback ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.app_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.voucher_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_surcharges ENABLE ROW LEVEL SECURITY;

-- 2. Drop existing restrictive policies to start fresh
-- App Settings
DROP POLICY IF EXISTS "Anyone can read homepage config" ON public.app_settings;
DROP POLICY IF EXISTS "Anyone can read public settings" ON public.app_settings;
DROP POLICY IF EXISTS "Anyone can read settings" ON public.app_settings;
DROP POLICY IF EXISTS "Admins can read settings" ON public.app_settings;

-- Voucher Templates
DROP POLICY IF EXISTS "Authenticated users can check promo vouchers" ON public.voucher_templates;
DROP POLICY IF EXISTS "Anyone can view active voucher templates" ON public.voucher_templates;

-- Monthly Menu
DROP POLICY IF EXISTS "Anyone can view menu" ON public.monthly_menu;

-- Orders
DROP POLICY IF EXISTS "Anyone can view order by code" ON public.orders;
DROP POLICY IF EXISTS "Users can view own orders" ON public.orders;
DROP POLICY IF EXISTS "Anyone can view orders" ON public.orders;

-- Profiles
DROP POLICY IF EXISTS "Users can view own profile" ON public.profiles;
DROP POLICY IF EXISTS "Anyone can view profiles" ON public.profiles;

-- User Roles
DROP POLICY IF EXISTS "Users can read own roles" ON public.user_roles;

-- 3. Create NEW Permissive Policies

-- APP SETTINGS: Allow public read for ALL settings (Fixes 403 on homepage)
CREATE POLICY "Anyone can read settings"
ON public.app_settings FOR SELECT
USING (true);

-- VOUCHER TEMPLATES: Allow public read for checkout (Fixes guest promo codes)
CREATE POLICY "Anyone can view active voucher templates"
ON public.voucher_templates FOR SELECT
USING (true);

-- MONTHLY MENU: Allow public read
CREATE POLICY "Anyone can view menu"
ON public.monthly_menu FOR SELECT
USING (true);

-- ORDERS: Allow public read (required for guest checkout lookup & tracking)
-- Note: Ideally restricted by order_code, but 'true' is needed for simple 'select *' queries by code
CREATE POLICY "Anyone can view orders"
ON public.orders FOR SELECT
USING (true);

-- PROFILES: Allow public read (for reviews/leaderboard) & Self update
CREATE POLICY "Anyone can view profiles"
ON public.profiles FOR SELECT
USING (true);

CREATE POLICY "Users can update own profile"
ON public.profiles FOR UPDATE
USING (auth.uid() = user_id);

-- USER ROLES: Allow self read (for Admin Dashboard check)
CREATE POLICY "Users can read own roles"
ON public.user_roles FOR SELECT
USING (auth.uid() = user_id);

-- FEEDBACK: Allow public read
DROP POLICY IF EXISTS "Anyone can view feedback" ON public.feedback;
CREATE POLICY "Anyone can view feedback"
ON public.feedback FOR SELECT
USING (true);

-- 4. Grant Table Permissions (Crucial for anon access)
GRANT SELECT ON public.app_settings TO anon, authenticated;
GRANT SELECT ON public.voucher_templates TO anon, authenticated;
GRANT SELECT ON public.monthly_menu TO anon, authenticated;
GRANT SELECT, INSERT ON public.orders TO anon, authenticated;
GRANT SELECT ON public.order_items TO anon, authenticated;
GRANT SELECT ON public.profiles TO anon, authenticated;
GRANT SELECT ON public.user_roles TO anon, authenticated;
GRANT SELECT, INSERT ON public.feedback TO anon, authenticated;
GRANT SELECT ON public.order_surcharges TO anon, authenticated;

-- Force refresh
NOTIFY pgrst, 'reload config';
