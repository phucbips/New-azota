
-- 1. Add cost_price to monthly_menu
ALTER TABLE public.monthly_menu ADD COLUMN cost_price integer NOT NULL DEFAULT 0;

-- 2. Create financial_transactions table
CREATE TABLE public.financial_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  type text NOT NULL CHECK (type IN ('income', 'expense')),
  category text NOT NULL CHECK (category IN ('order_revenue', 'ingredient', 'capital', 'other')),
  amount integer NOT NULL,
  description text NOT NULL DEFAULT '',
  reference_order_id uuid REFERENCES public.orders(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  created_by uuid NOT NULL
);

ALTER TABLE public.financial_transactions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can select financial_transactions"
  ON public.financial_transactions FOR SELECT
  USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can insert financial_transactions"
  ON public.financial_transactions FOR INSERT
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can update financial_transactions"
  ON public.financial_transactions FOR UPDATE
  USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can delete financial_transactions"
  ON public.financial_transactions FOR DELETE
  USING (has_role(auth.uid(), 'admin'::app_role));

-- 3. Create order_surcharges table
CREATE TABLE public.order_surcharges (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  type text NOT NULL CHECK (type IN ('fixed', 'percent')),
  value integer NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  is_default boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.order_surcharges ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view surcharges"
  ON public.order_surcharges FOR SELECT
  USING (true);

CREATE POLICY "Admins can insert surcharges"
  ON public.order_surcharges FOR INSERT
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can update surcharges"
  ON public.order_surcharges FOR UPDATE
  USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can delete surcharges"
  ON public.order_surcharges FOR DELETE
  USING (has_role(auth.uid(), 'admin'::app_role));

-- 4. Seed default surcharges
INSERT INTO public.order_surcharges (name, type, value, is_active, is_default)
VALUES
  ('Phí ship', 'fixed', 15000, true, true),
  ('Ủng hộ Quỹ Xanh', 'percent', 5, true, true);
