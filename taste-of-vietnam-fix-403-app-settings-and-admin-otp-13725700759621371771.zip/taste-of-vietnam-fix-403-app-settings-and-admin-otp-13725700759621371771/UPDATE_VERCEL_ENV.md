# Cập nhật Biến Môi Trường trên Vercel

Bạn vừa chuyển sang Project Supabase mới, nên bắt buộc phải cập nhật biến môi trường trên Vercel thì website mới chạy được.

## Bước 1: Copy thông tin mới

Sử dụng các giá trị dưới đây (giống trong file `.env` vừa cập nhật):

*   **VITE_SUPABASE_PROJECT_ID:** `iiglwrhbdddmgfzsmimv`
*   **VITE_SUPABASE_URL:** `https://iiglwrhbdddmgfzsmimv.supabase.co`
*   **VITE_SUPABASE_PUBLISHABLE_KEY:** `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlpZ2x3cmhiZGRkbWdmenNtaW12Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzIwMzA3NzEsImV4cCI6MjA4NzYwNjc3MX0.3iCau5voizPpe7dLS9z94TOzpgGjlRGiSE-VXmbIVo8`
*   **SUPABASE_URL:** `https://iiglwrhbdddmgfzsmimv.supabase.co`
*   **SUPABASE_ANON_KEY:** `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlpZ2x3cmhiZGRkbWdmenNtaW12Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzIwMzA3NzEsImV4cCI6MjA4NzYwNjc3MX0.3iCau5voizPpe7dLS9z94TOzpgGjlRGiSE-VXmbIVo8`

## Bước 2: Cập nhật trên Dashboard Vercel

1.  Truy cập [Vercel Dashboard](https://vercel.com/dashboard).
2.  Chọn dự án `nova-cookie` (hoặc tên dự án của bạn).
3.  Vào tab **Settings** -> **Environment Variables**.
4.  Tìm các biến tên tương ứng ở trên.
5.  Bấm vào nút **Edit** (biểu tượng bút chì) bên cạnh giá trị cũ.
6.  Paste giá trị mới vào và bấm **Save**.
7.  Làm lần lượt cho hết 5 biến trên.

## Bước 3: Redeploy (Quan trọng)

Sau khi sửa biến môi trường, bạn phải deploy lại để áp dụng:
1.  Vào tab **Deployments**.
2.  Chọn deployment mới nhất (hoặc cái đang chạy).
3.  Bấm vào dấu 3 chấm `...` bên phải -> Chọn **Redeploy**.
4.  Đợi deploy xong là web sẽ chạy với project Supabase mới!

---
**Lưu ý:** Để các chức năng gửi mail, thanh toán hoạt động, bạn cũng cần lấy **Service Role Key** từ Supabase mới và cập nhật cho biến `SUPABASE_SERVICE_ROLE_KEY` trên Vercel nhé.
