-- Fix RLS Policies and Ensure Access

-- 1. Helper Function for Roles
DO $$ BEGIN
    CREATE TYPE public.app_role AS ENUM ('admin', 'baker', 'customer');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

CREATE OR REPLACE FUNCTION public.has_role(user_id uuid, role_name text)
RETURNS boolean AS $$
DECLARE
  retval boolean;
BEGIN
  -- Check if the user has the specified role in user_roles table
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles ur
    WHERE ur.user_id = has_role.user_id AND ur.role = has_role.role_name
  ) INTO retval;
  RETURN retval;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 2. Enable RLS on all tables (idempotent)
ALTER TABLE public.monthly_menu ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.page_views ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.feedback ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- 3. Drop existing restrictive/broken policies to start fresh
DO $$
BEGIN
    -- monthly_menu
    DROP POLICY IF EXISTS "Anyone can view menu" ON public.monthly_menu;
    DROP POLICY IF EXISTS "Admins can manage menu" ON public.monthly_menu;
    DROP POLICY IF EXISTS "Admins and Bakers can manage menu" ON public.monthly_menu;

    -- page_views
    DROP POLICY IF EXISTS "Anyone can insert page views" ON public.page_views;
    DROP POLICY IF EXISTS "Admins can view page views" ON public.page_views;

    -- orders
    DROP POLICY IF EXISTS "Anyone can create orders" ON public.orders;
    DROP POLICY IF EXISTS "Anyone can view order by code" ON public.orders;
    DROP POLICY IF EXISTS "Anyone can view orders" ON public.orders;

    -- order_items
    DROP POLICY IF EXISTS "Anyone can create order items" ON public.order_items;
    DROP POLICY IF EXISTS "Anyone can view order items" ON public.order_items;

    -- feedback
    DROP POLICY IF EXISTS "Anyone can create feedback" ON public.feedback;
    DROP POLICY IF EXISTS "Anyone can view feedback" ON public.feedback;

    -- user_roles
    DROP POLICY IF EXISTS "Users can read own roles" ON public.user_roles;
END $$;

-- 4. Create correct policies

-- MONTHLY MENU
-- Everyone can view
CREATE POLICY "Anyone can view menu"
ON public.monthly_menu FOR SELECT
USING (true);

-- Admins and Bakers can insert/update/delete
CREATE POLICY "Admins and Bakers can manage menu"
ON public.monthly_menu FOR ALL
USING (auth.role() = 'authenticated' AND (has_role(auth.uid(), 'admin') OR has_role(auth.uid(), 'baker')));

-- PAGE VIEWS
-- Everyone can insert (tracking)
CREATE POLICY "Anyone can insert page views"
ON public.page_views FOR INSERT
WITH CHECK (true);

-- Admins can view stats
CREATE POLICY "Admins can view page views"
ON public.page_views FOR SELECT
USING (auth.role() = 'authenticated' AND has_role(auth.uid(), 'admin'));

-- ORDERS
-- Everyone can create orders
CREATE POLICY "Anyone can create orders"
ON public.orders FOR INSERT
WITH CHECK (true);

-- Everyone can view orders (needed for order tracking by code)
-- Note: In a production app with sensitive data, this should be restricted.
-- But for now we restore functionality.
CREATE POLICY "Anyone can view orders"
ON public.orders FOR SELECT
USING (true);

-- ORDER ITEMS
-- Everyone can create order items
CREATE POLICY "Anyone can create order items"
ON public.order_items FOR INSERT
WITH CHECK (true);

-- Everyone can view order items
CREATE POLICY "Anyone can view order items"
ON public.order_items FOR SELECT
USING (true);

-- FEEDBACK
-- Everyone can create feedback
CREATE POLICY "Anyone can create feedback"
ON public.feedback FOR INSERT
WITH CHECK (true);

-- Everyone can view feedback
CREATE POLICY "Anyone can view feedback"
ON public.feedback FOR SELECT
USING (true);

-- USER ROLES
-- Users can read their own roles
CREATE POLICY "Users can read own roles"
ON public.user_roles FOR SELECT
USING (auth.uid() = user_id);

-- Admins can manage roles
CREATE POLICY "Admins can manage user roles"
ON public.user_roles FOR ALL
USING (auth.role() = 'authenticated' AND has_role(auth.uid(), 'admin'));
