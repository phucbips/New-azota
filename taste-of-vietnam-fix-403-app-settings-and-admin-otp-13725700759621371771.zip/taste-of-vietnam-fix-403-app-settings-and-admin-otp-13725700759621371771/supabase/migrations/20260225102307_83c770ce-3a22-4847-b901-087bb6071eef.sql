-- Allow public read for homepage config keys
CREATE POLICY "Anyone can read homepage config"
ON public.app_settings
FOR SELECT
USING (key = ANY (ARRAY['HERO_CONFIG', 'HOMEPAGE_SECTIONS', 'SECTION_ORDER', 'EMAIL_TEMPLATES']));
