import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Leaf, Loader2, Mail, Lock, User, KeyRound } from "lucide-react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { z } from "zod";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

const signupSchema = z.object({
  fullName: z.string().trim().min(1, "Vui lòng nhập họ tên").max(100),
  email: z.string().trim().email("Email không hợp lệ"),
  password: z.string().min(6, "Mật khẩu ít nhất 6 ký tự"),
});

const loginSchema = z.object({
  email: z.string().trim().email("Email không hợp lệ"),
  password: z.string().min(1, "Vui lòng nhập mật khẩu"),
});

const COUNTDOWN_SECONDS = 60;

const Auth = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [isForgotPassword, setIsForgotPassword] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);

  // OTP states
  const [otpStep, setOtpStep] = useState<"none" | "password_reset_code" | "password_reset_new" | "signup_verify">("none");
  const [otpCode, setOtpCode] = useState("");
  const [otpLoading, setOtpLoading] = useState(false);
  const [otpEmail, setOtpEmail] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  // Signup pending data
  const [signupPendingData, setSignupPendingData] = useState<{ fullName: string; email: string; password: string } | null>(null);

  // Countdown timer
  const [resendCountdown, setResendCountdown] = useState(0);

  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const redirectTo = searchParams.get("redirect") || "/";

  // Countdown effect
  useEffect(() => {
    if (resendCountdown <= 0) return;
    const timer = setInterval(() => {
      setResendCountdown((prev) => (prev <= 1 ? 0 : prev - 1));
    }, 1000);
    return () => clearInterval(timer);
  }, [resendCountdown]);

  // Check URL hash for OAuth errors (like ?error=server_error&...)
  useEffect(() => {
    const hash = window.location.hash;
    const search = window.location.search;

    if (hash.includes("error=server_error") || search.includes("error=server_error")) {
      const errorDescMatch = hash.match(/error_description=([^&]+)/) || search.match(/error_description=([^&]+)/);
      if (errorDescMatch && errorDescMatch[1]) {
        const decodedError = decodeURIComponent(errorDescMatch[1].replace(/\+/g, " "));
        if (decodedError.includes("Database error saving new user")) {
          toast.error("Lỗi cấu hình CSDL. Vui lòng thử lại sau.");
          window.history.replaceState(null, "", window.location.pathname);
        } else {
          toast.error(`Lỗi đăng nhập: ${decodedError}`);
        }
      }
    }
  }, []);

  const handleGoogleLogin = async () => {
    setGoogleLoading(true);
    const { error } = await supabase.auth.signInWithOAuth({
      provider: "google",
      options: {
        redirectTo: window.location.origin,
      },
    });
    if (error) {
      toast.error("Đăng nhập Google thất bại: " + error.message);
      setGoogleLoading(false);
    }
  };

  const sendVerificationCode = async (targetEmail: string, type: "admin_login" | "password_reset" | "signup_verify") => {
    try {
      const { data, error } = await supabase.functions.invoke("send-verification-code", {
        body: { email: targetEmail, type },
      });
      if (error) {
        toast.error("Lỗi kết nối: Không thể gửi mã xác thực");
        return false;
      }
      if (data && !data.success) {
        toast.error(data.error || "Lỗi gửi mã");
        return false;
      }
      return true;
    } catch (err: any) {
      toast.error("Lỗi hệ thống: " + (err.message || "Hãy thử lại"));
      return false;
    }
  };

  const verifyCode = async (targetEmail: string, code: string, type: "admin_login" | "password_reset" | "signup_verify") => {
    const { data, error } = await supabase.functions.invoke("verify-code", {
      body: { email: targetEmail, code, type },
    });
    if (error || !data?.valid) {
      return false;
    }
    return true;
  };

  const startCountdown = () => {
    setResendCountdown(COUNTDOWN_SECONDS);
  };

  const handleForgotPassword = async () => {
    if (!email.trim()) {
      setErrors({ email: "Vui lòng nhập email" });
      return;
    }
    const emailCheck = z.string().email().safeParse(email.trim());
    if (!emailCheck.success) {
      setErrors({ email: "Email không hợp lệ" });
      return;
    }
    setLoading(true);
    const sent = await sendVerificationCode(email.trim(), "password_reset");
    setLoading(false);
    if (sent) {
      setOtpEmail(email.trim());
      setOtpStep("password_reset_code");
      setOtpCode("");
      startCountdown();
      toast.success("Mã xác thực đã được gửi đến email!");
    }
  };

  const handleVerifyResetCode = async () => {
    if (otpCode.length !== 6) {
      toast.error("Vui lòng nhập đủ 6 chữ số");
      return;
    }
    setOtpLoading(true);
    const isValid = await verifyCode(otpEmail, otpCode, "password_reset");
    setOtpLoading(false);
    if (!isValid) {
      toast.error("Mã không hợp lệ hoặc đã hết hạn");
    } else {
      setOtpStep("password_reset_new");
      toast.success("Xác thực thành công!");
    }
  };

  const handleVerifySignupCode = async () => {
    if (otpCode.length !== 6) {
      toast.error("Vui lòng nhập đủ 6 chữ số");
      return;
    }
    if (!signupPendingData) return;

    setOtpLoading(true);
    // Verify first
    const isValid = await verifyCode(otpEmail, otpCode, "signup_verify");

    if (!isValid) {
      setOtpLoading(false);
      toast.error("Mã không hợp lệ hoặc đã hết hạn");
      return;
    }

    // Then create user (verified)
    const { error } = await supabase.auth.signUp({
      email: signupPendingData.email,
      password: signupPendingData.password,
      options: {
        data: { full_name: signupPendingData.fullName },
      },
    });

    setOtpLoading(false);
    if (error) {
      toast.error("Lỗi tạo tài khoản: " + error.message);
    } else {
      toast.success("Đăng ký thành công!");
      navigate(redirectTo);
    }
  };

  const handleSetNewPassword = async () => {
    if (newPassword.length < 6) {
      toast.error("Mật khẩu ít nhất 6 ký tự");
      return;
    }
    if (newPassword !== confirmPassword) {
      toast.error("Mật khẩu xác nhận không khớp");
      return;
    }
    setOtpLoading(true);

    const { data, error } = await supabase.functions.invoke("reset-password", {
      body: { email: otpEmail, newPassword },
    });

    setOtpLoading(false);

    if (error) {
      toast.error("Lỗi kết nối: " + error.message);
      return;
    }

    if (!data?.success) {
      toast.error(data?.error || "Không thể đặt lại mật khẩu");
      return;
    }

    toast.success("Đặt lại mật khẩu thành công! Hãy đăng nhập lại.");
    setOtpStep("none");
    setIsForgotPassword(false);
    setNewPassword("");
    setConfirmPassword("");
    setOtpCode("");
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrors({});

    if (isLogin) {
      const result = loginSchema.safeParse({ email, password });
      if (!result.success) {
        const fieldErrors: Record<string, string> = {};
        result.error.errors.forEach((err) => {
          if (err.path[0]) fieldErrors[err.path[0] as string] = err.message;
        });
        setErrors(fieldErrors);
        return;
      }

      setLoading(true);
      const { data: signInData, error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });

      if (error) {
        setLoading(false);
        // Hỗ trợ hiển thị message lỗi chi tiết
        toast.error(error.message === "Invalid login credentials" ? "Email hoặc mật khẩu không đúng" : (error.message || "Lỗi đăng nhập"));
        return;
      }

      setLoading(false);
      toast.success("Đăng nhập thành công!");
      navigate(redirectTo);
    } else {
      const result = signupSchema.safeParse({ fullName, email, password });
      if (!result.success) {
        const fieldErrors: Record<string, string> = {};
        result.error.errors.forEach((err) => {
          if (err.path[0]) fieldErrors[err.path[0] as string] = err.message;
        });
        setErrors(fieldErrors);
        return;
      }

      setLoading(true);
      // Check if user exists (handled by function or signup later, but sending code first is safer/UX)
      const sent = await sendVerificationCode(email.trim(), "signup_verify");
      setLoading(false);

      if (sent) {
        setSignupPendingData({ fullName: fullName.trim(), email: email.trim(), password });
        setOtpEmail(email.trim());
        setOtpStep("signup_verify");
        setOtpCode("");
        startCountdown();
        toast.success("Mã xác thực đã được gửi đến email!");
      }
    }
  };

  const handleResendCode = async () => {
    if (resendCountdown > 0) return;
    const type = otpStep === "signup_verify" ? "signup_verify" : "password_reset";
    setOtpLoading(true);
    const sent = await sendVerificationCode(otpEmail, type);
    setOtpLoading(false);
    if (sent) {
      toast.success("Đã gửi lại mã xác thực!");
      setOtpCode("");
      startCountdown();
    }
  };

  const inputClass = (field: string) =>
    `w-full rounded-xl border ${errors[field] ? "border-destructive" : "border-border"} bg-background px-4 py-3 pl-11 text-sm text-foreground outline-none transition-colors placeholder:text-muted-foreground focus:border-primary focus:ring-2 focus:ring-primary/20`;

  const resendButton = (
    <button
      onClick={handleResendCode}
      disabled={otpLoading || resendCountdown > 0}
      className="font-semibold text-primary hover:underline disabled:opacity-50 disabled:no-underline"
    >
      {resendCountdown > 0 ? `Gửi lại mã (${resendCountdown}s)` : "Gửi lại mã"}
    </button>
  );

  // OTP Verification Screen for password reset
  if (otpStep === "password_reset_code") {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <main className="flex items-center justify-center px-4 pt-24 pb-16">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-md">
            <div className="mb-8 text-center">
              <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-primary/10">
                <KeyRound className="h-7 w-7 text-primary" />
              </div>
              <h1 className="font-display text-3xl font-extrabold text-foreground">Nhập mã xác thực</h1>
              <p className="mt-2 text-sm text-muted-foreground">
                Mã 6 chữ số đã được gửi đến <span className="font-semibold text-foreground">{otpEmail}</span>
              </p>
            </div>

            <div className="space-y-6 rounded-2xl border border-border bg-card p-6">
              <div className="flex justify-center">
                <InputOTP maxLength={6} value={otpCode} onChange={setOtpCode}>
                  <InputOTPGroup>
                    <InputOTPSlot index={0} />
                    <InputOTPSlot index={1} />
                    <InputOTPSlot index={2} />
                    <InputOTPSlot index={3} />
                    <InputOTPSlot index={4} />
                    <InputOTPSlot index={5} />
                  </InputOTPGroup>
                </InputOTP>
              </div>

              <button
                onClick={handleVerifyResetCode}
                disabled={otpLoading || otpCode.length !== 6}
                className="w-full rounded-full bg-primary px-6 py-3 text-sm font-bold text-primary-foreground transition-transform hover:scale-[1.02] disabled:opacity-50"
              >
                {otpLoading ? (
                  <span className="flex items-center justify-center gap-2">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Đang xác thực...
                  </span>
                ) : "Xác nhận"}
              </button>

              <div className="flex items-center justify-between text-sm">
                {resendButton}
                <button
                  onClick={() => { setOtpStep("none"); setOtpCode(""); setIsForgotPassword(false); setResendCountdown(0); }}
                  className="text-muted-foreground hover:text-foreground"
                >
                  Hủy bỏ
                </button>
              </div>
            </div>
          </motion.div>
        </main>
        <Footer />
      </div>
    );
  }

  // Signup OTP verification screen
  if (otpStep === "signup_verify") {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <main className="flex items-center justify-center px-4 pt-24 pb-16">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-md">
            <div className="mb-8 text-center">
              <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-primary/10">
                <Mail className="h-7 w-7 text-primary" />
              </div>
              <h1 className="font-display text-3xl font-extrabold text-foreground">Xác thực email</h1>
              <p className="mt-2 text-sm text-muted-foreground">
                Mã 6 chữ số đã được gửi đến <span className="font-semibold text-foreground">{otpEmail}</span>
              </p>
            </div>

            <div className="space-y-6 rounded-2xl border border-border bg-card p-6">
              <div className="flex justify-center">
                <InputOTP maxLength={6} value={otpCode} onChange={setOtpCode}>
                  <InputOTPGroup>
                    <InputOTPSlot index={0} />
                    <InputOTPSlot index={1} />
                    <InputOTPSlot index={2} />
                    <InputOTPSlot index={3} />
                    <InputOTPSlot index={4} />
                    <InputOTPSlot index={5} />
                  </InputOTPGroup>
                </InputOTP>
              </div>

              <button
                onClick={handleVerifySignupCode}
                disabled={otpLoading || otpCode.length !== 6}
                className="w-full rounded-full bg-primary px-6 py-3 text-sm font-bold text-primary-foreground transition-transform hover:scale-[1.02] disabled:opacity-50"
              >
                {otpLoading ? (
                  <span className="flex items-center justify-center gap-2">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Đang tạo tài khoản...
                  </span>
                ) : "Xác nhận & Đăng ký"}
              </button>

              <div className="flex items-center justify-between text-sm">
                {resendButton}
                <button
                  onClick={() => { setOtpStep("none"); setOtpCode(""); setSignupPendingData(null); setResendCountdown(0); }}
                  className="text-muted-foreground hover:text-foreground"
                >
                  Quay lại
                </button>
              </div>
            </div>
          </motion.div>
        </main>
        <Footer />
      </div>
    );
  }

  // New password screen (after reset code verified)
  if (otpStep === "password_reset_new") {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <main className="flex items-center justify-center px-4 pt-24 pb-16">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-md">
            <div className="mb-8 text-center">
              <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-primary/10">
                <Lock className="h-7 w-7 text-primary" />
              </div>
              <h1 className="font-display text-3xl font-extrabold text-foreground">Đặt mật khẩu mới</h1>
              <p className="mt-2 text-sm text-muted-foreground">Nhập mật khẩu mới cho tài khoản <span className="font-semibold text-foreground">{otpEmail}</span></p>
            </div>

            <div className="space-y-4 rounded-2xl border border-border bg-card p-6">
              <div>
                <label className="mb-1.5 block text-sm font-semibold text-foreground">Mật khẩu mới</label>
                <div className="relative">
                  <Lock className="absolute left-3.5 top-3.5 h-4 w-4 text-muted-foreground" />
                  <input
                    type="password"
                    placeholder="••••••"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    className={inputClass("newPassword")}
                  />
                </div>
              </div>
              <div>
                <label className="mb-1.5 block text-sm font-semibold text-foreground">Xác nhận mật khẩu</label>
                <div className="relative">
                  <Lock className="absolute left-3.5 top-3.5 h-4 w-4 text-muted-foreground" />
                  <input
                    type="password"
                    placeholder="••••••"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    className={inputClass("confirmPassword")}
                  />
                </div>
              </div>
              <button
                onClick={handleSetNewPassword}
                disabled={otpLoading}
                className="w-full rounded-full bg-primary px-6 py-3 text-sm font-bold text-primary-foreground transition-transform hover:scale-[1.02] disabled:opacity-50"
              >
                {otpLoading ? (
                  <span className="flex items-center justify-center gap-2">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Đang xử lý...
                  </span>
                ) : "Đặt lại mật khẩu"}
              </button>
            </div>
          </motion.div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="flex items-center justify-center px-4 pt-24 pb-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-md"
        >
          <div className="mb-8 text-center">
            <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-primary/10">
              <Leaf className="h-7 w-7 text-primary" />
            </div>
            <h1 className="font-display text-3xl font-extrabold text-foreground">
              {isForgotPassword ? "Quên mật khẩu" : isLogin ? "Đăng nhập" : "Đăng ký"}
            </h1>
            <p className="mt-2 text-sm text-muted-foreground">
              {isForgotPassword ? "Nhận mã xác thực qua email" : isLogin ? "Đăng nhập để theo dõi đơn hàng" : "Tạo tài khoản để lưu lịch sử đặt hàng"}
            </p>
          </div>

          {isForgotPassword ? (
            <div className="space-y-4 rounded-2xl border border-border bg-card p-6">
              <p className="text-sm text-muted-foreground">Nhập email để nhận mã đặt lại mật khẩu</p>
              <div>
                <label className="mb-1.5 block text-sm font-semibold text-foreground">Email</label>
                <div className="relative">
                  <Mail className="absolute left-3.5 top-3.5 h-4 w-4 text-muted-foreground" />
                  <input
                    type="email"
                    placeholder="email@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className={inputClass("email")}
                  />
                </div>
                {errors.email && <p className="mt-1 text-xs text-destructive">{errors.email}</p>}
              </div>
              <button
                onClick={handleForgotPassword}
                disabled={loading}
                className="w-full rounded-full bg-primary px-6 py-3 text-sm font-bold text-primary-foreground transition-transform hover:scale-[1.02] disabled:opacity-50"
              >
                {loading ? (
                  <span className="flex items-center justify-center gap-2">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Đang gửi...
                  </span>
                ) : "Gửi mã xác thực"}
              </button>
              <button
                onClick={() => { setIsForgotPassword(false); setErrors({}); }}
                className="w-full text-sm font-semibold text-primary hover:underline"
              >
                Quay lại đăng nhập
              </button>
            </div>
          ) : (
          <>
          <form onSubmit={handleSubmit} className="space-y-4 rounded-2xl border border-border bg-card p-6">
            {!isLogin && (
              <div>
                <label className="mb-1.5 block text-sm font-semibold text-foreground">Họ tên</label>
                <div className="relative">
                  <User className="absolute left-3.5 top-3.5 h-4 w-4 text-muted-foreground" />
                  <input
                    type="text"
                    placeholder="Nguyễn Văn A"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className={inputClass("fullName")}
                  />
                </div>
                {errors.fullName && <p className="mt-1 text-xs text-destructive">{errors.fullName}</p>}
              </div>
            )}
            <div>
              <label className="mb-1.5 block text-sm font-semibold text-foreground">Email</label>
              <div className="relative">
                <Mail className="absolute left-3.5 top-3.5 h-4 w-4 text-muted-foreground" />
                <input
                  type="email"
                  placeholder="email@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className={inputClass("email")}
                />
              </div>
              {errors.email && <p className="mt-1 text-xs text-destructive">{errors.email}</p>}
            </div>
            <div>
              <label className="mb-1.5 block text-sm font-semibold text-foreground">Mật khẩu</label>
              <div className="relative">
                <Lock className="absolute left-3.5 top-3.5 h-4 w-4 text-muted-foreground" />
                <input
                  type="password"
                  placeholder="••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className={inputClass("password")}
                />
              </div>
              {errors.password && <p className="mt-1 text-xs text-destructive">{errors.password}</p>}
            </div>
            {isLogin && (
              <button
                type="button"
                onClick={() => { setIsForgotPassword(true); setErrors({}); }}
                className="text-sm font-semibold text-primary hover:underline"
              >
                Quên mật khẩu?
              </button>
            )}
            <button
              type="submit"
              disabled={loading}
              className="w-full rounded-full bg-primary px-6 py-3 text-sm font-bold text-primary-foreground transition-transform hover:scale-[1.02] disabled:opacity-50"
            >
              {loading ? (
                <span className="flex items-center justify-center gap-2">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Đang xử lý...
                </span>
              ) : isLogin ? "Đăng nhập" : "Đăng ký"}
            </button>
          </form>

          <div className="my-4 flex items-center gap-3">
            <div className="h-px flex-1 bg-border" />
            <span className="text-xs text-muted-foreground">hoặc</span>
            <div className="h-px flex-1 bg-border" />
          </div>

          <button
            onClick={handleGoogleLogin}
            disabled={googleLoading}
            className="flex w-full items-center justify-center gap-3 rounded-full border border-border bg-card px-6 py-3 text-sm font-semibold text-foreground transition-transform hover:scale-[1.02] disabled:opacity-50"
          >
            {googleLoading ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <svg className="h-5 w-5" viewBox="0 0 24 24">
                <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" fill="#4285F4"/>
                <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
              </svg>
            )}
            Đăng nhập bằng Google
          </button>

          <p className="mt-4 text-center text-sm text-muted-foreground">
            {isLogin ? "Chưa có tài khoản?" : "Đã có tài khoản?"}{" "}
            <button
              onClick={() => { setIsLogin(!isLogin); setErrors({}); }}
              className="font-semibold text-primary hover:underline"
            >
              {isLogin ? "Đăng ký ngay" : "Đăng nhập"}
            </button>
          </p>
          </>
          )}
        </motion.div>
      </main>
      <Footer />
    </div>
  );
};

export default Auth;
