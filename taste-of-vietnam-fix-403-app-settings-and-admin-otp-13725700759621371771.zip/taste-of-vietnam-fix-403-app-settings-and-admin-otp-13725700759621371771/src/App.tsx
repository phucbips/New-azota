import { useState, useCallback } from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/hooks/useAuth";
import { ImageCacheProvider } from "@/hooks/useImageCache";
import { usePageTracking } from "@/hooks/usePageTracking";
import LoadingScreen from "@/components/LoadingScreen";
import FeedbackPopup from "@/components/FeedbackPopup";
import Index from "./pages/Index";
import Order from "./pages/Order";
import Ranking from "./pages/Ranking";
import Auth from "./pages/Auth";
import ResetPassword from "./pages/ResetPassword";
import OrderHistory from "./pages/OrderHistory";
import AdminDashboard from "./pages/AdminDashboard";
import BakerDashboard from "./pages/BakerDashboard";
import Profile from "./pages/Profile";
import AdminCheck from "./pages/AdminCheck";
import NotFound from "./pages/NotFound";
import OrderRealtimeNotifier from "./components/OrderRealtimeNotifier";

const queryClient = new QueryClient();

const PageTracker = () => {
  usePageTracking();
  return null;
};

const App = () => {
  const [loaded, setLoaded] = useState(false);
  const handleLoaded = useCallback(() => setLoaded(true), []);

  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <ImageCacheProvider>
          <TooltipProvider>
            <Toaster />
            <Sonner />
            <OrderRealtimeNotifier />
            <FeedbackPopup />
            {!loaded && <LoadingScreen onLoaded={handleLoaded} />}
            <BrowserRouter>
              <PageTracker />
              <Routes>
                <Route path="/" element={<Index />} />
                <Route path="/order" element={<Order />} />
                <Route path="/ranking" element={<Ranking />} />
                <Route path="/auth" element={<Auth />} />
                <Route path="/reset-password" element={<ResetPassword />} />
                <Route path="/orders" element={<OrderHistory />} />
                <Route path="/admin" element={<AdminDashboard />} />
                <Route path="/baker" element={<BakerDashboard />} />
                <Route path="/profile" element={<Profile />} />
                <Route path="/admin-check" element={<AdminCheck />} />
                <Route path="*" element={<NotFound />} />
              </Routes>
            </BrowserRouter>
          </TooltipProvider>
        </ImageCacheProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
};

export default App;
