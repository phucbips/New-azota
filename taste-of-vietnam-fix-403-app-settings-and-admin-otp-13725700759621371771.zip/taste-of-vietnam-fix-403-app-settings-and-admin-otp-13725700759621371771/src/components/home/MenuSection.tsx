import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { CURRENT_MONTH, formatPrice } from "@/data/mockMenu";
import { VineBorder, CornerVine, LotusDecor, DetailedLotus, TropicalVine } from "@/components/decorations/VietnameseMotifs";
import { supabase } from "@/integrations/supabase/client";

interface MenuItem {
  id: string;
  cookie_name: string;
  description: string | null;
  origin: string | null;
  price: number;
  image_url: string | null;
  stock: number;
}

const MenuSection = () => {
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchMenu = async () => {
      const { data, error } = await supabase
        .from("monthly_menu")
        .select("id, cookie_name, description, origin, price, image_url, stock")
        .eq("is_active", true)
        .order("display_order");
      if (!error && data) setMenuItems(data);
      setLoading(false);
    };
    fetchMenu();
  }, []);

  if (loading) return null;

  return (
    <section id="menu" className="relative bg-background py-16 md:py-24">
      <VineBorder className="absolute left-0 top-0 opacity-60" />
      <CornerVine className="absolute left-0 top-0 h-32 w-32 md:h-48 md:w-48" position="top-left" />
      <CornerVine className="absolute right-0 top-0 h-32 w-32 md:h-48 md:w-48" position="top-right" />

      {/* Side tropical vines */}
      <TropicalVine className="absolute left-0 top-[15%] hidden h-[400px] w-[60px] opacity-40 md:block" side="left" />
      <TropicalVine className="absolute right-0 top-[40%] hidden h-[400px] w-[60px] opacity-30 md:block" side="right" />

      <div className="container relative mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-16 md:mb-24"
        >
          <span className="mb-3 inline-block rounded-full border border-secondary bg-secondary/10 px-4 py-1.5 text-sm font-semibold text-secondary-foreground">
            {CURRENT_MONTH}
          </span>
          <h2 className="font-display text-4xl font-extrabold text-foreground md:text-6xl lg:text-7xl">
            Menu trong tháng
          </h2>
          <p className="mt-3 text-lg text-muted-foreground">
            5 vị mới mỗi tháng — thử ngay kẻo hết!
          </p>
        </motion.div>

        {menuItems.length === 0 ? (
          <div className="text-center text-muted-foreground">Chưa có menu cho tháng này</div>
        ) : (
          <div className="space-y-20 md:space-y-32">
            {menuItems.map((cookie, i) => {
              const isEven = i % 2 === 0;
              const outOfStock = cookie.stock <= 0;
              return (
                <motion.div
                  key={cookie.id}
                  initial={{ opacity: 0, y: 50 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-100px" }}
                  transition={{ duration: 0.6 }}
                  className="group relative"
                >
                  <div className="pointer-events-none absolute -inset-6 rounded-[2rem] bg-primary/10 opacity-0 transition-opacity duration-500 group-hover:opacity-100 md:-inset-10" />

                  <div
                    className={`relative flex flex-col items-center gap-8 md:flex-row md:gap-16 ${
                      isEven ? "" : "md:flex-row-reverse"
                    }`}
                  >
                    <div className="flex-1">
                      {cookie.image_url ? (
                        <img
                          src={cookie.image_url}
                          alt={cookie.cookie_name}
                          className="mx-auto w-full max-w-md rounded-3xl object-cover shadow-lg transition-transform duration-500 group-hover:scale-105 md:max-w-lg"
                        />
                      ) : (
                        <div className="mx-auto flex h-64 w-full max-w-md items-center justify-center rounded-3xl bg-muted text-6xl shadow-lg md:max-w-lg">
                          🍪
                        </div>
                      )}
                    </div>

                    <div className={`flex-1 ${isEven ? "md:text-left" : "md:text-right"} text-center`}>
                      <span className="mb-2 inline-block rounded-full bg-primary/10 px-3 py-1 text-xs font-semibold uppercase tracking-widest text-primary">
                        {cookie.origin || "Việt Nam"}
                      </span>
                      <h3 className="mb-3 font-display text-3xl font-extrabold text-foreground md:text-4xl lg:text-5xl">
                        {cookie.cookie_name}
                      </h3>
                      <p className="mb-4 text-base leading-relaxed text-muted-foreground md:text-lg">
                        {cookie.description}
                      </p>

                      {/* Stock badge */}
                      <div className="mb-4">
                        <span className={`inline-block rounded-full px-3 py-1 text-xs font-semibold ${
                          outOfStock
                            ? "bg-destructive/10 text-destructive"
                            : cookie.stock <= 10
                            ? "bg-secondary/20 text-secondary-foreground"
                            : "bg-primary/10 text-primary"
                        }`}>
                          {outOfStock ? "Hết hàng" : cookie.stock <= 10 ? `Chỉ còn ${cookie.stock}!` : `Còn ${cookie.stock}`}
                        </span>
                      </div>

                      <div className={`flex items-center gap-4 ${isEven ? "md:justify-start" : "md:justify-end"} justify-center`}>
                        <span className="text-2xl font-bold text-primary">
                          {formatPrice(cookie.price)}
                        </span>
                        <Link
                          to="/order"
                          className={`rounded-full border-2 border-transparent bg-transparent px-6 py-2.5 text-sm font-bold transition-all duration-300 ${
                            outOfStock
                              ? "text-muted-foreground cursor-not-allowed"
                              : "text-foreground group-hover:border-foreground group-hover:bg-foreground group-hover:text-background"
                          }`}
                        >
                          {outOfStock ? "Hết hàng" : "Đặt ngay"}
                        </Link>
                      </div>
                    </div>
                  </div>

                  {/* Decorations between items */}
                  {i % 2 === 0 && (
                    <DetailedLotus className="absolute -right-4 -top-8 hidden h-16 w-20 md:block" size="sm" />
                  )}
                  {i % 2 === 1 && (
                    <LotusDecor className="absolute -left-4 -bottom-6 hidden h-12 w-16 md:block" />
                  )}
                </motion.div>
              );
            })}
          </div>
        )}
      </div>

      <VineBorder className="absolute bottom-0 left-0 opacity-60" flip />
    </section>
  );
};

export default MenuSection;
