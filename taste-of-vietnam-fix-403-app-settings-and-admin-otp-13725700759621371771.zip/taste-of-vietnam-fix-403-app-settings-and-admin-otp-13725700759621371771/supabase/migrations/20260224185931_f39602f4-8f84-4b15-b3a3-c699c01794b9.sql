
-- Create trigger to decrement voucher_templates.max_quantity when a user_voucher is marked as used
CREATE OR REPLACE FUNCTION public.decrement_voucher_quantity()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  -- Only when is_used changes from false to true
  IF NEW.is_used = true AND (OLD.is_used = false OR OLD.is_used IS NULL) AND NEW.voucher_template_id IS NOT NULL THEN
    UPDATE public.voucher_templates
    SET max_quantity = GREATEST(0, max_quantity - 1)
    WHERE id = NEW.voucher_template_id;
  END IF;
  RETURN NEW;
END;
$function$;

CREATE TRIGGER trigger_decrement_voucher_quantity
  AFTER UPDATE ON public.user_vouchers
  FOR EACH ROW
  EXECUTE FUNCTION public.decrement_voucher_quantity();

-- Also add a column to feedback to track if user dismissed the popup permanently
ALTER TABLE public.feedback ADD COLUMN IF NOT EXISTS user_id uuid;
