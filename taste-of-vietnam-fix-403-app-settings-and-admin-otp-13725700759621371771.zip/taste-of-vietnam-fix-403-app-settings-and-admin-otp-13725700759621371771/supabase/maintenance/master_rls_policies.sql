-- ==============================================================================
-- THE MASTER RLS POLICIES (BẢN CHUẨN HÓA TOÀN BỘ PHÂN QUYỀN HỆ THỐNG)
-- Đối tượng: Anon (Khách), User (Đã đăng nhập), Baker (Thợ bánh), Admin (Chủ)
-- Tác dụng: Xóa sạch mọi rác policy cũ và thiết lập lại 1 bộ Policy chuẩn duy nhất.
-- Cấm mọi xung đột, đảm bảo ai làm việc nấy.
-- ==============================================================================

-- ------------------------------------------------------------------------------
-- 1. CHUẨN BỊ HÀM VÀ QUYỀN CƠ BẢN TẦNG DATABASE
-- ------------------------------------------------------------------------------
-- Cấp quyền sử dụng cho mọi người
GRANT USAGE ON SCHEMA public TO anon, authenticated, service_role;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO anon, authenticated;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO anon, authenticated;

-- Tịch thu quyền bảng verification_codes của public (chỉ dành cho service_role)
REVOKE ALL ON public.verification_codes FROM anon, authenticated;

-- Hàm kiểm tra Role (Bọc an toàn)
CREATE OR REPLACE FUNCTION public.has_role(user_id uuid, role_name text)
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM public.user_roles ur
    WHERE ur.user_id = has_role.user_id
    AND ur.role::text = has_role.role_name
  );
EXCEPTION WHEN OTHERS THEN
  RETURN false;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

GRANT EXECUTE ON FUNCTION public.has_role(uuid, text) TO public;

-- ------------------------------------------------------------------------------
-- 2. NUKE TẤT CẢ CÁC POLICY HIỆN TẠI (LÀM SẠCH BẢNG ĐIỀU KHIỂN)
-- ------------------------------------------------------------------------------
DO $$
DECLARE
    pol RECORD;
BEGIN
    FOR pol IN SELECT policyname, tablename FROM pg_policies WHERE schemaname = 'public'
    LOOP
        EXECUTE format('DROP POLICY IF EXISTS %I ON public.%I', pol.policyname, pol.tablename);
    END LOOP;
END
$$;

-- Bật RLS mọi bảng
ALTER TABLE public.app_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.feedback ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.financial_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.monthly_menu ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_surcharges ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.page_views ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_vouchers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.verification_codes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.votes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.voucher_templates ENABLE ROW LEVEL SECURITY;

-- ------------------------------------------------------------------------------
-- 3. XÂY DỰNG MỚI THEO TỪNG BẢNG (MASTER MATRIX)
-- ------------------------------------------------------------------------------

-- ================== BẢNG `orders` (Đơn hàng) ==================
-- Khách / User: Được phép tạo (Insert)
CREATE POLICY "Ord_Public_Insert" ON public.orders FOR INSERT WITH CHECK (true);
-- Khách / User: Được phép đọc đơn CỦA MÌNH. (Hoặc đơn guest nếu tracking được cho phép).
CREATE POLICY "Ord_User_Select" ON public.orders FOR SELECT USING (auth.uid() = user_id OR user_id IS NULL);
-- User: Được phép tự Update đơn của mình (VD: hủy đơn)
CREATE POLICY "Ord_User_Update" ON public.orders FOR UPDATE USING (auth.uid() = user_id OR user_id IS NULL);
-- Baker + Admin: Xem tất cả
CREATE POLICY "Ord_Staff_Select" ON public.orders FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'baker') OR public.has_role(auth.uid(), 'admin'));
-- Baker + Admin: Update trạng thái tất cả
CREATE POLICY "Ord_Staff_Update" ON public.orders FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'baker') OR public.has_role(auth.uid(), 'admin'));
-- Admin: Quản lý (Xóa)
CREATE POLICY "Ord_Admin_Delete" ON public.orders FOR DELETE TO authenticated USING (public.has_role(auth.uid(), 'admin'));

-- ================== BẢNG `order_items` ==================
CREATE POLICY "Item_Public_Insert" ON public.order_items FOR INSERT WITH CHECK (true);
CREATE POLICY "Item_User_Select" ON public.order_items FOR SELECT USING (
    EXISTS (SELECT 1 FROM public.orders WHERE orders.id = order_items.order_id AND (orders.user_id = auth.uid() OR orders.user_id IS NULL))
);
CREATE POLICY "Item_Staff_Select" ON public.order_items FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'baker') OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Item_Admin_All" ON public.order_items FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin'));

-- ================== BẢNG `monthly_menu` (Bánh) ==================
CREATE POLICY "Menu_Public_Select" ON public.monthly_menu FOR SELECT USING (true);
-- Baker + Admin: Cập nhật, Thêm món
CREATE POLICY "Menu_Staff_Update" ON public.monthly_menu FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'baker') OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Menu_Staff_Insert" ON public.monthly_menu FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(), 'baker') OR public.has_role(auth.uid(), 'admin'));
-- Admin: Mới được xóa món
CREATE POLICY "Menu_Admin_Delete" ON public.monthly_menu FOR DELETE TO authenticated USING (public.has_role(auth.uid(), 'admin'));

-- ================== BẢNG `votes` (Bình chọn) ==================
CREATE POLICY "Vote_Public_Select" ON public.votes FOR SELECT USING (true);
-- User: Tự bình chọn
CREATE POLICY "Vote_User_Insert" ON public.votes FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
-- Admin: Quản lý toàn bộ
CREATE POLICY "Vote_Admin_All" ON public.votes FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin'));

-- ================== BẢNG `user_vouchers` (Ví voucher) ==================
CREATE POLICY "Vch_User_Select" ON public.user_vouchers FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Vch_User_Insert" ON public.user_vouchers FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
-- Cho phép thanh toán dùng voucher (Update is_used)
CREATE POLICY "Vch_User_Update" ON public.user_vouchers FOR UPDATE TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Vch_Admin_All" ON public.user_vouchers FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin'));

-- ================== BẢNG `voucher_templates` ==================
CREATE POLICY "VchTmpl_Public_Select" ON public.voucher_templates FOR SELECT USING (true);
CREATE POLICY "VchTmpl_Admin_All" ON public.voucher_templates FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin'));

-- ================== BẢNG `feedback` (Đánh giá) ==================
CREATE POLICY "FB_Public_Select" ON public.feedback FOR SELECT USING (true);
CREATE POLICY "FB_Public_Insert" ON public.feedback FOR INSERT WITH CHECK (true);
CREATE POLICY "FB_Admin_All" ON public.feedback FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin'));

-- ================== BẢNG `profiles` ==================
CREATE POLICY "Prof_Public_Select" ON public.profiles FOR SELECT USING (true);
CREATE POLICY "Prof_User_Insert" ON public.profiles FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Prof_User_Update" ON public.profiles FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Prof_Admin_All" ON public.profiles FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin'));

-- ================== BẢNG `user_roles` ==================
CREATE POLICY "Role_Public_Select" ON public.user_roles FOR SELECT USING (true);
-- Chặn Insert linh tinh, User CHỈ được cấp quyền 'user' nếu họ tự insert lần đầu
CREATE POLICY "Role_User_Insert" ON public.user_roles FOR INSERT WITH CHECK (auth.uid() = user_id AND role::text = 'user');
CREATE POLICY "Role_Admin_All" ON public.user_roles FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin'));

-- ================== BẢNG `page_views` ==================
CREATE POLICY "View_Public_Insert" ON public.page_views FOR INSERT WITH CHECK (true);
CREATE POLICY "View_Admin_Select" ON public.page_views FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));

-- ================== BẢNG `app_settings` & `order_surcharges` & `financial_transactions` ==================
CREATE POLICY "Cfg_Public_Select" ON public.app_settings FOR SELECT USING (key IN ('SOCIAL_LINKS', 'SHIPPING_ZONE_CONFIG', 'REQUIRE_ADMIN_OTP'));
CREATE POLICY "Cfg_Admin_All" ON public.app_settings FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Surch_Public_Select" ON public.order_surcharges FOR SELECT USING (true);
CREATE POLICY "Surch_Admin_All" ON public.order_surcharges FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Fin_Admin_All" ON public.financial_transactions FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin'));

-- ================== BẢNG `verification_codes` ==================
-- Chỉ dành cho Edge Function, public không thấy.
CREATE POLICY "Ver_ServiceRole_All" ON public.verification_codes FOR ALL TO service_role USING (true) WITH CHECK (true);
