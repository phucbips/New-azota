-- Script: check_admin_role.sql
-- Run this in Supabase SQL Editor to verify your permissions.

DO $$
DECLARE
  v_user_email text := 'thanhphucn4u@gmail.com';
  v_user_id uuid;
  v_role app_role;
  v_count integer;
BEGIN
  -- 1. Check if user exists in auth.users
  SELECT id INTO v_user_id FROM auth.users WHERE email = v_user_email;

  IF v_user_id IS NULL THEN
    RAISE NOTICE '❌ User % does NOT exist in auth.users.', v_user_email;
  ELSE
    RAISE NOTICE '✅ User found in auth.users with ID: %', v_user_id;

    -- 2. Check user_roles table
    SELECT count(*), role INTO v_count, v_role
    FROM public.user_roles
    WHERE user_id = v_user_id
    GROUP BY role;

    IF v_count > 0 THEN
      RAISE NOTICE '✅ User has role: % in public.user_roles.', v_role;
      IF v_role = 'admin' THEN
        RAISE NOTICE '🎉 ADMIN PERMISSION CONFIRMED.';
      ELSE
        RAISE NOTICE '⚠️ User has a role but it is NOT admin.';
      END IF;
    ELSE
      RAISE NOTICE '❌ User has NO role in public.user_roles. Please run the fix_permissions_and_rls.sql script again.';
    END IF;
  END IF;

  -- 3. Check RLS on key tables
  RAISE NOTICE 'Checking RLS status...';

  IF NOT EXISTS (SELECT 1 FROM pg_tables WHERE tablename = 'financial_transactions' AND rowsecurity = true) THEN
     RAISE NOTICE '⚠️ RLS is NOT enabled on financial_transactions!';
  ELSE
     RAISE NOTICE '✅ RLS enabled on financial_transactions.';
  END IF;

END $$;
