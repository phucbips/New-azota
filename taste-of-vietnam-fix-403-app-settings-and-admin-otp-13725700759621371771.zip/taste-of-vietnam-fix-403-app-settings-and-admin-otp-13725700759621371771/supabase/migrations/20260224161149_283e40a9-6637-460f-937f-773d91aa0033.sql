
-- =============================================
-- PHASE 2: Cải tiến bảng votes
-- =============================================

-- Thêm cột user_id vào votes
ALTER TABLE public.votes ADD COLUMN user_id uuid REFERENCES auth.users(id);

-- Thêm unique constraint: mỗi user chỉ vote 1 lần/tháng
ALTER TABLE public.votes ADD CONSTRAINT votes_user_month_unique UNIQUE (user_id, month_year);

-- Cập nhật RLS: chỉ user đã đăng nhập mới vote được
DROP POLICY IF EXISTS "Anyone can create votes" ON public.votes;
CREATE POLICY "Authenticated users can vote"
  ON public.votes FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- =============================================
-- PHASE 3: Hệ thống Voucher
-- =============================================

-- Bảng voucher templates (Admin quản lý)
CREATE TABLE public.voucher_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  type text NOT NULL CHECK (type IN ('percent', 'fixed')),
  value integer NOT NULL,
  min_order_amount integer NOT NULL DEFAULT 0,
  max_quantity integer NOT NULL DEFAULT 100,
  month_year text NOT NULL,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.voucher_templates ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view active voucher templates"
  ON public.voucher_templates FOR SELECT
  USING (true);

CREATE POLICY "Admins can insert voucher templates"
  ON public.voucher_templates FOR INSERT
  WITH CHECK (has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update voucher templates"
  ON public.voucher_templates FOR UPDATE
  USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can delete voucher templates"
  ON public.voucher_templates FOR DELETE
  USING (has_role(auth.uid(), 'admin'));

-- Bảng user vouchers (voucher đã nhận)
CREATE TABLE public.user_vouchers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id),
  voucher_template_id uuid REFERENCES public.voucher_templates(id),
  code text UNIQUE NOT NULL,
  is_used boolean NOT NULL DEFAULT false,
  used_at timestamptz,
  order_id uuid REFERENCES public.orders(id),
  expires_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.user_vouchers ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own vouchers"
  ON public.user_vouchers FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Authenticated users can claim voucher"
  ON public.user_vouchers FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can use own voucher"
  ON public.user_vouchers FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Admins can view all vouchers"
  ON public.user_vouchers FOR SELECT
  USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can manage vouchers"
  ON public.user_vouchers FOR ALL
  USING (has_role(auth.uid(), 'admin'));
