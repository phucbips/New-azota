-- ==============================================================================
-- KHÔI PHỤC QUYỀN (GRANTS) BỊ MẤT DO LỆNH NUKE
-- Sửa lỗi: 401 trên page_views và 500 trên Edge Functions (thiếu quyền Sequence)
-- ==============================================================================

-- 1. Cấp lại quyền sử dụng Schema (Rất quan trọng)
GRANT USAGE ON SCHEMA public TO postgres, anon, authenticated, service_role;

-- 2. Cấp quyền trên TẤT CẢ bảng cho service_role và postgres
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO postgres, service_role;

-- 3. Cấp quyền trên TẤT CẢ SEQUENCES (Bắt buộc để INSERT id tự tăng không bị lỗi 500)
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO postgres, service_role;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO anon, authenticated;

-- 4. Bảng page_views (Khách và User cần quyền INSERT để đếm lượt truy cập)
GRANT INSERT ON public.page_views TO anon, authenticated;
-- Admin dashboard cần quyền SELECT
GRANT SELECT ON public.page_views TO anon, authenticated;

-- Đảm bảo RLS cho page_views được bật và cấu hình đúng
ALTER TABLE public.page_views ENABLE ROW LEVEL SECURITY;

-- Xóa các policy page_views cũ nếu có
DO $$
BEGIN
    EXECUTE 'DROP POLICY IF EXISTS "Public_Insert_PageViews" ON public.page_views';
    EXECUTE 'DROP POLICY IF EXISTS "Admin_Select_PageViews" ON public.page_views';
EXCEPTION WHEN OTHERS THEN
END
$$;

-- Mọi người (cả anon) đều có thể tự do Insert lượt xem
CREATE POLICY "Public_Insert_PageViews"
ON public.page_views
FOR INSERT
WITH CHECK (true);

-- Chỉ Admin mới xem được thống kê
CREATE POLICY "Admin_Select_PageViews"
ON public.page_views
FOR SELECT
USING (public.has_role(auth.uid(), 'admin'::text));

-- ==============================================================================
-- Đảm bảo lại bảng verification_codes (cho Edge Function)
-- ==============================================================================
GRANT ALL PRIVILEGES ON public.verification_codes TO service_role;
