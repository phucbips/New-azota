import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { createHmac } from "node:crypto";
import { getRequiredEnv, corsHeaders } from "../_shared/utils.ts";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const body = await req.json();
    console.log("PayOS webhook received:", JSON.stringify(body));

    const { code, data, signature } = body;

    if (!data || !signature) {
      return new Response(JSON.stringify({ error: "Missing data or signature" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Get checksum key
    const serviceClient = createClient(
      getRequiredEnv("SUPABASE_URL"),
      getRequiredEnv("SUPABASE_SERVICE_ROLE_KEY")
    );

    const { data: settingsData } = await serviceClient
      .from("app_settings")
      .select("key, value")
      .eq("key", "PAYOS_CHECKSUM_KEY");

    const checksumKey =
      settingsData?.[0]?.value || getRequiredEnv("PAYOS_CHECKSUM_KEY");

    // Verify checksum: sort data keys alphabetically, join as key=value with &
    const sortedKeys = Object.keys(data).sort();
    const checksumStr = sortedKeys
      .map((key) => `${key}=${data[key]}`)
      .join("&");
    const computedSignature = createHmac("sha256", checksumKey)
      .update(checksumStr)
      .digest("hex");

    if (computedSignature !== signature) {
      console.error("Invalid signature", { computedSignature, signature });
      return new Response(JSON.stringify({ error: "Invalid signature" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const orderCode = data.orderCode;

    // code "00" = success, others = failed/cancelled
    if (code === "00") {
      // Payment successful
      const { error: updateError } = await serviceClient
        .from("orders")
        .update({ payment_status: "paid" })
        .eq("payos_order_code", orderCode);

      if (updateError) {
        console.error("Error updating order:", updateError);
      } else {
        console.log(`Order with payos_order_code ${orderCode} marked as paid`);
      }
    } else {
      // Payment cancelled/failed
      const { error: updateError } = await serviceClient
        .from("orders")
        .update({ payment_status: "cancelled", status: "cancelled" })
        .eq("payos_order_code", orderCode);

      if (updateError) {
        console.error("Error cancelling order:", updateError);
      } else {
        console.log(`Order with payos_order_code ${orderCode} marked as cancelled`);
      }
    }

    // Return success to PayOS
    return new Response(JSON.stringify({ success: true }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("Webhook error:", error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
