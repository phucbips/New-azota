import { useState, useEffect, useMemo, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Package, Users, BarChart3, Settings, Clock, ChefHat, Truck,
  CheckCircle2, Loader2, Search, Filter, Eye, EyeOff, RefreshCw, Mail,
  ChevronDown, CreditCard, Banknote, XCircle, Shield, UserPlus, UserMinus,
  DollarSign, TrendingUp, TrendingDown, PlusCircle, Trash2, Receipt, Ticket,
  ExternalLink, Phone, MapPin, Copy, Calendar, Tag, ShieldCheck, Palette
} from "lucide-react";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useRole } from "@/hooks/useRole";
import { formatPrice } from "@/data/mockMenu";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import {
  SidebarProvider, Sidebar, SidebarContent, SidebarGroup,
  SidebarGroupLabel, SidebarGroupContent, SidebarMenu,
  SidebarMenuItem, SidebarMenuButton, SidebarTrigger
} from "@/components/ui/sidebar";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, BarChart, Bar
} from "recharts";
import VoucherManagement from "@/components/admin/VoucherManagement";
import InterfaceSettings from "@/components/admin/InterfaceSettings";

const SOCIAL_PLATFORM_OPTIONS = [
  { value: "facebook", label: "Facebook" },
  { value: "instagram", label: "Instagram" },
  { value: "tiktok", label: "TikTok" },
  { value: "zalo", label: "Zalo" },
  { value: "youtube", label: "YouTube" },
  { value: "hotline_primary", label: "Hotline chính" },
  { value: "hotline_secondary", label: "Hotline phụ" },
  { value: "email", label: "Email" },
  { value: "map", label: "Bản đồ (Google Maps)" },
];

const DEFAULT_SOCIAL_LINKS: { platform: string; label: string; url: string }[] = [];

const DEFAULT_SHIPPING_ZONE = {
  pickup_points: [] as { name: string; address: string; lat: number; lng: number; radius_km: number }[],
};

const SecretInput = ({
  label,
  value,
  onChange,
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
}) => {
  const [show, setShow] = useState(false);
  return (
    <div>
      <label className="mb-1 block text-xs font-semibold text-muted-foreground">{label}</label>
      <div className="relative">
        <input
          type={show ? "text" : "password"}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="w-full rounded-xl border border-border bg-background px-4 py-2.5 pr-10 text-sm outline-none focus:border-primary"
          placeholder={placeholder}
        />
        <button
          type="button"
          onClick={() => setShow(!show)}
          className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
        >
          {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
        </button>
      </div>
    </div>
  );
};

// --- Sub-components for Admin Dashboard Tabs ---

const StatsTab = ({ orders }: { orders: Order[] }) => {
  const [period, setPeriod] = useState<"7d" | "30d" | "90d" | "all">("30d");
  const [userStats, setUserStats] = useState<any[]>([]);
  const [loadingUsers, setLoadingUsers] = useState(true);
  const [topCookiesMonth, setTopCookiesMonth] = useState<any[]>([]);
  const [topCookiesAll, setTopCookiesAll] = useState<any[]>([]);
  const [loadingTop, setLoadingTop] = useState(true);
  // Feedback/ratings
  const [feedbacks, setFeedbacks] = useState<any[]>([]);
  const [loadingFeedbacks, setLoadingFeedbacks] = useState(true);
  const [ratingFilter, setRatingFilter] = useState<number>(0); // 0 = all

  const stats = {
    total: orders.length,
    pending: orders.filter((o) => o.status === "pending").length,
    revenue: orders.filter((o) => o.status === "delivered").reduce((s, o) => s + o.total, 0),
    today: orders.filter((o) => new Date(o.created_at).toDateString() === new Date().toDateString()).length,
  };

  useEffect(() => {
    const fetchUserStats = async () => {
      setLoadingUsers(true);
      const { data } = await supabase
        .from("profiles")
        .select("created_at")
        .order("created_at");
      if (data) setUserStats(data);
      setLoadingUsers(false);
    };
    fetchUserStats();
  }, []);

  useEffect(() => {
    const fetchTopCookies = async () => {
      setLoadingTop(true);
      const now = new Date();
      const currentMonthYear = `${String(now.getMonth() + 1).padStart(2, "0")}/${now.getFullYear()}`;

      const [monthRes, allRes] = await Promise.all([
        supabase.rpc("get_top_cookies", { p_limit: 3, p_month_year: currentMonthYear }),
        supabase.rpc("get_top_cookies", { p_limit: 3 }),
      ]);

      if (monthRes.data) setTopCookiesMonth(monthRes.data);
      if (allRes.data) setTopCookiesAll(allRes.data);
      setLoadingTop(false);
    };
    fetchTopCookies();
  }, []);

  useEffect(() => {
    const fetchFeedbacks = async () => {
      setLoadingFeedbacks(true);
      const { data } = await supabase
        .from("feedback")
        .select("*")
        .order("created_at", { ascending: false });
      if (data) setFeedbacks(data);
      setLoadingFeedbacks(false);
    };
    fetchFeedbacks();
  }, []);

  const filteredOrders = useMemo(() => {
    if (period === "all") return orders;
    const days = period === "7d" ? 7 : period === "30d" ? 30 : 90;
    const cutoff = new Date();
    cutoff.setDate(cutoff.getDate() - days);
    return orders.filter((o) => new Date(o.created_at) >= cutoff);
  }, [orders, period]);

  const revenueChartData = useMemo(() => {
    const delivered = filteredOrders.filter((o) => o.status === "delivered");
    const map: Record<string, number> = {};
    delivered.forEach((o) => {
      const day = new Date(o.created_at).toLocaleDateString("vi-VN", { day: "2-digit", month: "2-digit" });
      map[day] = (map[day] || 0) + o.total;
    });
    return Object.entries(map).map(([date, revenue]) => ({ date, revenue }));
  }, [filteredOrders]);

  const userChartData = useMemo(() => {
    if (!userStats.length) return [];
    const cutoff = period === "all" ? null : new Date();
    if (cutoff) {
      const days = period === "7d" ? 7 : period === "30d" ? 30 : 90;
      cutoff.setDate(cutoff.getDate() - days);
    }
    const filtered = cutoff ? userStats.filter((u) => new Date(u.created_at) >= cutoff) : userStats;
    const map: Record<string, number> = {};
    filtered.forEach((u) => {
      const day = new Date(u.created_at).toLocaleDateString("vi-VN", { day: "2-digit", month: "2-digit" });
      map[day] = (map[day] || 0) + 1;
    });
    return Object.entries(map).map(([date, count]) => ({ date, count }));
  }, [userStats, period]);

  return (
    <div className="space-y-6">
      {/* Period filter */}
      <div className="flex gap-2">
        {([["7d", "7 ngày"], ["30d", "30 ngày"], ["90d", "3 tháng"], ["all", "Toàn bộ"]] as const).map(([p, label]) => (
          <button
            key={p}
            onClick={() => setPeriod(p)}
            className={`rounded-full px-4 py-1.5 text-xs font-semibold transition-colors ${
              period === p ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:bg-muted/80"
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        {[
          { label: "Tổng đơn", value: stats.total, icon: Package, color: "text-foreground" },
          { label: "Chờ xử lý", value: stats.pending, icon: Clock, color: "text-yellow-600" },
          { label: "Hôm nay", value: stats.today, icon: BarChart3, color: "text-blue-500" },
          { label: "Doanh thu", value: formatPrice(stats.revenue), icon: CheckCircle2, color: "text-primary" },
        ].map((s) => (
          <div key={s.label} className="rounded-2xl border border-border bg-card p-5">
            <div className="flex items-center gap-2 mb-2">
              <s.icon className={`h-5 w-5 ${s.color}`} />
              <span className="text-xs font-semibold text-muted-foreground">{s.label}</span>
            </div>
            <p className={`font-display text-2xl font-extrabold ${s.color}`}>{s.value}</p>
          </div>
        ))}
      </div>

      {/* Revenue chart */}
      <div className="rounded-2xl border border-border bg-card p-6">
        <h3 className="mb-4 font-display text-lg font-bold text-foreground">📈 Doanh thu theo ngày</h3>
        {revenueChartData.length > 0 ? (
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={revenueChartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="date" tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" />
              <YAxis tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" tickFormatter={(v) => `${(v / 1000).toFixed(0)}k`} />
              <Tooltip formatter={(v: number) => formatPrice(v)} />
              <Bar dataKey="revenue" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} name="Doanh thu" />
            </BarChart>
          </ResponsiveContainer>
        ) : (
          <p className="text-center text-sm text-muted-foreground py-8">Chưa có dữ liệu doanh thu</p>
        )}
      </div>

      {/* User growth chart */}
      <div className="rounded-2xl border border-border bg-card p-6">
        <h3 className="mb-4 font-display text-lg font-bold text-foreground">👥 Người dùng mới theo ngày</h3>
        {loadingUsers ? (
          <div className="flex justify-center py-8"><Loader2 className="h-5 w-5 animate-spin text-primary" /></div>
        ) : userChartData.length > 0 ? (
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={userChartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="date" tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" />
              <YAxis tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" allowDecimals={false} />
              <Tooltip />
              <Line type="monotone" dataKey="count" stroke="hsl(var(--primary))" strokeWidth={2} dot={{ r: 3 }} name="Người dùng mới" />
            </LineChart>
          </ResponsiveContainer>
        ) : (
          <p className="text-center text-sm text-muted-foreground py-8">Chưa có dữ liệu</p>
        )}
      </div>

      {/* Top sản phẩm */}
      <div className="rounded-2xl border border-border bg-card p-6">
        <h3 className="mb-4 font-display text-lg font-bold text-foreground">🏆 Top sản phẩm bán chạy</h3>
        {loadingTop ? (
          <div className="flex justify-center py-8"><Loader2 className="h-5 w-5 animate-spin text-primary" /></div>
        ) : (
          <div className="grid gap-6 md:grid-cols-2">
            {/* This month */}
            <div>
              <p className="mb-3 text-sm font-semibold text-muted-foreground">📅 Tháng này</p>
              {topCookiesMonth.length > 0 ? (
                <div className={`grid gap-3 ${topCookiesMonth.length === 1 ? "grid-cols-1 max-w-xs" : topCookiesMonth.length === 2 ? "grid-cols-2" : "grid-cols-1"}`}>
                  {topCookiesMonth.map((c: any, i: number) => {
                    const medals = ["🥇", "🥈", "🥉"];
                    return (
                      <div key={c.cookie_name} className="flex items-center gap-3 rounded-xl border border-border bg-background p-3">
                        <span className="text-xl">{medals[i]}</span>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-bold text-foreground truncate">{c.cookie_name}</p>
                          <p className="text-xs text-muted-foreground">
                            {c.total_sold} đã bán
                            {c.avg_rating > 0 && ` · ⭐ ${Number(c.avg_rating).toFixed(1)}`}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">Chưa có dữ liệu tháng này</p>
              )}
            </div>

            {/* All time */}
            <div>
              <p className="mb-3 text-sm font-semibold text-muted-foreground">📊 Toàn thời gian</p>
              {topCookiesAll.length > 0 ? (
                <div className={`grid gap-3 ${topCookiesAll.length === 1 ? "grid-cols-1 max-w-xs" : topCookiesAll.length === 2 ? "grid-cols-2" : "grid-cols-1"}`}>
                  {topCookiesAll.map((c: any, i: number) => {
                    const medals = ["🥇", "🥈", "🥉"];
                    return (
                      <div key={c.cookie_name} className="flex items-center gap-3 rounded-xl border border-border bg-background p-3">
                        <span className="text-xl">{medals[i]}</span>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-bold text-foreground truncate">{c.cookie_name}</p>
                          <p className="text-xs text-muted-foreground">
                            {c.total_sold} đã bán
                            {c.avg_rating > 0 && ` · ⭐ ${Number(c.avg_rating).toFixed(1)}`}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">Chưa có dữ liệu</p>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Order distribution */}
      <div className="rounded-2xl border border-border bg-card p-6">
        <h3 className="mb-4 font-display text-lg font-bold text-foreground">Phân bổ đơn hàng</h3>
        <div className="space-y-3">
          {STATUSES.map((s) => {
            const count = orders.filter((o) => o.status === s).length;
            const pct = orders.length ? Math.round((count / orders.length) * 100) : 0;
            const si = STATUS_MAP[s];
            return (
              <div key={s}>
                <div className="mb-1 flex justify-between text-sm">
                  <span className="text-muted-foreground">{si.label}</span>
                  <span className="font-semibold text-foreground">{count} ({pct}%)</span>
                </div>
                <div className="h-2 rounded-full bg-muted">
                  <div className="h-2 rounded-full bg-primary transition-all" style={{ width: `${pct}%` }} />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Customer Ratings - CH Play style */}
      <div className="rounded-2xl border border-border bg-card p-6">
        <h3 className="mb-4 font-display text-lg font-bold text-foreground">⭐ Đánh giá khách hàng</h3>
        {loadingFeedbacks ? (
          <div className="flex justify-center py-8"><Loader2 className="h-5 w-5 animate-spin text-primary" /></div>
        ) : feedbacks.length === 0 ? (
          <p className="text-center text-sm text-muted-foreground py-8">Chưa có đánh giá nào</p>
        ) : (() => {
          const avgRating = feedbacks.reduce((s, f) => s + f.rating, 0) / feedbacks.length;
          const ratingCounts = [5, 4, 3, 2, 1].map((star) => ({
            star,
            count: feedbacks.filter((f) => f.rating === star).length,
          }));
          const filteredFeedbacks = ratingFilter === 0
            ? feedbacks
            : feedbacks.filter((f) => f.rating === ratingFilter);

          return (
            <div className="space-y-6">
              {/* Summary */}
              <div className="flex gap-6 items-start">
                <div className="text-center">
                  <p className="font-display text-5xl font-extrabold text-foreground">{avgRating.toFixed(1)}</p>
                  <div className="mt-1 flex justify-center gap-0.5">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <span key={star} className={`text-lg ${star <= Math.round(avgRating) ? "text-primary" : "text-muted-foreground/30"}`}>★</span>
                    ))}
                  </div>
                  <p className="mt-1 text-xs text-muted-foreground">{feedbacks.length} đánh giá</p>
                </div>
                <div className="flex-1 space-y-1.5">
                  {ratingCounts.map(({ star, count }) => {
                    const pct = feedbacks.length ? Math.round((count / feedbacks.length) * 100) : 0;
                    return (
                      <div key={star} className="flex items-center gap-2 text-sm">
                        <span className="w-4 text-right font-semibold text-foreground">{star}</span>
                        <span className="text-primary">★</span>
                        <div className="flex-1 h-2 rounded-full bg-muted overflow-hidden">
                          <div className="h-full rounded-full bg-primary transition-all" style={{ width: `${pct}%` }} />
                        </div>
                        <span className="w-8 text-right text-xs text-muted-foreground">{count}</span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Filter tabs */}
              <div className="flex gap-2 flex-wrap">
                {[{ label: "Tất cả", value: 0 }, ...([5, 4, 3, 2, 1].map((s) => ({ label: `${s} ★`, value: s })))].map((f) => (
                  <button
                    key={f.value}
                    onClick={() => setRatingFilter(f.value)}
                    className={`rounded-full px-3 py-1.5 text-xs font-semibold transition-colors ${
                      ratingFilter === f.value
                        ? "bg-primary text-primary-foreground"
                        : "bg-muted text-muted-foreground hover:bg-muted/80"
                    }`}
                  >
                    {f.label}
                    {f.value > 0 && (
                      <span className="ml-1 opacity-70">({ratingCounts.find((r) => r.star === f.value)?.count || 0})</span>
                    )}
                  </button>
                ))}
              </div>

              {/* Reviews list */}
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {filteredFeedbacks.length === 0 ? (
                  <p className="text-center text-sm text-muted-foreground py-4">Không có đánh giá {ratingFilter} sao</p>
                ) : (
                  filteredFeedbacks.map((f) => (
                    <div key={f.id} className="rounded-xl border border-border bg-background p-4">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10 text-xs font-bold text-primary">
                            {(f.customer_name || "?").charAt(0).toUpperCase()}
                          </div>
                          <div>
                            <p className="text-sm font-semibold text-foreground">{f.customer_name || "Ẩn danh"}</p>
                            <p className="text-[10px] text-muted-foreground">
                              {new Date(f.created_at).toLocaleDateString("vi-VN")} · #{f.order_code}
                            </p>
                          </div>
                        </div>
                        <div className="flex gap-0.5">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <span key={star} className={`text-sm ${star <= f.rating ? "text-primary" : "text-muted-foreground/30"}`}>★</span>
                          ))}
                        </div>
                      </div>
                      {f.comment && (
                        <p className="text-sm text-foreground leading-relaxed">{f.comment}</p>
                      )}
                    </div>
                  ))
                )}
              </div>
            </div>
          );
        })()}
      </div>
    </div>
  );
};

const FinanceTab = () => {
  const [transactions, setTransactions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ type: "expense", category: "ingredient", amount: 0, description: "" });
  const [saving, setSaving] = useState(false);
  const [filterType, setFilterType] = useState<string>("all");
  const [timePeriod, setTimePeriod] = useState<"today" | "week" | "month" | "all">("all");
  const { user } = useAuth();

  const fetchTransactions = async () => {
    setLoading(true);
    const { data } = await supabase
      .from("financial_transactions")
      .select("*")
      .order("created_at", { ascending: false });
    if (data) setTransactions(data);
    setLoading(false);
  };

  useEffect(() => { fetchTransactions(); }, []);

  const addTransaction = async () => {
    if (!form.amount || !form.description.trim()) return;
    setSaving(true);
    await supabase.from("financial_transactions").insert({
      type: form.type,
      category: form.category,
      amount: form.amount,
      description: form.description.trim(),
      created_by: user?.id,
    } as any);
    setForm({ type: "expense", category: "ingredient", amount: 0, description: "" });
    setShowForm(false);
    fetchTransactions();
    setSaving(false);
  };

  const deleteTransaction = async (id: string) => {
    if (!confirm("Xóa giao dịch này?")) return;
    await supabase.from("financial_transactions").delete().eq("id", id);
    setTransactions((prev) => prev.filter((t) => t.id !== id));
  };

  const timeFiltered = useMemo(() => {
    if (timePeriod === "all") return transactions;
    const now = new Date();
    const start = new Date();
    if (timePeriod === "today") {
      start.setHours(0, 0, 0, 0);
    } else if (timePeriod === "week") {
      start.setDate(now.getDate() - now.getDay());
      start.setHours(0, 0, 0, 0);
    } else if (timePeriod === "month") {
      start.setDate(1);
      start.setHours(0, 0, 0, 0);
    }
    return transactions.filter((t) => new Date(t.created_at) >= start);
  }, [transactions, timePeriod]);

  const filtered = filterType === "all" ? timeFiltered : timeFiltered.filter((t) => t.type === filterType);
  const totalIncome = timeFiltered.filter((t) => t.type === "income").reduce((s, t) => s + t.amount, 0);
  const totalExpense = timeFiltered.filter((t) => t.type === "expense").reduce((s, t) => s + t.amount, 0);

  const categoryLabels: Record<string, string> = {
    order_revenue: "Doanh thu đơn hàng",
    ingredient: "Nguyên liệu",
    capital: "Tiền vốn",
    other: "Khác",
  };

  return (
    <div className="space-y-6">
      {/* Summary */}
      <div className="grid grid-cols-3 gap-4">
        <div className="rounded-2xl border border-border bg-card p-5">
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp className="h-5 w-5 text-primary" />
            <span className="text-xs font-semibold text-muted-foreground">Tổng thu</span>
          </div>
          <p className="font-display text-2xl font-extrabold text-primary">{formatPrice(totalIncome)}</p>
        </div>
        <div className="rounded-2xl border border-border bg-card p-5">
          <div className="flex items-center gap-2 mb-2">
            <TrendingDown className="h-5 w-5 text-destructive" />
            <span className="text-xs font-semibold text-muted-foreground">Tổng chi</span>
          </div>
          <p className="font-display text-2xl font-extrabold text-destructive">{formatPrice(totalExpense)}</p>
        </div>
        <div className="rounded-2xl border border-border bg-card p-5">
          <div className="flex items-center gap-2 mb-2">
            <DollarSign className="h-5 w-5 text-foreground" />
            <span className="text-xs font-semibold text-muted-foreground">Lợi nhuận ròng</span>
          </div>
          <p className={`font-display text-2xl font-extrabold ${totalIncome - totalExpense >= 0 ? "text-primary" : "text-destructive"}`}>
            {formatPrice(totalIncome - totalExpense)}
          </p>
        </div>
      </div>

      {/* Time period filter */}
      <div className="flex gap-2 flex-wrap">
        {([["today", "Hôm nay"], ["week", "Tuần này"], ["month", "Tháng này"], ["all", "Tất cả"]] as const).map(([p, label]) => (
          <button
            key={p}
            onClick={() => setTimePeriod(p)}
            className={`rounded-full px-4 py-1.5 text-xs font-semibold transition-colors ${
              timePeriod === p ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:bg-muted/80"
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {/* Actions */}
      <div className="flex items-center gap-3">
        <button
          onClick={() => setShowForm(!showForm)}
          className="flex items-center gap-2 rounded-full bg-primary px-5 py-2.5 text-sm font-bold text-primary-foreground hover:scale-105 transition-transform"
        >
          <PlusCircle className="h-4 w-4" /> Thêm giao dịch
        </button>
        <div className="flex gap-2">
          {[["all", "Tất cả"], ["income", "Thu"], ["expense", "Chi"]].map(([val, label]) => (
            <button
              key={val}
              onClick={() => setFilterType(val)}
              className={`rounded-full px-3 py-1.5 text-xs font-semibold transition-colors ${
                filterType === val ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
              }`}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* Add form */}
      {showForm && (
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="rounded-2xl border border-primary/20 bg-card p-6">
          <h3 className="mb-4 font-display text-lg font-bold text-foreground">Thêm giao dịch</h3>
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="mb-1 block text-xs font-semibold text-muted-foreground">Loại</label>
              <select
                value={form.type}
                onChange={(e) => setForm((p) => ({ ...p, type: e.target.value }))}
                className="w-full rounded-xl border border-border bg-background px-3 py-2 text-sm outline-none focus:border-primary"
              >
                <option value="income">Thu nhập</option>
                <option value="expense">Chi phí</option>
              </select>
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold text-muted-foreground">Danh mục</label>
              <select
                value={form.category}
                onChange={(e) => setForm((p) => ({ ...p, category: e.target.value }))}
                className="w-full rounded-xl border border-border bg-background px-3 py-2 text-sm outline-none focus:border-primary"
              >
                <option value="order_revenue">Doanh thu đơn hàng</option>
                <option value="ingredient">Nguyên liệu</option>
                <option value="capital">Tiền vốn</option>
                <option value="other">Khác</option>
              </select>
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold text-muted-foreground">Số tiền (VNĐ)</label>
              <input
                type="number"
                value={form.amount || ""}
                onChange={(e) => setForm((p) => ({ ...p, amount: Number(e.target.value) }))}
                className="w-full rounded-xl border border-border bg-background px-3 py-2 text-sm outline-none focus:border-primary"
                placeholder="0"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold text-muted-foreground">Mô tả</label>
              <input
                type="text"
                value={form.description}
                onChange={(e) => setForm((p) => ({ ...p, description: e.target.value }))}
                className="w-full rounded-xl border border-border bg-background px-3 py-2 text-sm outline-none focus:border-primary"
                placeholder="Mua bột mì, đường..."
              />
            </div>
          </div>
          <div className="mt-4 flex gap-2">
            <button onClick={addTransaction} disabled={saving} className="rounded-full bg-primary px-6 py-2.5 text-sm font-bold text-primary-foreground">
              {saving ? "Đang lưu..." : "Lưu"}
            </button>
            <button onClick={() => setShowForm(false)} className="rounded-full border border-border px-6 py-2.5 text-sm font-bold text-muted-foreground">
              Hủy
            </button>
          </div>
        </motion.div>
      )}

      {/* Transactions list */}
      {loading ? (
        <div className="flex justify-center py-20"><Loader2 className="h-6 w-6 animate-spin text-primary" /></div>
      ) : filtered.length === 0 ? (
        <div className="rounded-2xl border border-border bg-card p-10 text-center text-muted-foreground">Chưa có giao dịch nào</div>
      ) : (
        <div className="space-y-2">
          {filtered.map((t) => (
            <div key={t.id} className="flex items-center justify-between rounded-2xl border border-border bg-card p-4">
              <div className="flex items-center gap-3">
                <div className={`flex h-10 w-10 items-center justify-center rounded-full ${t.type === "income" ? "bg-primary/10" : "bg-destructive/10"}`}>
                  {t.type === "income" ? <TrendingUp className="h-5 w-5 text-primary" /> : <TrendingDown className="h-5 w-5 text-destructive" />}
                </div>
                <div>
                  <p className="text-sm font-semibold text-foreground">{t.description}</p>
                  <p className="text-xs text-muted-foreground">
                    {categoryLabels[t.category] || t.category} · {new Date(t.created_at).toLocaleDateString("vi-VN")}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <span className={`font-bold ${t.type === "income" ? "text-primary" : "text-destructive"}`}>
                  {t.type === "income" ? "+" : "-"}{formatPrice(t.amount)}
                </span>
                <button onClick={() => deleteTransaction(t.id)} className="rounded-lg p-1.5 text-muted-foreground hover:bg-destructive/10 hover:text-destructive">
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

const UsersTab = () => {
  const [users, setUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchUsers = async () => {
      const { data, error } = await supabase
        .from("profiles")
        .select("*")
        .order("created_at", { ascending: false });
      if (!error && data) {
        const userIds = data.map((p) => p.user_id);
        const { data: rolesData } = await supabase
          .from("user_roles")
          .select("*")
          .in("user_id", userIds);

        const usersWithRoles = data.map((p) => ({
          ...p,
          roles: rolesData?.filter((r) => r.user_id === p.user_id).map((r) => r.role) || [],
        }));
        setUsers(usersWithRoles);
      }
      setLoading(false);
    };
    fetchUsers();
  }, []);

  if (loading) {
    return (
      <div className="flex justify-center py-20">
        <Loader2 className="h-6 w-6 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <p className="text-sm text-muted-foreground">{users.length} người dùng</p>
      {users.map((u) => (
        <div key={u.id} className="flex items-center justify-between rounded-2xl border border-border bg-card p-4">
          <div>
            <p className="font-semibold text-foreground">{u.full_name || "Chưa cập nhật"}</p>
            <p className="text-xs text-muted-foreground">{u.phone || "—"} · {u.default_address || "—"}</p>
          </div>
          <div className="flex gap-1">
            {u.roles.map((r: string) => (
              <span
                key={r}
                className={`rounded-full px-2.5 py-0.5 text-xs font-semibold ${
                  r === "admin" ? "bg-destructive/10 text-destructive" :
                  r === "baker" ? "bg-secondary/20 text-secondary-foreground" :
                  "bg-muted text-muted-foreground"
                }`}
              >
                {r}
              </span>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
};

const RolesTab = () => {
  const [users, setUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [updating, setUpdating] = useState<string | null>(null);

  const fetchUsers = async () => {
    setLoading(true);
    const { data: profiles } = await supabase
      .from("profiles")
      .select("*")
      .order("created_at", { ascending: false });
    if (profiles) {
      const userIds = profiles.map((p) => p.user_id);
      const { data: rolesData } = await supabase
        .from("user_roles")
        .select("*")
        .in("user_id", userIds);
      const usersWithRoles = profiles.map((p) => ({
        ...p,
        roles: rolesData?.filter((r) => r.user_id === p.user_id).map((r) => r.role) || [],
      }));
      setUsers(usersWithRoles);
    }
    setLoading(false);
  };

  useEffect(() => { fetchUsers(); }, []);

  const toggleBakerRole = async (userId: string, hasBaker: boolean) => {
    setUpdating(userId);
    try {
      if (hasBaker) {
        await supabase.from("user_roles").delete().eq("user_id", userId).eq("role", "baker");
      } else {
        await supabase.from("user_roles").insert({ user_id: userId, role: "baker" as any });
      }
      await fetchUsers();
    } catch (e) {
      console.error(e);
    }
    setUpdating(null);
  };

  if (loading) {
    return (
      <div className="flex justify-center py-20">
        <Loader2 className="h-6 w-6 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <p className="text-sm text-muted-foreground">
        Cấp hoặc thu hồi quyền <span className="font-bold text-secondary-foreground">Baker</span> cho người dùng.
      </p>
      <div className="space-y-3">
        {users.map((u) => {
          const hasBaker = u.roles.includes("baker");
          const isAdminUser = u.roles.includes("admin");
          return (
            <motion.div
              key={u.id}
              initial={{ opacity: 0, y: 5 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex items-center justify-between rounded-2xl border border-border bg-card p-4"
            >
              <div>
                <p className="font-semibold text-foreground">{u.full_name || "Chưa cập nhật"}</p>
                <p className="text-xs text-muted-foreground">{u.phone || "—"}</p>
                <div className="mt-1 flex gap-1">
                  {u.roles.map((r: string) => (
                    <span
                      key={r}
                      className={`rounded-full px-2.5 py-0.5 text-xs font-semibold ${
                        r === "admin" ? "bg-destructive/10 text-destructive" :
                        r === "baker" ? "bg-secondary/20 text-secondary-foreground" :
                        "bg-muted text-muted-foreground"
                      }`}
                    >
                      {r}
                    </span>
                  ))}
                </div>
              </div>
              {!isAdminUser && (
                <button
                  onClick={() => toggleBakerRole(u.user_id, hasBaker)}
                  disabled={updating === u.user_id}
                  className={`flex items-center gap-2 rounded-full px-4 py-2 text-sm font-bold transition-all ${
                    hasBaker
                      ? "bg-destructive/10 text-destructive hover:bg-destructive/20"
                      : "bg-primary/10 text-primary hover:bg-primary/20"
                  } disabled:opacity-50`}
                >
                  {updating === u.user_id ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : hasBaker ? (
                    <><UserMinus className="h-4 w-4" /> Thu hồi Baker</>
                  ) : (
                    <><UserPlus className="h-4 w-4" /> Cấp quyền Baker</>
                  )}
                </button>
              )}
            </motion.div>
          );
        })}
      </div>
    </div>
  );
};

const SurchargesTab = () => {
  const [surcharges, setSurcharges] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: "", type: "fixed", value: 0, is_active: true, is_default: false });
  const [saving, setSaving] = useState(false);

  const fetchSurcharges = async () => {
    setLoading(true);
    const { data } = await supabase.from("order_surcharges").select("*").order("created_at");
    if (data) setSurcharges(data);
    setLoading(false);
  };

  useEffect(() => { fetchSurcharges(); }, []);

  const addSurcharge = async () => {
    if (!form.name.trim()) return;
    setSaving(true);
    await supabase.from("order_surcharges").insert(form as any);
    setForm({ name: "", type: "fixed", value: 0, is_active: true, is_default: false });
    setShowForm(false);
    fetchSurcharges();
    setSaving(false);
  };

  const toggleActive = async (id: string, currentValue: boolean) => {
    const { error } = await supabase.from("order_surcharges").update({ is_active: !currentValue } as any).eq("id", id);
    if (error) {
      toast.error("Không thể cập nhật trạng thái: " + error.message);
      console.error(error);
      return;
    }
    setSurcharges((prev) => prev.map((s) => s.id === id ? { ...s, is_active: !currentValue } : s));
  };

  const updateValue = async (id: string, newValue: number) => {
    const { error } = await supabase.from("order_surcharges").update({ value: newValue } as any).eq("id", id);
    if (error) {
      toast.error("Không thể cập nhật giá trị: " + error.message);
      console.error(error);
      return;
    }
    setSurcharges((prev) => prev.map((s) => s.id === id ? { ...s, value: newValue } : s));
  };

  const deleteSurcharge = async (id: string) => {
    if (!confirm("Xóa phụ phí này?")) return;
    await supabase.from("order_surcharges").delete().eq("id", id);
    setSurcharges((prev) => prev.filter((s) => s.id !== id));
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <button
          onClick={() => setShowForm(!showForm)}
          className="flex items-center gap-2 rounded-full bg-primary px-5 py-2.5 text-sm font-bold text-primary-foreground hover:scale-105 transition-transform"
        >
          <PlusCircle className="h-4 w-4" /> Thêm phụ phí
        </button>
      </div>

      {showForm && (
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="rounded-2xl border border-primary/20 bg-card p-6">
          <h3 className="mb-4 font-display text-lg font-bold text-foreground">Thêm phụ phí mới</h3>
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="mb-1 block text-xs font-semibold text-muted-foreground">Tên phụ phí</label>
              <input
                type="text"
                value={form.name}
                onChange={(e) => setForm((p) => ({ ...p, name: e.target.value }))}
                className="w-full rounded-xl border border-border bg-background px-3 py-2 text-sm outline-none focus:border-primary"
                placeholder="VD: Phí đóng gói"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold text-muted-foreground">Loại</label>
              <select
                value={form.type}
                onChange={(e) => setForm((p) => ({ ...p, type: e.target.value }))}
                className="w-full rounded-xl border border-border bg-background px-3 py-2 text-sm outline-none focus:border-primary"
              >
                <option value="fixed">Cố định (VNĐ)</option>
                <option value="percent">Phần trăm (%)</option>
              </select>
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold text-muted-foreground">Giá trị</label>
              <input
                type="number"
                value={form.value || ""}
                onChange={(e) => setForm((p) => ({ ...p, value: Number(e.target.value) }))}
                className="w-full rounded-xl border border-border bg-background px-3 py-2 text-sm outline-none focus:border-primary"
                placeholder={form.type === "fixed" ? "15000" : "5"}
              />
            </div>
            <div className="flex items-center gap-4 pt-5">
              <label className="flex items-center gap-2 text-sm">
                <input type="checkbox" checked={form.is_default} onChange={(e) => setForm((p) => ({ ...p, is_default: e.target.checked }))} className="rounded" />
                Mặc định
              </label>
              <label className="flex items-center gap-2 text-sm">
                <input type="checkbox" checked={form.is_active} onChange={(e) => setForm((p) => ({ ...p, is_active: e.target.checked }))} className="rounded" />
                Đang hoạt động
              </label>
            </div>
          </div>
          <div className="mt-4 flex gap-2">
            <button onClick={addSurcharge} disabled={saving} className="rounded-full bg-primary px-6 py-2.5 text-sm font-bold text-primary-foreground">
              {saving ? "Đang lưu..." : "Lưu"}
            </button>
            <button onClick={() => setShowForm(false)} className="rounded-full border border-border px-6 py-2.5 text-sm font-bold text-muted-foreground">Hủy</button>
          </div>
        </motion.div>
      )}

      {loading ? (
        <div className="flex justify-center py-20"><Loader2 className="h-6 w-6 animate-spin text-primary" /></div>
      ) : surcharges.length === 0 ? (
        <div className="rounded-2xl border border-border bg-card p-10 text-center text-muted-foreground">Chưa có phụ phí nào</div>
      ) : (
        <div className="space-y-3">
          {surcharges.map((s) => (
            <div key={s.id} className="flex items-center justify-between rounded-2xl border border-border bg-card p-4">
              <div className="flex items-center gap-3">
                <div className={`h-3 w-3 rounded-full ${s.is_active ? "bg-primary" : "bg-muted-foreground/30"}`} />
                <div>
                  <p className="text-sm font-semibold text-foreground">{s.name}</p>
                  <p className="text-xs text-muted-foreground">
                    {s.type === "fixed" ? formatPrice(s.value) : `${s.value}%`}
                    {s.is_default && " · Mặc định"}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  value={s.value}
                  onChange={(e) => updateValue(s.id, Number(e.target.value))}
                  className="w-24 rounded-lg border border-border bg-background px-2 py-1 text-sm text-right outline-none focus:border-primary"
                />
                <button
                  onClick={() => toggleActive(s.id, s.is_active)}
                  className={`rounded-lg px-3 py-1.5 text-xs font-semibold ${s.is_active ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground"}`}
                >
                  {s.is_active ? "Bật" : "Tắt"}
                </button>
                <button onClick={() => deleteSurcharge(s.id)} className="rounded-lg p-1.5 text-muted-foreground hover:bg-destructive/10 hover:text-destructive">
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

const AnalyticsTab = () => {
  const [pageViews, setPageViews] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [period, setPeriod] = useState<"today" | "week" | "month" | "all">("month");

  useEffect(() => {
    const fetchViews = async () => {
      setLoading(true);
      const { data } = await supabase
        .from("page_views")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(1000);
      if (data) setPageViews(data);
      setLoading(false);
    };
    fetchViews();
  }, []);

  const filtered = useMemo(() => {
    if (period === "all") return pageViews;
    const now = new Date();
    const start = new Date();
    if (period === "today") {
      start.setHours(0, 0, 0, 0);
    } else if (period === "week") {
      start.setDate(now.getDate() - now.getDay());
      start.setHours(0, 0, 0, 0);
    } else if (period === "month") {
      start.setDate(1);
      start.setHours(0, 0, 0, 0);
    }
    return pageViews.filter((v) => new Date(v.created_at) >= start);
  }, [pageViews, period]);

  const uniqueVisitors = useMemo(() => {
    const agents = new Set(filtered.map((v) => v.user_agent));
    return agents.size;
  }, [filtered]);

  const deviceStats = useMemo(() => {
    const map: Record<string, number> = {};
    filtered.forEach((v) => {
      const d = v.device_type || "Unknown";
      map[d] = (map[d] || 0) + 1;
    });
    return Object.entries(map).sort((a, b) => b[1] - a[1]);
  }, [filtered]);

  const browserStats = useMemo(() => {
    const map: Record<string, number> = {};
    filtered.forEach((v) => {
      const b = v.browser || "Unknown";
      map[b] = (map[b] || 0) + 1;
    });
    return Object.entries(map).sort((a, b) => b[1] - a[1]);
  }, [filtered]);

  const pageStats = useMemo(() => {
    const map: Record<string, number> = {};
    filtered.forEach((v) => {
      map[v.path] = (map[v.path] || 0) + 1;
    });
    return Object.entries(map).sort((a, b) => b[1] - a[1]);
  }, [filtered]);

  const dailyViews = useMemo(() => {
    const map: Record<string, number> = {};
    filtered.forEach((v) => {
      const day = new Date(v.created_at).toLocaleDateString("vi-VN", { day: "2-digit", month: "2-digit" });
      map[day] = (map[day] || 0) + 1;
    });
    return Object.entries(map).map(([date, views]) => ({ date, views }));
  }, [filtered]);

  const pathLabels: Record<string, string> = {
    "/": "Trang chủ",
    "/order": "Đặt hàng",
    "/ranking": "Bình chọn",
    "/auth": "Đăng nhập",
    "/orders": "Lịch sử đơn",
    "/admin": "Admin",
    "/baker": "Baker",
    "/profile": "Hồ sơ",
  };

  if (loading) {
    return <div className="flex justify-center py-20"><Loader2 className="h-6 w-6 animate-spin text-primary" /></div>;
  }

  return (
    <div className="space-y-6">
      {/* Period filter */}
      <div className="flex gap-2">
        {([["today", "Hôm nay"], ["week", "Tuần này"], ["month", "Tháng này"], ["all", "Tất cả"]] as const).map(([p, label]) => (
          <button
            key={p}
            onClick={() => setPeriod(p)}
            className={`rounded-full px-4 py-1.5 text-xs font-semibold transition-colors ${
              period === p ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:bg-muted/80"
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        <div className="rounded-2xl border border-border bg-card p-5">
          <div className="flex items-center gap-2 mb-2">
            <Eye className="h-5 w-5 text-primary" />
            <span className="text-xs font-semibold text-muted-foreground">Lượt xem</span>
          </div>
          <p className="font-display text-2xl font-extrabold text-primary">{filtered.length}</p>
        </div>
        <div className="rounded-2xl border border-border bg-card p-5">
          <div className="flex items-center gap-2 mb-2">
            <Users className="h-5 w-5 text-blue-500" />
            <span className="text-xs font-semibold text-muted-foreground">Khách truy cập</span>
          </div>
          <p className="font-display text-2xl font-extrabold text-blue-500">{uniqueVisitors}</p>
        </div>
        <div className="rounded-2xl border border-border bg-card p-5">
          <div className="flex items-center gap-2 mb-2">
            <BarChart3 className="h-5 w-5 text-foreground" />
            <span className="text-xs font-semibold text-muted-foreground">Trang phổ biến</span>
          </div>
          <p className="font-display text-lg font-extrabold text-foreground">{pageStats[0]?.[0] ? (pathLabels[pageStats[0][0]] || pageStats[0][0]) : "—"}</p>
        </div>
        <div className="rounded-2xl border border-border bg-card p-5">
          <div className="flex items-center gap-2 mb-2">
            <Package className="h-5 w-5 text-foreground" />
            <span className="text-xs font-semibold text-muted-foreground">Thiết bị chính</span>
          </div>
          <p className="font-display text-lg font-extrabold text-foreground">{deviceStats[0]?.[0] || "—"}</p>
        </div>
      </div>

      {/* Daily views chart */}
      <div className="rounded-2xl border border-border bg-card p-6">
        <h3 className="mb-4 font-display text-lg font-bold text-foreground">📊 Lượt xem theo ngày</h3>
        {dailyViews.length > 0 ? (
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={dailyViews}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="date" tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" />
              <YAxis tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" allowDecimals={false} />
              <Tooltip />
              <Bar dataKey="views" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} name="Lượt xem" />
            </BarChart>
          </ResponsiveContainer>
        ) : (
          <p className="text-center text-sm text-muted-foreground py-8">Chưa có dữ liệu</p>
        )}
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        {/* Pages */}
        <div className="rounded-2xl border border-border bg-card p-6">
          <h3 className="mb-4 font-display text-sm font-bold text-foreground">📄 Trang được xem</h3>
          <div className="space-y-3">
            {pageStats.map(([path, count]) => {
              const pct = filtered.length ? Math.round((count / filtered.length) * 100) : 0;
              return (
                <div key={path}>
                  <div className="mb-1 flex justify-between text-xs">
                    <span className="text-muted-foreground">{pathLabels[path] || path}</span>
                    <span className="font-semibold text-foreground">{count} ({pct}%)</span>
                  </div>
                  <div className="h-1.5 rounded-full bg-muted">
                    <div className="h-1.5 rounded-full bg-primary transition-all" style={{ width: `${pct}%` }} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Devices */}
        <div className="rounded-2xl border border-border bg-card p-6">
          <h3 className="mb-4 font-display text-sm font-bold text-foreground">📱 Thiết bị</h3>
          <div className="space-y-3">
            {deviceStats.map(([device, count]) => {
              const pct = filtered.length ? Math.round((count / filtered.length) * 100) : 0;
              return (
                <div key={device}>
                  <div className="mb-1 flex justify-between text-xs">
                    <span className="text-muted-foreground">{device}</span>
                    <span className="font-semibold text-foreground">{count} ({pct}%)</span>
                  </div>
                  <div className="h-1.5 rounded-full bg-muted">
                    <div className="h-1.5 rounded-full bg-blue-500 transition-all" style={{ width: `${pct}%` }} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Browsers */}
        <div className="rounded-2xl border border-border bg-card p-6">
          <h3 className="mb-4 font-display text-sm font-bold text-foreground">🌐 Trình duyệt</h3>
          <div className="space-y-3">
            {browserStats.map(([browser, count]) => {
              const pct = filtered.length ? Math.round((count / filtered.length) * 100) : 0;
              return (
                <div key={browser}>
                  <div className="mb-1 flex justify-between text-xs">
                    <span className="text-muted-foreground">{browser}</span>
                    <span className="font-semibold text-foreground">{count} ({pct}%)</span>
                  </div>
                  <div className="h-1.5 rounded-full bg-muted">
                    <div className="h-1.5 rounded-full bg-secondary transition-all" style={{ width: `${pct}%` }} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

const SettingsTab = () => {
  const [notifEmails, setNotifEmails] = useState<string[]>([]);
  const [newEmailInput, setNewEmailInput] = useState("");
  const [savingEmail, setSavingEmail] = useState(false);
  const [emailMsg, setEmailMsg] = useState("");
  const [loadingEmail, setLoadingEmail] = useState(true);

  const [resendKey, setResendKey] = useState("");
  const [savingResend, setSavingResend] = useState(false);
  const [resendMsg, setResendMsg] = useState("");

  const [payos, setPayos] = useState({ clientId: "", apiKey: "", checksumKey: "" });
  const [savingPayos, setSavingPayos] = useState(false);
  const [payosMsg, setPayosMsg] = useState("");
  const [loadingPayos, setLoadingPayos] = useState(true);

  const [storage, setStorage] = useState({ serviceName: "Cloudinary", cloudName: "", apiKey: "", apiSecret: "" });
  const [savingStorage, setSavingStorage] = useState(false);
  const [storageMsg, setStorageMsg] = useState("");
  const [loadingStorage, setLoadingStorage] = useState(true);

  const [socialLinks, setSocialLinks] = useState<{ platform: string; label: string; url: string }[]>([]);
  const [savingSocial, setSavingSocial] = useState(false);
  const [socialMsg, setSocialMsg] = useState("");
  const [loadingSocial, setLoadingSocial] = useState(true);

  const [shippingZone, setShippingZone] = useState(DEFAULT_SHIPPING_ZONE);
  const [savingShipping, setSavingShipping] = useState(false);
  const [shippingMsg, setShippingMsg] = useState("");
  const [loadingShipping, setLoadingShipping] = useState(true);

  const [requireAdminOtp, setRequireAdminOtp] = useState(true);
  const [savingOtpConfig, setSavingOtpConfig] = useState(false);
  const [otpConfigMsg, setOtpConfigMsg] = useState("");
  const [loadingOtpConfig, setLoadingOtpConfig] = useState(true);
  const [showOtpPasswordPrompt, setShowOtpPasswordPrompt] = useState(false);
  const [otpTogglePassword, setOtpTogglePassword] = useState("");
  const [pendingOtpState, setPendingOtpState] = useState<boolean | null>(null);

  const { user } = useAuth();

  useEffect(() => {
    const load = async () => {
      const { data } = await supabase
        .from("app_settings")
        .select("key, value")
        .in("key", [
          "PAYOS_CLIENT_ID", "PAYOS_API_KEY", "PAYOS_CHECKSUM_KEY",
          "CLOUDINARY_CLOUD_NAME", "CLOUDINARY_API_KEY", "CLOUDINARY_API_SECRET",
          "STORAGE_SERVICE_NAME", "ADMIN_NOTIFICATION_EMAIL", "SOCIAL_LINKS",
          "SHIPPING_ZONE_CONFIG", "RESEND_API_KEY", "REQUIRE_ADMIN_OTP"
        ]);
      if (data) {
        const map: Record<string, string> = {};
        data.forEach((s) => (map[s.key] = s.value));
        setPayos({
          clientId: map["PAYOS_CLIENT_ID"] || "",
          apiKey: map["PAYOS_API_KEY"] || "",
          checksumKey: map["PAYOS_CHECKSUM_KEY"] || "",
        });
        setStorage({
          serviceName: map["STORAGE_SERVICE_NAME"] || "Cloudinary",
          cloudName: map["CLOUDINARY_CLOUD_NAME"] || "",
          apiKey: map["CLOUDINARY_API_KEY"] || "",
          apiSecret: map["CLOUDINARY_API_SECRET"] || "",
        });

        const emailsFromDb = map["ADMIN_NOTIFICATION_EMAIL"] || "";
        setNotifEmails(emailsFromDb ? emailsFromDb.split(",").map(e => e.trim()).filter(Boolean) : []);

        setResendKey(map["RESEND_API_KEY"] || "");
        try {
          setSocialLinks(map["SOCIAL_LINKS"] ? JSON.parse(map["SOCIAL_LINKS"]) : DEFAULT_SOCIAL_LINKS);
        } catch {
          setSocialLinks(DEFAULT_SOCIAL_LINKS);
        }
        try {
          setShippingZone(map["SHIPPING_ZONE_CONFIG"] ? JSON.parse(map["SHIPPING_ZONE_CONFIG"]) : DEFAULT_SHIPPING_ZONE);
        } catch {
          setShippingZone(DEFAULT_SHIPPING_ZONE);
        }

        setRequireAdminOtp(map["REQUIRE_ADMIN_OTP"] !== "false");

      } else {
        setSocialLinks(DEFAULT_SOCIAL_LINKS);
        setShippingZone(DEFAULT_SHIPPING_ZONE);
      }
      setLoadingPayos(false);
      setLoadingStorage(false);
      setLoadingEmail(false);
      setLoadingSocial(false);
      setLoadingShipping(false);
      setLoadingOtpConfig(false);
    };
    load();
  }, []);

  const saveEmail = async () => {
    setSavingEmail(true);
    setEmailMsg("");
    try {
      const finalEmailString = notifEmails.join(", ");
      const existing = await supabase.from("app_settings").select("id").eq("key", "ADMIN_NOTIFICATION_EMAIL").maybeSingle();
      if (existing.data) {
        await supabase.from("app_settings").update({ value: finalEmailString } as any).eq("key", "ADMIN_NOTIFICATION_EMAIL");
      } else {
        await supabase.from("app_settings").insert({ key: "ADMIN_NOTIFICATION_EMAIL", value: finalEmailString } as any);
      }
      setEmailMsg("✅ Đã lưu email thông báo!");
    } catch (e: any) {
      setEmailMsg(`❌ Lỗi: ${e.message}`);
    }
    setSavingEmail(false);
  };

  const handleAddEmailTag = () => {
    const val = newEmailInput.trim();
    if (!val) return;
    // Basic email validation
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val)) {
      setEmailMsg("❌ Email không hợp lệ");
      return;
    }
    if (notifEmails.includes(val)) {
      setEmailMsg("❌ Email đã tồn tại");
      return;
    }
    setNotifEmails([...notifEmails, val]);
    setNewEmailInput("");
    setEmailMsg("");
  };

  const handleRemoveEmailTag = (email: string) => {
    setNotifEmails(notifEmails.filter(e => e !== email));
  };

  const saveResend = async () => {
    setSavingResend(true);
    setResendMsg("");
    try {
      const { error } = await supabase.functions.invoke("update-resend-config", {
        body: { resendApiKey: resendKey.trim() },
      });
      if (error) throw error;
      setResendMsg("✅ Đã cập nhật Resend API Key!");
    } catch (e: any) {
      setResendMsg(`❌ Lỗi: ${e.message || "Không thể cập nhật"}`);
    }
    setSavingResend(false);
  };

  const savePayos = async () => {
    setSavingPayos(true);
    setPayosMsg("");
    try {
      const { error } = await supabase.functions.invoke("update-payos-config", {
        body: payos,
      });
      if (error) throw error;
      setPayosMsg("✅ Đã cập nhật PayOS thành công!");
    } catch (e: any) {
      setPayosMsg(`❌ Lỗi: ${e.message || "Không thể cập nhật"}`);
    }
    setSavingPayos(false);
  };

  const confirmOtpToggle = async () => {
    if (!user?.email || !otpTogglePassword || pendingOtpState === null) return;
    setSavingOtpConfig(true);
    setOtpConfigMsg("");

    try {
      // Xác thực mật khẩu
      const { error: authError } = await supabase.auth.signInWithPassword({
        email: user.email,
        password: otpTogglePassword,
      });

      if (authError) throw new Error("Mật khẩu không chính xác");

      // Nếu pass, cập nhật settings
      const existing = await supabase.from("app_settings").select("id").eq("key", "REQUIRE_ADMIN_OTP").maybeSingle();
      const stringValue = pendingOtpState ? "true" : "false";

      if (existing.data) {
        await supabase.from("app_settings").update({ value: stringValue } as any).eq("key", "REQUIRE_ADMIN_OTP");
      } else {
        await supabase.from("app_settings").insert({ key: "REQUIRE_ADMIN_OTP", value: stringValue } as any);
      }

      setRequireAdminOtp(pendingOtpState);
      setOtpConfigMsg("✅ Đã cập nhật cài đặt OTP Admin!");
      setShowOtpPasswordPrompt(false);
      setOtpTogglePassword("");

    } catch (e: any) {
      setOtpConfigMsg(`❌ Lỗi: ${e.message}`);
    }

    setSavingOtpConfig(false);
  };

  const handleToggleOtp = (newState: boolean) => {
    setPendingOtpState(newState);
    setShowOtpPasswordPrompt(true);
    setOtpConfigMsg("");
  };

  const saveStorage = async () => {
    setSavingStorage(true);
    setStorageMsg("");
    try {
      const { error } = await supabase.functions.invoke("update-cloudinary-config", {
        body: { cloudName: storage.cloudName, apiKey: storage.apiKey, apiSecret: storage.apiSecret },
      });
      if (error) throw error;
      const existing = await supabase.from("app_settings").select("id").eq("key", "STORAGE_SERVICE_NAME").maybeSingle();
      if (existing.data) {
        await supabase.from("app_settings").update({ value: storage.serviceName } as any).eq("key", "STORAGE_SERVICE_NAME");
      } else {
        await supabase.from("app_settings").insert({ key: "STORAGE_SERVICE_NAME", value: storage.serviceName } as any);
      }
      setStorageMsg("✅ Đã cập nhật kho lưu trữ thành công!");
    } catch (e: any) {
      setStorageMsg(`❌ Lỗi: ${e.message || "Không thể cập nhật"}`);
    }
    setSavingStorage(false);
  };

  return (
    <div className="max-w-lg space-y-6">
      {/* Admin OTP Config */}
      <div className="rounded-2xl border border-border bg-card p-6">
        <h3 className="mb-4 font-display text-lg font-bold text-foreground flex items-center gap-2">
          <ShieldCheck className="h-5 w-5" />
          Bảo mật Admin
        </h3>
        <p className="mb-4 text-sm text-muted-foreground">
          Bật/tắt yêu cầu nhập mã OTP khi truy cập vào trang quản trị Admin.
        </p>

        {loadingOtpConfig ? (
          <Loader2 className="h-5 w-5 animate-spin text-primary" />
        ) : (
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 rounded-xl border border-border bg-background">
              <div>
                <p className="text-sm font-semibold text-foreground">Yêu cầu mã OTP</p>
                <p className="text-xs text-muted-foreground">{requireAdminOtp ? "Đang bật" : "Đang tắt"}</p>
              </div>
              <button
                onClick={() => handleToggleOtp(!requireAdminOtp)}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  requireAdminOtp ? "bg-primary" : "bg-muted"
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    requireAdminOtp ? "translate-x-6" : "translate-x-1"
                  }`}
                />
              </button>
            </div>

            {showOtpPasswordPrompt && (
              <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} className="space-y-3 pt-2">
                <p className="text-sm font-medium text-foreground">
                  Nhập mật khẩu của bạn để xác nhận {pendingOtpState ? "BẬT" : "TẮT"} OTP
                </p>
                <SecretInput
                  label="Mật khẩu hiện tại"
                  value={otpTogglePassword}
                  onChange={setOtpTogglePassword}
                  placeholder="Nhập mật khẩu..."
                />
                <div className="flex gap-2">
                  <button
                    onClick={confirmOtpToggle}
                    disabled={savingOtpConfig || !otpTogglePassword}
                    className="flex-1 rounded-xl bg-primary px-4 py-2 text-sm font-bold text-primary-foreground disabled:opacity-50"
                  >
                    {savingOtpConfig ? "Đang xử lý..." : "Xác nhận"}
                  </button>
                  <button
                    onClick={() => {
                      setShowOtpPasswordPrompt(false);
                      setOtpTogglePassword("");
                    }}
                    className="rounded-xl border border-border px-4 py-2 text-sm font-bold text-muted-foreground hover:bg-muted"
                  >
                    Hủy
                  </button>
                </div>
              </motion.div>
            )}
            {otpConfigMsg && <p className="text-sm mt-2">{otpConfigMsg}</p>}
          </div>
        )}
      </div>

      {/* Resend API Key */}
      <div className="rounded-2xl border border-border bg-card p-6">
        <h3 className="mb-4 font-display text-lg font-bold text-foreground">
          🔑 Resend API Key
        </h3>
        <p className="mb-4 text-sm text-muted-foreground">
          API Key từ <a href="https://resend.com/api-keys" target="_blank" rel="noopener noreferrer" className="underline text-primary">resend.com</a> để gửi email thông báo đơn hàng.
        </p>
        <div className="space-y-3">
          <SecretInput
            label="Resend API Key"
            value={resendKey}
            onChange={setResendKey}
            placeholder="re_xxxxxxxxxxxxxxxx"
          />
          <button
            onClick={saveResend}
            disabled={savingResend || !resendKey.trim()}
            className="w-full rounded-xl bg-primary px-4 py-3 text-sm font-bold text-primary-foreground disabled:opacity-50"
          >
            {savingResend ? "Đang lưu..." : "Cập nhật Resend API Key"}
          </button>
          {resendMsg && <p className="text-sm mt-2">{resendMsg}</p>}
        </div>
      </div>

      {/* Email notification */}
      <div className="rounded-2xl border border-border bg-card p-6">
        <h3 className="mb-4 font-display text-lg font-bold text-foreground">
          <Mail className="mr-2 inline h-5 w-5" />
          Email nhận thông báo đơn hàng
        </h3>
        <p className="mb-4 text-sm text-muted-foreground">
          Thêm các email nhận thông báo khi có đơn hàng mới.
        </p>
        {loadingEmail ? (
          <Loader2 className="h-5 w-5 animate-spin text-primary" />
        ) : (
          <div className="space-y-4">
            <div className="flex flex-wrap gap-2 mb-2">
              {notifEmails.map((email) => (
                <div key={email} className="flex items-center gap-1.5 rounded-full bg-primary/10 px-3 py-1.5 text-sm font-medium text-primary">
                  {email}
                  <button
                    onClick={() => handleRemoveEmailTag(email)}
                    className="ml-1 rounded-full p-0.5 hover:bg-primary/20 hover:text-primary-foreground"
                    title="Xóa"
                  >
                    <XCircle className="h-3.5 w-3.5" />
                  </button>
                </div>
              ))}
              {notifEmails.length === 0 && (
                <span className="text-sm text-muted-foreground italic">Chưa có email nào</span>
              )}
            </div>

            <div className="flex gap-2">
              <input
                type="email"
                value={newEmailInput}
                onChange={(e) => setNewEmailInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault();
                    handleAddEmailTag();
                  }
                }}
                className="flex-1 rounded-xl border border-border bg-background px-4 py-2.5 text-sm outline-none focus:border-primary"
                placeholder="Nhập email mới..."
              />
              <button
                onClick={handleAddEmailTag}
                className="rounded-xl bg-secondary px-4 py-2.5 text-sm font-bold text-secondary-foreground hover:bg-secondary/80 transition-colors"
              >
                Thêm
              </button>
            </div>

            <button
              onClick={saveEmail}
              disabled={savingEmail}
              className="w-full rounded-xl bg-primary px-4 py-3 text-sm font-bold text-primary-foreground disabled:opacity-50"
            >
              {savingEmail ? "Đang lưu..." : "Lưu danh sách email"}
            </button>
            {emailMsg && <p className="text-sm mt-2">{emailMsg}</p>}
          </div>
        )}
      </div>

      {/* PayOS config */}
      <div className="rounded-2xl border border-border bg-card p-6">
        <h3 className="mb-4 font-display text-lg font-bold text-foreground">
          💳 Cấu hình PayOS
        </h3>
        <p className="mb-4 text-sm text-muted-foreground">
          Cập nhật Client ID, API Key và Checksum Key của PayOS.
        </p>
        {loadingPayos ? (
          <Loader2 className="h-5 w-5 animate-spin text-primary" />
        ) : (
          <div className="space-y-3">
            <SecretInput label="Client ID" value={payos.clientId} onChange={(v) => setPayos((p) => ({ ...p, clientId: v }))} placeholder="Nhập Client ID" />
            <SecretInput label="API Key" value={payos.apiKey} onChange={(v) => setPayos((p) => ({ ...p, apiKey: v }))} placeholder="Nhập API Key" />
            <SecretInput label="Checksum Key" value={payos.checksumKey} onChange={(v) => setPayos((p) => ({ ...p, checksumKey: v }))} placeholder="Nhập Checksum Key" />
            <button
              onClick={savePayos}
              disabled={savingPayos || !payos.clientId || !payos.apiKey || !payos.checksumKey}
              className="w-full rounded-xl bg-primary px-4 py-3 text-sm font-bold text-primary-foreground disabled:opacity-50"
            >
              {savingPayos ? "Đang lưu..." : "Cập nhật PayOS"}
            </button>
            {payosMsg && <p className="text-sm mt-2">{payosMsg}</p>}
          </div>
        )}
      </div>

      {/* Storage config */}
      <div className="rounded-2xl border border-border bg-card p-6">
        <h3 className="mb-4 font-display text-lg font-bold text-foreground">
          🖼️ Kho lưu trữ ảnh
        </h3>
        <p className="mb-4 text-sm text-muted-foreground">
          Cấu hình dịch vụ lưu trữ ảnh (Cloudinary hoặc dịch vụ khác).
        </p>
        {loadingStorage ? (
          <Loader2 className="h-5 w-5 animate-spin text-primary" />
        ) : (
          <div className="space-y-3">
            <div>
              <label className="mb-1 block text-xs font-semibold text-muted-foreground">Tên dịch vụ</label>
              <input
                type="text"
                value={storage.serviceName}
                onChange={(e) => setStorage((p) => ({ ...p, serviceName: e.target.value }))}
                className="w-full rounded-xl border border-border bg-background px-4 py-2.5 text-sm outline-none focus:border-primary"
                placeholder="VD: Cloudinary, Imgix..."
              />
            </div>
            <SecretInput label="Cloud Name / Endpoint" value={storage.cloudName} onChange={(v) => setStorage((p) => ({ ...p, cloudName: v }))} placeholder="Nhập Cloud Name hoặc Endpoint" />
            <SecretInput label="API Key" value={storage.apiKey} onChange={(v) => setStorage((p) => ({ ...p, apiKey: v }))} placeholder="Nhập API Key" />
            <SecretInput label="API Secret" value={storage.apiSecret} onChange={(v) => setStorage((p) => ({ ...p, apiSecret: v }))} placeholder="Nhập API Secret" />
            <button
              onClick={saveStorage}
              disabled={savingStorage || !storage.cloudName || !storage.apiKey || !storage.apiSecret}
              className="w-full rounded-xl bg-primary px-4 py-3 text-sm font-bold text-primary-foreground disabled:opacity-50"
            >
              {savingStorage ? "Đang lưu..." : "Cập nhật kho lưu trữ"}
            </button>
            {storageMsg && <p className="text-sm mt-2">{storageMsg}</p>}
          </div>
        )}
      </div>
      {/* Social Links config */}
      <div className="rounded-2xl border border-border bg-card p-6">
        <h3 className="mb-4 font-display text-lg font-bold text-foreground">
          🔗 Liên kết mạng xã hội & Hotline
        </h3>
        <p className="mb-4 text-sm text-muted-foreground">
          Quản lý các liên kết hiển thị ở cuối trang web.
        </p>
        {loadingSocial ? (
          <Loader2 className="h-5 w-5 animate-spin text-primary" />
        ) : (
          <div className="space-y-3">
            {socialLinks.map((link, idx) => (
              <div key={idx} className="flex gap-2 items-end">
                <div className="w-36">
                  <label className="mb-1 block text-xs font-semibold text-muted-foreground">Nền tảng</label>
                  <select
                    value={link.platform}
                    onChange={(e) => {
                      const updated = [...socialLinks];
                      const opt = SOCIAL_PLATFORM_OPTIONS.find((o) => o.value === e.target.value);
                      updated[idx] = { ...updated[idx], platform: e.target.value, label: opt?.label || e.target.value };
                      setSocialLinks(updated);
                    }}
                    className="w-full rounded-xl border border-border bg-background px-3 py-2.5 text-sm outline-none focus:border-primary"
                  >
                    {SOCIAL_PLATFORM_OPTIONS.map((opt) => (
                      <option key={opt.value} value={opt.value}>{opt.label}</option>
                    ))}
                  </select>
                </div>
                <div className="flex-1">
                  <label className="mb-1 block text-xs font-semibold text-muted-foreground">
                    {link.platform.startsWith("hotline") ? "Số điện thoại" : "URL"}
                  </label>
                  <input
                    type="text"
                    value={link.url}
                    onChange={(e) => {
                      const updated = [...socialLinks];
                      updated[idx] = { ...updated[idx], url: e.target.value };
                      setSocialLinks(updated);
                    }}
                    className="w-full rounded-xl border border-border bg-background px-3 py-2.5 text-sm outline-none focus:border-primary"
                    placeholder={link.platform.startsWith("hotline") ? "0xx xxx xxxx" : "https://..."}
                  />
                </div>
                <button
                  onClick={() => setSocialLinks(socialLinks.filter((_, i) => i !== idx))}
                  className="rounded-xl border border-destructive/30 p-2.5 text-destructive hover:bg-destructive/10"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            ))}
            <button
              onClick={() => setSocialLinks([...socialLinks, { platform: "facebook", label: "Facebook", url: "" }])}
              className="flex items-center gap-2 text-sm font-medium text-primary hover:underline"
            >
              <PlusCircle className="h-4 w-4" /> Thêm liên kết
            </button>
            <button
              onClick={async () => {
                setSavingSocial(true);
                setSocialMsg("");
                try {
                  const jsonValue = JSON.stringify(socialLinks);
                  const existing = await supabase.from("app_settings").select("id").eq("key", "SOCIAL_LINKS").maybeSingle();
                  if (existing.data) {
                    await supabase.from("app_settings").update({ value: jsonValue } as any).eq("key", "SOCIAL_LINKS");
                  } else {
                    await supabase.from("app_settings").insert({ key: "SOCIAL_LINKS", value: jsonValue } as any);
                  }
                  setSocialMsg("✅ Đã lưu liên kết!");
                } catch (e: any) {
                  setSocialMsg(`❌ Lỗi: ${e.message}`);
                }
                setSavingSocial(false);
              }}
              disabled={savingSocial}
              className="w-full rounded-xl bg-primary px-4 py-3 text-sm font-bold text-primary-foreground disabled:opacity-50"
            >
              {savingSocial ? "Đang lưu..." : "Lưu liên kết"}
            </button>
            {socialMsg && <p className="text-sm mt-2">{socialMsg}</p>}
          </div>
        )}
      </div>

      {/* Shipping Zone config */}
      <div className="rounded-2xl border border-border bg-card p-6">
        <h3 className="mb-4 font-display text-lg font-bold text-foreground">
          🚚 Vùng giao hàng & Điểm nhận hàng
        </h3>
        <p className="mb-4 text-sm text-muted-foreground">
          Cấu hình bán kính free ship và các điểm nhận hàng cố định (khách chọn điểm = miễn phí ship).
        </p>
        {loadingShipping ? (
          <Loader2 className="h-5 w-5 animate-spin text-primary" />
        ) : (
          <div className="space-y-4">
            <div>
              <label className="mb-2 block text-xs font-semibold text-muted-foreground">Điểm nhận hàng (free ship)</label>
              <p className="mb-3 text-xs text-muted-foreground">Mỗi điểm có tên, địa chỉ, toạ độ và bán kính free ship riêng. Copy toạ độ từ Google Maps (chuột phải → Copy coordinates).</p>
              {shippingZone.pickup_points.map((pp, idx) => (
                <div key={idx} className="mb-3 rounded-xl border border-border bg-background p-3 space-y-2">
                  <div className="flex gap-2">
                    <div className="flex-1">
                      <label className="mb-1 block text-xs text-muted-foreground">Tên điểm</label>
                      <input
                        type="text"
                        value={pp.name}
                        onChange={(e) => {
                          const updated = [...shippingZone.pickup_points];
                          updated[idx] = { ...updated[idx], name: e.target.value };
                          setShippingZone((p) => ({ ...p, pickup_points: updated }));
                        }}
                        className="w-full rounded-lg border border-border bg-card px-3 py-2 text-sm outline-none focus:border-primary"
                        placeholder="VD: Trường THPT Chí Linh"
                      />
                    </div>
                    <button
                      onClick={() => {
                        const updated = shippingZone.pickup_points.filter((_, i) => i !== idx);
                        setShippingZone((p) => ({ ...p, pickup_points: updated }));
                      }}
                      className="self-end rounded-lg border border-destructive/30 p-2 text-destructive hover:bg-destructive/10"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                  <div>
                    <label className="mb-1 block text-xs text-muted-foreground">Địa chỉ</label>
                    <input
                      type="text"
                      value={pp.address}
                      onChange={(e) => {
                        const updated = [...shippingZone.pickup_points];
                        updated[idx] = { ...updated[idx], address: e.target.value };
                        setShippingZone((p) => ({ ...p, pickup_points: updated }));
                      }}
                      className="w-full rounded-lg border border-border bg-card px-3 py-2 text-sm outline-none focus:border-primary"
                      placeholder="Phường/xã, quận/huyện, tỉnh/TP"
                    />
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <label className="mb-1 block text-xs text-muted-foreground">Toạ độ (dán từ Maps)</label>
                      <input
                        type="text"
                        placeholder="21.133, 106.396"
                        defaultValue={pp.lat && pp.lng ? `${pp.lat}, ${pp.lng}` : ""}
                        onChange={(e) => {
                          const m = e.target.value.trim().match(/^(-?\d+\.?\d*)\s*,\s*(-?\d+\.?\d*)$/);
                          if (m) {
                            const updated = [...shippingZone.pickup_points];
                            updated[idx] = { ...updated[idx], lat: parseFloat(m[1]), lng: parseFloat(m[2]) };
                            setShippingZone((p) => ({ ...p, pickup_points: updated }));
                          }
                        }}
                        className="w-full rounded-lg border border-border bg-card px-3 py-2 text-sm outline-none focus:border-primary"
                      />
                    </div>
                    <div>
                      <label className="mb-1 block text-xs text-muted-foreground">Vĩ độ</label>
                      <input
                        type="number"
                        step="0.0001"
                        value={pp.lat}
                        onChange={(e) => {
                          const updated = [...shippingZone.pickup_points];
                          updated[idx] = { ...updated[idx], lat: parseFloat(e.target.value) || 0 };
                          setShippingZone((p) => ({ ...p, pickup_points: updated }));
                        }}
                        className="w-full rounded-lg border border-border bg-card px-3 py-2 text-sm outline-none focus:border-primary"
                      />
                    </div>
                    <div>
                      <label className="mb-1 block text-xs text-muted-foreground">Kinh độ</label>
                      <input
                        type="number"
                        step="0.0001"
                        value={pp.lng}
                        onChange={(e) => {
                          const updated = [...shippingZone.pickup_points];
                          updated[idx] = { ...updated[idx], lng: parseFloat(e.target.value) || 0 };
                          setShippingZone((p) => ({ ...p, pickup_points: updated }));
                        }}
                        className="w-full rounded-lg border border-border bg-card px-3 py-2 text-sm outline-none focus:border-primary"
                      />
                    </div>
                  </div>
                  <div className="w-1/3">
                    <label className="mb-1 block text-xs text-muted-foreground">Bán kính free ship (km)</label>
                    <input
                      type="number"
                      step="0.5"
                      min="0"
                      value={pp.radius_km}
                      onChange={(e) => {
                        const updated = [...shippingZone.pickup_points];
                        updated[idx] = { ...updated[idx], radius_km: parseFloat(e.target.value) || 0 };
                        setShippingZone((p) => ({ ...p, pickup_points: updated }));
                      }}
                      className="w-full rounded-lg border border-border bg-card px-3 py-2 text-sm outline-none focus:border-primary"
                    />
                  </div>
                </div>
              ))}
              <button
                onClick={() => setShippingZone((p) => ({ ...p, pickup_points: [...p.pickup_points, { name: "", address: "", lat: 0, lng: 0, radius_km: 3 }] }))}
                className="flex items-center gap-2 text-sm font-medium text-primary hover:underline"
              >
                <PlusCircle className="h-4 w-4" /> Thêm điểm nhận hàng
              </button>
            </div>

            <button
              onClick={async () => {
                setSavingShipping(true);
                setShippingMsg("");
                try {
                  const jsonValue = JSON.stringify(shippingZone);
                  const existing = await supabase.from("app_settings").select("id").eq("key", "SHIPPING_ZONE_CONFIG").maybeSingle();
                  if (existing.data) {
                    await supabase.from("app_settings").update({ value: jsonValue } as any).eq("key", "SHIPPING_ZONE_CONFIG");
                  } else {
                    await supabase.from("app_settings").insert({ key: "SHIPPING_ZONE_CONFIG", value: jsonValue } as any);
                  }
                  setShippingMsg("✅ Đã lưu cấu hình giao hàng!");
                } catch (e: any) {
                  setShippingMsg(`❌ Lỗi: ${e.message}`);
                }
                setSavingShipping(false);
              }}
              disabled={savingShipping}
              className="w-full rounded-xl bg-primary px-4 py-3 text-sm font-bold text-primary-foreground disabled:opacity-50"
            >
              {savingShipping ? "Đang lưu..." : "Lưu cấu hình giao hàng"}
            </button>
            {shippingMsg && <p className="text-sm mt-2">{shippingMsg}</p>}
          </div>
        )}
      </div>
    </div>
  );
};

const STATUS_MAP: Record<string, { label: string; icon: React.ElementType; color: string }> = {
  pending: { label: "Chờ xác nhận", icon: Clock, color: "text-yellow-600 bg-yellow-50" },
  preparing: { label: "Đang chuẩn bị", icon: ChefHat, color: "text-orange-500 bg-orange-50" },
  delivering: { label: "Đang giao", icon: Truck, color: "text-blue-500 bg-blue-50" },
  delivered: { label: "Đã giao", icon: CheckCircle2, color: "text-primary bg-primary/10" },
  cancelled: { label: "Đã hủy", icon: XCircle, color: "text-destructive bg-destructive/10" },
};

const STATUSES = ["pending", "preparing", "delivering", "delivered", "cancelled"];

type Tab = "orders" | "users" | "stats" | "finance" | "surcharges" | "settings" | "roles" | "analytics" | "vouchers" | "interface";

interface Order {
  id: string;
  order_code: string;
  customer_name: string;
  phone: string;
  address: string;
  total: number;
  subtotal: number;
  shipping_fee: number;
  green_fund_amount: number;
  status: string;
  created_at: string;
  payment_method: string;
  payment_status: string;
  notes: string | null;
}

interface OrderItem {
  id: string;
  cookie_name: string;
  quantity: number;
  unit_price: number;
  total_price: number;
}

const AdminDashboard = () => {
  const { user, loading: authLoading } = useAuth();
  const { isAdmin, loading: roleLoading } = useRole();
  const navigate = useNavigate();
  const [tab, setTab] = useState<Tab>("orders");
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [orderItems, setOrderItems] = useState<Record<string, OrderItem[]>>({});
  const [loadingItems, setLoadingItems] = useState<string | null>(null);
  const [updatingStatus, setUpdatingStatus] = useState<string | null>(null);
  const [orderVouchers, setOrderVouchers] = useState<Record<string, any | null>>({});

  // Admin OTP verification state
  const [adminVerified, setAdminVerified] = useState(false);
  const [otpStep, setOtpStep] = useState<"checking_config" | "sending" | "verify" | "done">("checking_config");
  const [otpCode, setOtpCode] = useState("");
  const [otpLoading, setOtpLoading] = useState(false);
  const [resendCountdown, setResendCountdown] = useState(0);
  const [isOtpRequired, setIsOtpRequired] = useState(true);

  const formatRemainingTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return mins > 0 ? `${mins}m ${secs}s` : `${secs}s`;
  };

  // Countdown effect
  useEffect(() => {
    if (resendCountdown <= 0) return;
    const timer = setInterval(() => {
      setResendCountdown((prev) => (prev <= 1 ? 0 : prev - 1));
    }, 1000);
    return () => clearInterval(timer);
  }, [resendCountdown]);

  const toggleExpand = async (orderId: string) => {
    if (expandedId === orderId) { setExpandedId(null); return; }
    setExpandedId(orderId);
    if (!orderItems[orderId]) {
      setLoadingItems(orderId);
      const [itemsRes, voucherRes] = await Promise.all([
        supabase.from("order_items").select("*").eq("order_id", orderId),
        supabase.from("user_vouchers").select("*, voucher_templates(name, type, value)").eq("order_id", orderId).maybeSingle(),
      ]);
      if (itemsRes.data) setOrderItems((prev) => ({ ...prev, [orderId]: itemsRes.data }));
      setOrderVouchers((prev) => ({ ...prev, [orderId]: voucherRes.data || null }));
      setLoadingItems(null);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success("Đã sao chép!");
  };

  useEffect(() => {
    if (!authLoading && !roleLoading) {
      if (!user) navigate("/auth");
      else if (!isAdmin) navigate("/");
    }
  }, [user, isAdmin, authLoading, roleLoading, navigate]);

  // Check if OTP is required for Admin, then optionally send OTP
  const otpSentRef = useRef(false);
  useEffect(() => {
    if (!isAdmin || !user || adminVerified) return;
    if (otpSentRef.current) return;
    otpSentRef.current = true;

    const checkAndSendOtp = async () => {
      // 1. Check REQUIRE_ADMIN_OTP from app_settings
      const { data: settingData } = await supabase
        .from("app_settings")
        .select("value")
        .eq("key", "REQUIRE_ADMIN_OTP")
        .maybeSingle();

      const requiresOtp = settingData?.value !== "false";
      setIsOtpRequired(requiresOtp);

      if (!requiresOtp) {
        setAdminVerified(true);
        setOtpStep("done");
        return;
      }

      // 2. If required, check session throttle and send OTP
      const sessionKey = `admin_otp_last_sent_${user.id}`;
      const lastSentAt = Number(sessionStorage.getItem(sessionKey) || 0);
      const elapsedSeconds = Math.floor((Date.now() - lastSentAt) / 1000);

      // If already sent recently in this browser session, don't auto-send again
      if (lastSentAt > 0 && elapsedSeconds < 300) {
        setOtpStep("verify");
        if (elapsedSeconds < 60) {
          setResendCountdown(60 - elapsedSeconds);
        }
        return;
      }

      setOtpStep("sending");
      const { data, error } = await supabase.functions.invoke("send-verification-code", {
        body: { email: user.email, type: "admin_login" },
      });

      if (error || (data && !data.success)) {
        if (data?.retry_after_seconds) {
          setResendCountdown(Math.max(0, Number(data.retry_after_seconds)));
          toast.error(`Bạn gửi quá nhanh. Thử lại sau ${formatRemainingTime(Number(data.retry_after_seconds))}.`);
        } else if (data?.error?.includes("quá nhiều")) {
          toast.error(data.error);
        } else {
          toast.error("Không thể gửi mã xác thực");
        }
        setOtpStep("verify");
      } else {
        sessionStorage.setItem(sessionKey, String(Date.now()));
        toast.info("Mã xác thực đã được gửi đến email của bạn");
        setOtpStep("verify");
        setResendCountdown(60);
      }
    };

    checkAndSendOtp();
  }, [isAdmin, user, adminVerified]);

  const handleAdminOtpVerify = async () => {
    if (otpCode.length !== 6) {
      toast.error("Vui lòng nhập đủ 6 chữ số");
      return;
    }
    setOtpLoading(true);
    const { data, error } = await supabase.functions.invoke("verify-code", {
      body: { email: user!.email, code: otpCode, type: "admin_login" },
    });
    setOtpLoading(false);
    if (error || !data?.valid) {
      toast.error("Mã không hợp lệ hoặc đã hết hạn");
      return;
    }
    setAdminVerified(true);
    setOtpStep("done");
    toast.success("Xác thực thành công!");
  };

  const handleResendAdminOtp = async () => {
    if (!user || resendCountdown > 0) return;
    setOtpLoading(true);
    const { data, error } = await supabase.functions.invoke("send-verification-code", {
      body: { email: user.email, type: "admin_login" },
    });
    setOtpLoading(false);

    if (error || (data && !data.success)) {
      if (data?.retry_after_seconds) {
        setResendCountdown(Math.max(0, Number(data.retry_after_seconds)));
        toast.error(`Bạn gửi quá nhanh. Thử lại sau ${formatRemainingTime(Number(data.retry_after_seconds))}.`);
      } else {
        toast.error(data?.error || "Không thể gửi lại mã");
      }
      return;
    }

    sessionStorage.setItem(`admin_otp_last_sent_${user.id}`, String(Date.now()));
    toast.success("Đã gửi lại mã xác thực!");
    setOtpCode("");
    setResendCountdown(60);
  };

  const fetchOrders = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("orders")
      .select("*")
      .order("created_at", { ascending: false });
    if (!error && data) setOrders(data);
    setLoading(false);
  };

  useEffect(() => {
    if (isAdmin && adminVerified) fetchOrders();
  }, [isAdmin, adminVerified]);

  const updateOrderStatus = async (orderId: string, newStatus: string) => {
    setUpdatingStatus(orderId);
    const order = orders.find((o) => o.id === orderId);
    const previousStatus = order?.status;

    const { error } = await supabase
      .from("orders")
      .update({ status: newStatus })
      .eq("id", orderId);

    if (!error) {
      setOrders((prev) => prev.map((o) => o.id === orderId ? { ...o, status: newStatus } : o));

      // When delivered: decrease stock + auto-add revenue
      if (newStatus === "delivered" && previousStatus !== "delivered" && order) {
        // Fetch order items to decrease stock
        let items = orderItems[orderId];
        if (!items) {
          const { data } = await supabase.from("order_items").select("*").eq("order_id", orderId);
          if (data) {
            items = data;
            setOrderItems((prev) => ({ ...prev, [orderId]: data }));
          }
        }
        if (items) {
          // Decrease stock for each item
          for (const item of items) {
            await supabase.rpc("has_role", { _user_id: user!.id, _role: "admin" as any }); // just to keep auth context
            const { data: menuItem } = await supabase
              .from("monthly_menu")
              .select("id, stock")
              .eq("cookie_name", item.cookie_name)
              .eq("is_active", true)
              .maybeSingle();
            if (menuItem) {
              await supabase
                .from("monthly_menu")
                .update({ stock: Math.max(0, menuItem.stock - item.quantity) } as any)
                .eq("id", menuItem.id);
            }
          }
        }

        // Auto-add revenue transaction
        await supabase.from("financial_transactions").insert({
          type: "income",
          category: "order_revenue",
          amount: order.total,
          description: `Đơn hàng ${order.order_code} giao thành công`,
          created_by: user!.id,
          reference_order_id: orderId,
        } as any);
      }
    }
    setUpdatingStatus(null);
  };

  const filteredOrders = orders.filter((o) => {
    const matchSearch = searchQuery === "" ||
      o.order_code.toLowerCase().includes(searchQuery.toLowerCase()) ||
      o.customer_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      o.phone.includes(searchQuery);
    const matchStatus = statusFilter === "all" || o.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const stats = {
    total: orders.length,
    pending: orders.filter((o) => o.status === "pending").length,
    revenue: orders.filter((o) => o.status === "delivered").reduce((s, o) => s + o.total, 0),
    today: orders.filter((o) => new Date(o.created_at).toDateString() === new Date().toDateString()).length,
  };

  if (authLoading || roleLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  // Admin OTP verification gate
  if (isAdmin && !adminVerified && isOtpRequired) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background px-4">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-md">
          <div className="mb-8 text-center">
            <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-primary/10">
              <ShieldCheck className="h-7 w-7 text-primary" />
            </div>
            <h1 className="font-display text-3xl font-extrabold text-foreground">Xác thực Admin</h1>
            {otpStep !== "checking_config" && (
              <p className="mt-2 text-sm text-muted-foreground">
                Mã 6 chữ số đã được gửi đến <span className="font-semibold text-foreground">{user?.email}</span>
              </p>
            )}
          </div>

          <div className="space-y-6 rounded-2xl border border-border bg-card p-6">
            {otpStep === "checking_config" || otpStep === "sending" ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-6 w-6 animate-spin text-primary" />
              </div>
            ) : (
              <>
                <div className="flex justify-center">
                  <InputOTP maxLength={6} value={otpCode} onChange={setOtpCode}>
                    <InputOTPGroup>
                      <InputOTPSlot index={0} />
                      <InputOTPSlot index={1} />
                      <InputOTPSlot index={2} />
                      <InputOTPSlot index={3} />
                      <InputOTPSlot index={4} />
                      <InputOTPSlot index={5} />
                    </InputOTPGroup>
                  </InputOTP>
                </div>

                <button
                  onClick={handleAdminOtpVerify}
                  disabled={otpLoading || otpCode.length !== 6}
                  className="w-full rounded-full bg-primary px-6 py-3 text-sm font-bold text-primary-foreground transition-transform hover:scale-[1.02] disabled:opacity-50"
                >
                  {otpLoading ? (
                    <span className="flex items-center justify-center gap-2">
                      <Loader2 className="h-4 w-4 animate-spin" />
                      Đang xác thực...
                    </span>
                  ) : "Xác nhận"}
                </button>

                <div className="flex items-center justify-between text-sm">
                  <button
                    onClick={handleResendAdminOtp}
                    disabled={otpLoading || resendCountdown > 0}
                    className="font-semibold text-primary hover:underline disabled:opacity-50 disabled:no-underline"
                  >
                    {resendCountdown > 0 ? `Gửi lại mã (${resendCountdown}s)` : "Gửi lại mã"}
                  </button>
                  <button
                    onClick={() => navigate("/")}
                    className="text-muted-foreground hover:text-foreground"
                  >
                    Quay lại
                  </button>
                </div>
              </>
            )}
          </div>
        </motion.div>
      </div>
    );
  }

  const sidebarItems = [
    { title: "Đơn hàng", icon: Package, tab: "orders" as Tab },
    { title: "Thống kê", icon: BarChart3, tab: "stats" as Tab },
    { title: "Tài chính", icon: DollarSign, tab: "finance" as Tab },
    { title: "Phụ phí", icon: Receipt, tab: "surcharges" as Tab },
    { title: "Voucher", icon: Ticket, tab: "vouchers" as Tab },
    { title: "Truy cập", icon: Eye, tab: "analytics" as Tab },
    { title: "Người dùng", icon: Users, tab: "users" as Tab },
    { title: "Phân quyền", icon: Shield, tab: "roles" as Tab },
    { title: "Giao diện", icon: Palette, tab: "interface" as Tab },
    { title: "Cài đặt", icon: Settings, tab: "settings" as Tab },
  ];

  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full bg-background">
        <Sidebar className="w-60 border-r border-border" collapsible="icon">
          <SidebarContent className="pt-4">
            <div className="mb-6 px-4">
              <h2 className="font-display text-lg font-extrabold text-foreground">Admin</h2>
              <p className="text-xs text-muted-foreground">Nova Cookie</p>
            </div>
            <SidebarGroup>
              <SidebarGroupLabel>Quản lý</SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  {sidebarItems.map((item) => (
                    <SidebarMenuItem key={item.tab}>
                      <SidebarMenuButton
                        onClick={() => setTab(item.tab)}
                        className={`cursor-pointer ${tab === item.tab ? "bg-primary/10 text-primary font-medium" : ""}`}
                      >
                        <item.icon className="mr-2 h-4 w-4" />
                        <span>{item.title}</span>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
            <div className="mt-auto px-4 py-4">
              <button
                onClick={() => navigate("/")}
                className="text-xs text-muted-foreground hover:text-foreground"
              >
                ← Về trang chủ
              </button>
            </div>
          </SidebarContent>
        </Sidebar>

        <main className="flex-1 p-6 md:p-8">
          <div className="mb-6 flex items-center gap-3">
            <SidebarTrigger />
            <h1 className="font-display text-2xl font-extrabold text-foreground">
              {sidebarItems.find((i) => i.tab === tab)?.title}
            </h1>
          </div>

          {/* Orders Tab */}
          {tab === "orders" && (
            <div className="space-y-4">
              <div className="flex flex-col gap-3 sm:flex-row">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <input
                    placeholder="Tìm mã đơn, tên, SĐT..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full rounded-xl border border-border bg-background py-2.5 pl-10 pr-4 text-sm outline-none focus:border-primary"
                  />
                </div>
                <div className="flex gap-2 flex-wrap">
                  {["all", ...STATUSES].map((s) => (
                    <button
                      key={s}
                      onClick={() => setStatusFilter(s)}
                      className={`rounded-full px-3 py-1.5 text-xs font-semibold transition-colors ${
                        statusFilter === s ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:bg-muted/80"
                      }`}
                    >
                      {s === "all" ? "Tất cả" : STATUS_MAP[s]?.label}
                    </button>
                  ))}
                </div>
                <button onClick={fetchOrders} className="rounded-xl border border-border p-2.5 hover:bg-muted">
                  <RefreshCw className="h-4 w-4" />
                </button>
              </div>

              {loading ? (
                <div className="flex justify-center py-20">
                  <Loader2 className="h-6 w-6 animate-spin text-primary" />
                </div>
              ) : filteredOrders.length === 0 ? (
                <div className="rounded-2xl border border-border bg-card p-10 text-center text-muted-foreground">
                  Không có đơn hàng nào
                </div>
              ) : (
                <div className="space-y-3">
                  {filteredOrders.map((order) => {
                    const status = STATUS_MAP[order.status] || STATUS_MAP.pending;
                    const StatusIcon = status.icon;
                    const isExpanded = expandedId === order.id;
                    const items = orderItems[order.id];
                    const paymentLabel = order.payment_status === "paid" ? "Đã TT" : order.payment_status === "expired" ? "Hết hạn" : "Chưa TT";
                    const paymentColor = order.payment_status === "paid" ? "text-primary bg-primary/10" : order.payment_status === "expired" ? "text-destructive bg-destructive/10" : "text-yellow-600 bg-yellow-50";
                    return (
                      <motion.div
                        key={order.id}
                        initial={{ opacity: 0, y: 5 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="rounded-2xl border border-border bg-card overflow-hidden hover:shadow-sm transition-shadow"
                      >
                        <div className="p-4 cursor-pointer" onClick={() => toggleExpand(order.id)}>
                          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1 flex-wrap">
                                <span className="font-mono text-sm font-bold text-foreground">{order.order_code}</span>
                                <span className={`flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-semibold ${status.color}`}>
                                  <StatusIcon className="h-3 w-3" />
                                  {status.label}
                                </span>
                                <span className={`rounded-full px-2 py-0.5 text-xs font-semibold ${paymentColor}`}>
                                  {paymentLabel}
                                </span>
                                <ChevronDown className={`h-4 w-4 text-muted-foreground transition-transform ml-auto ${isExpanded ? "rotate-180" : ""}`} />
                              </div>
                              <p className="text-sm text-foreground">{order.customer_name} · {order.phone}</p>
                              <p className="mt-1 text-xs text-muted-foreground">
                                {new Date(order.created_at).toLocaleString("vi-VN")} · {order.payment_method === "bank_transfer" ? "Chuyển khoản" : "Tiền mặt"}
                              </p>
                            </div>
                            <div className="flex items-center gap-3" onClick={(e) => e.stopPropagation()}>
                              <span className="font-bold text-primary">{formatPrice(order.total)}</span>
                              <div className="flex gap-1">
                                {STATUSES.map((s) => {
                                  const si = STATUS_MAP[s];
                                  const Icon = si.icon;
                                  const isCurrent = order.status === s;
                                  return (
                                    <button
                                      key={s}
                                      title={si.label}
                                      disabled={isCurrent || updatingStatus === order.id}
                                      onClick={() => updateOrderStatus(order.id, s)}
                                      className={`rounded-lg p-1.5 transition-colors ${
                                        isCurrent ? "bg-primary/10 text-primary" : "text-muted-foreground hover:bg-muted"
                                      } disabled:opacity-30`}
                                    >
                                      <Icon className="h-4 w-4" />
                                    </button>
                                  );
                                })}
                              </div>
                            </div>
                          </div>
                        </div>

                        <AnimatePresence>
                          {isExpanded && (
                            <motion.div
                              initial={{ height: 0, opacity: 0 }}
                              animate={{ height: "auto", opacity: 1 }}
                              exit={{ height: 0, opacity: 0 }}
                              className="border-t border-border"
                            >
                              <div className="p-4">
                                {/* Order code + copy */}
                                <div className="flex items-center gap-2 mb-4">
                                  <span className="font-mono text-lg font-bold text-foreground">{order.order_code}</span>
                                  <button onClick={() => copyToClipboard(order.order_code)} className="rounded-lg p-1 text-muted-foreground hover:bg-muted hover:text-foreground transition-colors" title="Sao chép mã đơn">
                                    <Copy className="h-4 w-4" />
                                  </button>
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                  {/* Left: Customer info */}
                                  <div className="space-y-3">
                                    <h4 className="text-xs font-semibold uppercase text-muted-foreground tracking-wider">Khách hàng</h4>
                                    
                                    <div className="flex items-center gap-2 text-sm text-foreground">
                                      <Phone className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                                      <a href={`tel:${order.phone}`} className="text-primary hover:underline font-medium">
                                        {order.phone}
                                      </a>
                                    </div>

                                    <div className="flex items-start gap-2 text-sm">
                                      <MapPin className="h-4 w-4 text-muted-foreground flex-shrink-0 mt-0.5" />
                                      <a
                                        href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(order.address)}`}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="text-primary hover:underline break-all"
                                      >
                                        {order.address}
                                        <ExternalLink className="inline-block h-3 w-3 ml-1 -mt-0.5" />
                                      </a>
                                    </div>

                                    <div className="flex items-center gap-2 text-sm text-foreground">
                                      <Calendar className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                                      <span>{new Date(order.created_at).toLocaleDateString("vi-VN", { weekday: "long", day: "2-digit", month: "2-digit", year: "numeric" })} · {new Date(order.created_at).toLocaleTimeString("vi-VN", { hour: "2-digit", minute: "2-digit" })}</span>
                                    </div>

                                    <div className="flex items-center gap-2 text-sm text-foreground">
                                      {order.payment_method === "bank_transfer" ? <CreditCard className="h-4 w-4 text-muted-foreground" /> : <Banknote className="h-4 w-4 text-muted-foreground" />}
                                      <span>{order.payment_method === "bank_transfer" ? "Chuyển khoản" : "Tiền mặt"}</span>
                                      <span className={`rounded-full px-2 py-0.5 text-xs font-semibold ${paymentColor}`}>{paymentLabel}</span>
                                    </div>

                                    {order.notes && (
                                      <div className="rounded-lg bg-muted/50 px-3 py-2 text-xs text-muted-foreground">📝 {order.notes}</div>
                                    )}
                                  </div>

                                  {/* Right: Order items + finance */}
                                  <div className="space-y-3">
                                    <h4 className="text-xs font-semibold uppercase text-muted-foreground tracking-wider">Chi tiết đơn</h4>
                                    {loadingItems === order.id ? (
                                      <Loader2 className="h-5 w-5 animate-spin text-primary mx-auto" />
                                    ) : items ? (
                                      <div className="space-y-2 text-sm">
                                        {items.map((item) => (
                                          <div key={item.id} className="flex justify-between">
                                            <span className="text-foreground">{item.cookie_name} × {item.quantity}</span>
                                            <span className="text-foreground font-medium">{formatPrice(item.total_price)}</span>
                                          </div>
                                        ))}
                                        <div className="border-t border-border pt-2 space-y-1">
                                          <div className="flex justify-between text-xs">
                                            <span className="text-muted-foreground">Tạm tính</span>
                                            <span>{formatPrice(order.subtotal)}</span>
                                          </div>
                                          <div className="flex justify-between text-xs">
                                            <span className="text-muted-foreground">Ship</span>
                                            <span>{order.shipping_fee === 0 ? "Miễn phí" : formatPrice(order.shipping_fee)}</span>
                                          </div>
                                          <div className="flex justify-between text-xs text-primary">
                                            <span>🌱 Quỹ xanh</span>
                                            <span>{formatPrice(order.green_fund_amount)}</span>
                                          </div>
                                          {orderVouchers[order.id] && (
                                            <div className="flex justify-between text-xs text-accent-foreground">
                                              <span className="flex items-center gap-1"><Tag className="h-3 w-3" /> Voucher: {orderVouchers[order.id].code}</span>
                                              <span>-{orderVouchers[order.id].voucher_templates?.type === "percent" ? `${orderVouchers[order.id].voucher_templates.value}%` : formatPrice(orderVouchers[order.id].voucher_templates?.value || 0)}</span>
                                            </div>
                                          )}
                                          <div className="flex justify-between text-sm font-bold pt-1 border-t border-border">
                                            <span>Tổng</span>
                                            <span className="text-primary">{formatPrice(order.total)}</span>
                                          </div>
                                        </div>
                                      </div>
                                    ) : null}
                                  </div>
                                </div>
                              </div>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </motion.div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* Stats Tab */}
          {tab === "stats" && <StatsTab orders={orders} />}

          {/* Finance Tab */}
          {tab === "finance" && <FinanceTab />}

          {/* Surcharges Tab */}
          {tab === "surcharges" && <SurchargesTab />}

          {/* Users Tab */}
          {tab === "users" && <UsersTab />}

          {/* Roles Tab */}
          {tab === "roles" && <RolesTab />}

          {/* Analytics Tab */}
          {tab === "analytics" && <AnalyticsTab />}

          {/* Voucher Tab */}
          {tab === "vouchers" && <VoucherManagement />}

          {/* Interface Tab */}
          {tab === "interface" && <InterfaceSettings />}

          {/* Settings Tab */}
          {tab === "settings" && <SettingsTab />}
        </main>
      </div>
    </SidebarProvider>
  );
};

export default AdminDashboard;
