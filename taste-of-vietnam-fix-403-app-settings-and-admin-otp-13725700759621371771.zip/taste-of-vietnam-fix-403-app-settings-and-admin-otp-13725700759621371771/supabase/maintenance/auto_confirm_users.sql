-- ==============================================================================
-- GIẢI PHÁP TỰ ĐỘNG XÁC NHẬN EMAIL (AUTO-CONFIRM EMAIL)
-- Sửa lỗi: "Email not confirmed" sau khi đã nhập mã OTP thành công.
-- ==============================================================================
-- Lý do:
-- Hệ thống của bạn đang sử dụng hệ thống xác thực OTP 6 số riêng (Custom Edge Functions).
-- Khi người dùng nhập đúng OTP -> Frontend gọi lệnh signUp().
-- Tuy nhiên, cài đặt mặc định của Supabase Auth bắt buộc người dùng phải click vào link
-- do Supabase gửi đi mới cho phép login. Do đó tạo ra lỗi "Email not confirmed".
--
-- Cách xử lý:
-- Chúng ta tạo một trigger trên bảng auth.users. Bất cứ khi nào tài khoản mới được tạo ra,
-- nếu email_confirmed_at chưa có, hệ thống sẽ TỰ ĐỘNG điền vào (vì họ đã vượt qua vòng nhập OTP rồi).

CREATE OR REPLACE FUNCTION public.auto_confirm_user_email()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Tự động đánh dấu email đã được xác nhận (bỏ qua email link mặc định của Supabase)
  IF new.email_confirmed_at IS NULL THEN
    new.email_confirmed_at := now();
  END IF;

  RETURN new;
END;
$$;

-- Gắn trigger này vào hành động INSERT TRƯỚC (BEFORE INSERT) trên bảng auth.users
DROP TRIGGER IF EXISTS on_auth_user_created_auto_confirm ON auth.users;
CREATE TRIGGER on_auth_user_created_auto_confirm
  BEFORE INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.auto_confirm_user_email();
