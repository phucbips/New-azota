#!/bin/bash

# Configuration
PROJECT_ID="iiglwrhbdddmgfzsmimv"

# Secrets (Taken from your .env)
# Note: In a real production environment, avoid hardcoding secrets in scripts.
# Since this is a migration helper for your specific setup, we include them here.
PAYOS_CLIENT_ID="1a638ff8-08ab-4aad-9fa7-494564869d47"
PAYOS_API_KEY="fdfb8b9c-43f7-435b-94b6-21db1f2066db"
PAYOS_CHECKSUM_KEY="671edca74d7eda213e4af046a0e516a91b8ab45686544c67cb7815f6744d30d1"

CLOUDINARY_CLOUD_NAME="dkkvom3um"
CLOUDINARY_API_KEY="391519533335144"
CLOUDINARY_API_SECRET="B-lqnQ6M-CcQs174Mvqg6KyzMC0"

# Note: RESEND_API_KEY and ADMIN_NOTIFICATION_EMAIL were empty in .env
# You will need to set them manually or update this script if you have them.
# RESEND_API_KEY="your_resend_key"
# ADMIN_NOTIFICATION_EMAIL="your_email"

echo "🚀 Starting Supabase Edge Functions Deployment..."

# Check for Supabase CLI
if ! command -v supabase &> /dev/null; then
    if ! command -v npx &> /dev/null; then
        echo "❌ Error: Neither 'supabase' CLI nor 'npx' found."
        exit 1
    else
        SUPABASE_CMD="npx supabase"
    fi
else
    SUPABASE_CMD="supabase"
fi

echo "✅ Using command: $SUPABASE_CMD"

# Link Project
echo "🔗 Linking to project $PROJECT_ID..."
# You might be prompted for your database password here
$SUPABASE_CMD link --project-ref "$PROJECT_ID"

# Set Secrets
echo "🔑 Setting secrets..."
$SUPABASE_CMD secrets set \
    PAYOS_CLIENT_ID="$PAYOS_CLIENT_ID" \
    PAYOS_API_KEY="$PAYOS_API_KEY" \
    PAYOS_CHECKSUM_KEY="$PAYOS_CHECKSUM_KEY" \
    CLOUDINARY_CLOUD_NAME="$CLOUDINARY_CLOUD_NAME" \
    CLOUDINARY_API_KEY="$CLOUDINARY_API_KEY" \
    CLOUDINARY_API_SECRET="$CLOUDINARY_API_SECRET"

echo "✅ Secrets set successfully."

# Deploy Functions
echo "🚀 Deploying functions..."
$SUPABASE_CMD functions deploy

echo "🎉 Deployment complete! Your backend functions are now live on the new project."
