-- ==============================================================================
-- FIX LỖI 500: VIOLATES CHECK CONSTRAINT "verification_codes_type_check"
-- ==============================================================================
-- Vấn đề: Cột `type` của bảng `verification_codes` đang có một ràng buộc (CHECK constraint).
-- Ràng buộc cũ có thể chỉ cho phép giá trị 'admin_login' và 'password_reset',
-- nhưng bây giờ Frontend đang gửi thêm giá trị 'signup_verify'.
-- Điều này khiến Postgres từ chối câu lệnh INSERT và Edge Function quăng lỗi 500.

-- Cách khắc phục: Bỏ ràng buộc đó đi (hoặc cập nhật lại). Ở đây mình sẽ cập nhật lại
-- cho nó nhận cả 3 giá trị, hoặc bỏ luôn cho thoải mái. An toàn nhất là DROP.

ALTER TABLE public.verification_codes DROP CONSTRAINT IF EXISTS verification_codes_type_check;

-- Nếu muốn đảm bảo dữ liệu luôn chuẩn, bạn có thể chạy dòng dưới để thêm lại Constraint mới với đủ 3 types:
ALTER TABLE public.verification_codes ADD CONSTRAINT verification_codes_type_check
CHECK (type IN ('admin_login', 'password_reset', 'signup_verify'));
