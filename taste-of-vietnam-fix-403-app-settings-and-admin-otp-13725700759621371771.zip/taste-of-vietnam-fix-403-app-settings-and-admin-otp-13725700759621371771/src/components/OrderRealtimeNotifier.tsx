import { useEffect, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useRole } from "@/hooks/useRole";
import { toast } from "sonner";

const playNotificationSound = () => {
  try {
    const ctx = new AudioContext();
    const now = ctx.currentTime;

    // Pleasant two-tone chime
    const frequencies = [523.25, 659.25, 783.99]; // C5, E5, G5
    frequencies.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.value = freq;
      gain.gain.setValueAtTime(0, now + i * 0.15);
      gain.gain.linearRampToValueAtTime(0.3, now + i * 0.15 + 0.05);
      gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.15 + 0.5);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now + i * 0.15);
      osc.stop(now + i * 0.15 + 0.5);
    });
  } catch (e) {
    // AudioContext not available, skip sound
  }
};

const OrderRealtimeNotifier = () => {
  const { isAdmin, isBaker } = useRole();

  useEffect(() => {
    if (!isAdmin && !isBaker) return;

    const channel = supabase
      .channel("new-orders")
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "orders",
        },
        (payload) => {
          const order = payload.new as any;
          playNotificationSound();
          toast.info(`🍪 Đơn hàng mới #${order.order_code}`, {
            description: `${order.customer_name} — ${new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND" }).format(order.total)}`,
            duration: 8000,
          });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [isAdmin, isBaker]);

  return null;
};

export default OrderRealtimeNotifier;
