-- ==============================================================================
-- ULTIMATE NUKE & REBUILD CHO SUPABASE AUTH LOGIC
-- ==============================================================================
-- Lưu ý: Kịch bản này không xóa DATA của bạn. Nó chỉ xóa CẤU TRÚC PHÂN QUYỀN
-- và các TRIGGER bị lỗi, sau đó xây lại từ đầu.

-- ------------------------------------------------------------------------------
-- BƯỚC 1: QUÉT SẠCH CÁC TRIGGER VÀ FUNCTION LỖI
-- ------------------------------------------------------------------------------
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP FUNCTION IF EXISTS public.handle_new_user() CASCADE;

-- ------------------------------------------------------------------------------
-- BƯỚC 2: QUÉT SẠCH RLS POLICY (BẰNG DO BLOCK ĐỂ KHÔNG BỊ BÁO LỖI NẾU KHÔNG CÓ)
-- ------------------------------------------------------------------------------
DO $$
DECLARE
    pol RECORD;
BEGIN
    FOR pol IN SELECT policyname, tablename FROM pg_policies WHERE schemaname = 'public' AND tablename IN ('profiles', 'user_roles', 'verification_codes')
    LOOP
        EXECUTE format('DROP POLICY IF EXISTS %I ON public.%I', pol.policyname, pol.tablename);
    END LOOP;
END
$$;

-- ------------------------------------------------------------------------------
-- BƯỚC 3: THU HỒI TOÀN BỘ QUYỀN VÀ CẤP LẠI (RESET GRANTS)
-- ------------------------------------------------------------------------------
-- Hủy mọi quyền đang có
REVOKE ALL ON SCHEMA public FROM PUBLIC, anon, authenticated, service_role;
REVOKE ALL ON ALL TABLES IN SCHEMA public FROM PUBLIC, anon, authenticated, service_role;

-- Cấp lại quyền trên Schema cho các role cơ bản
GRANT USAGE ON SCHEMA public TO postgres, anon, authenticated, service_role;

-- Cấp quyền mặc định trên TẤT CẢ bảng hiện tại
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO postgres, service_role;
GRANT SELECT ON ALL TABLES IN SCHEMA public TO anon, authenticated;

-- *Riêng bảng verification_codes, cấm tuyệt đối khách và người dùng*
REVOKE ALL ON public.verification_codes FROM anon, authenticated;
-- (Service role đã có quyền ALL nhờ lệnh trên)

-- *Riêng bảng user_roles, khách chỉ được đọc*
REVOKE INSERT, UPDATE, DELETE ON public.user_roles FROM anon, authenticated;

-- *Riêng bảng profiles, User được tự sửa*
GRANT INSERT, UPDATE, DELETE ON public.profiles TO authenticated;

-- ------------------------------------------------------------------------------
-- BƯỚC 4: BẬT RLS (ROW LEVEL SECURITY)
-- ------------------------------------------------------------------------------
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.verification_codes ENABLE ROW LEVEL SECURITY;

-- ------------------------------------------------------------------------------
-- BƯỚC 5: TẠO POLICY "KIM CƯƠNG" CHO TỪNG BẢNG
-- ------------------------------------------------------------------------------

-- [Bảng profiles]
CREATE POLICY "Public_Select_Profiles" ON public.profiles FOR SELECT USING (true);
CREATE POLICY "Auth_Manage_Own_Profile" ON public.profiles FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- [Bảng user_roles]
CREATE POLICY "Public_Select_UserRoles" ON public.user_roles FOR SELECT USING (true);
-- Lưu ý: Không có policy INSERT/UPDATE/DELETE cho authenticated user thường. Role chỉ do Trigger hoặc Admin cấp.

-- [Bảng verification_codes]
-- Chìa khóa vàng: Bảng này chỉ service_role mới nhìn thấy, điều này bắt buộc Edge Function dùng khóa Service Role.
CREATE POLICY "ServiceRole_All_VerificationCodes" ON public.verification_codes FOR ALL TO service_role USING (true) WITH CHECK (true);


-- ------------------------------------------------------------------------------
-- BƯỚC 6: XÂY DỰNG LẠI TRIGGER CHỐNG ĐỔ VỠ (CRASH-PROOF)
-- ------------------------------------------------------------------------------
-- Dùng thuộc tính "SECURITY DEFINER" để trigger chạy với quyền postgres (admin) thay vì quyền user gọi,
-- và set "search_path = public" theo khuyến cáo của Supabase.
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Insert Profile
  BEGIN
    INSERT INTO public.profiles (user_id, full_name, created_at)
    VALUES (
      new.id,
      COALESCE(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name', 'User'),
      now()
    )
    ON CONFLICT (user_id) DO NOTHING;
  EXCEPTION WHEN OTHERS THEN
    -- Nếu lỗi, không làm gì cả, cứ tiếp tục chạy
  END;

  -- Insert Default Role
  BEGIN
    INSERT INTO public.user_roles (user_id, role)
    VALUES (new.id, 'user')
    ON CONFLICT (user_id, role) DO NOTHING;
  EXCEPTION WHEN OTHERS THEN
    -- Nếu lỗi, không làm gì cả, cứ tiếp tục chạy
  END;

  RETURN new;
END;
$$;

-- Gắn lại Trigger
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
