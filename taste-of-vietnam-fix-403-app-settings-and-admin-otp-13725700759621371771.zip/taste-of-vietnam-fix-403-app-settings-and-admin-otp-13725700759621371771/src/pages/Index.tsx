import { useState, useEffect } from "react";
import Navbar from "@/components/Navbar";
import HeroSection from "@/components/home/HeroSection";
import MenuSection from "@/components/home/MenuSection";
import AboutSection from "@/components/home/AboutSection";
import GreenFundSection from "@/components/home/GreenFundSection";
import TestimonialCarousel from "@/components/home/TestimonialCarousel";
import Footer from "@/components/Footer";
import ProfileCompletionModal from "@/components/ProfileCompletionModal";
import { useAuth } from "@/hooks/useAuth";
import { useProfile } from "@/hooks/useProfile";
import { supabase } from "@/integrations/supabase/client";
import { useQuery } from "@tanstack/react-query";

interface HomepageSections {
  hero: boolean;
  menu: boolean;
  testimonials: boolean;
  about: boolean;
  green_fund: boolean;
}

const DEFAULT_SECTIONS: HomepageSections = {
  hero: true,
  menu: true,
  testimonials: true,
  about: true,
  green_fund: true,
};

const DEFAULT_ORDER = ["hero", "menu", "testimonials", "about", "green_fund"];

const SECTION_COMPONENTS: Record<string, React.FC<any>> = {
  hero: HeroSection,
  menu: MenuSection,
  testimonials: TestimonialCarousel,
  about: AboutSection,
  green_fund: GreenFundSection,
};

const Index = () => {
  const { user } = useAuth();
  const { needsCompletion, loading, refetch } = useProfile();
  const [showModal, setShowModal] = useState(false);

  const { data: siteConfig } = useQuery({
    queryKey: ["homepage-config"],
    queryFn: async () => {
      const { data } = await supabase
        .from("app_settings")
        .select("key, value")
        .in("key", ["HOMEPAGE_SECTIONS", "SECTION_ORDER"]);

      let sections = DEFAULT_SECTIONS;
      let order = DEFAULT_ORDER;

      if (data) {
        data.forEach((row) => {
          try {
            const parsed = JSON.parse(row.value);
            if (row.key === "HOMEPAGE_SECTIONS") sections = { ...DEFAULT_SECTIONS, ...parsed };
            if (row.key === "SECTION_ORDER" && Array.isArray(parsed)) order = parsed;
          } catch {}
        });
      }

      return { sections, order };
    },
    staleTime: 60_000,
  });

  const sections = siteConfig?.sections ?? DEFAULT_SECTIONS;
  const sectionOrder = siteConfig?.order ?? DEFAULT_ORDER;

  useEffect(() => {
    if (user && !loading && needsCompletion) {
      const dismissed = sessionStorage.getItem("profile_modal_dismissed");
      if (!dismissed) {
        setShowModal(true);
      }
    }
  }, [user, loading, needsCompletion]);

  const handleCloseModal = () => {
    sessionStorage.setItem("profile_modal_dismissed", "1");
    setShowModal(false);
    refetch();
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main>
        {sectionOrder.map((key) => {
          if (!sections[key as keyof HomepageSections]) return null;
          const Component = SECTION_COMPONENTS[key];
          if (!Component) return null;
          return <Component key={key} />;
        })}
      </main>
      <Footer />
      <ProfileCompletionModal open={showModal} onClose={handleCloseModal} />
    </div>
  );
};

export default Index;
