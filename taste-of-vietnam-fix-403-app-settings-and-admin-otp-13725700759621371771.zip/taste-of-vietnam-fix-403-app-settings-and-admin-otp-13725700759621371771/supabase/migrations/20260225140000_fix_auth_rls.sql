-- Fix authenticated user access to their own data

-- 1. PROFILES
-- Allow authenticated users to read and update their own profile
DROP POLICY IF EXISTS "Users can view own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can update own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can insert own profile" ON public.profiles;

CREATE POLICY "Users can view own profile"
ON public.profiles FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can update own profile"
ON public.profiles FOR UPDATE
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own profile"
ON public.profiles FOR INSERT
WITH CHECK (auth.uid() = user_id);

-- Also ensure public read for leaderboard/reviews as previously discussed
CREATE POLICY "Anyone can view profiles"
ON public.profiles FOR SELECT
USING (true);

-- 2. USER_ROLES
-- Allow users to read their own roles (essential for UI to know if they are admin/baker)
DROP POLICY IF EXISTS "Users can read own roles" ON public.user_roles;

CREATE POLICY "Users can read own roles"
ON public.user_roles FOR SELECT
USING (auth.uid() = user_id);

-- 3. ORDERS
-- Allow users to read their own orders
DROP POLICY IF EXISTS "Users can view own orders" ON public.orders;

CREATE POLICY "Users can view own orders"
ON public.orders FOR SELECT
USING (auth.uid() = user_id);

-- 4. VERIFICATION_CODES (For Edge Function usage via Service Role - bypasses RLS, but safe to add policy if client access needed)
-- Generally, clients shouldn't read verification codes directly for security.
-- But if the Edge Function uses Service Role, it bypasses RLS.
-- Ensure RLS is enabled to prevent public access.
ALTER TABLE public.verification_codes ENABLE ROW LEVEL SECURITY;

-- 5. Grant permissions to authenticated role
GRANT SELECT, INSERT, UPDATE ON public.profiles TO authenticated;
GRANT SELECT ON public.user_roles TO authenticated;
GRANT SELECT ON public.orders TO authenticated;
