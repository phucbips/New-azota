-- 0. Ensure Dependencies Exist

-- Create app_role enum if it doesn't exist
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'app_role') THEN
        CREATE TYPE app_role AS ENUM ('admin', 'baker', 'customer');
    END IF;
END$$;

-- Create user_roles table if it doesn't exist (Critical for permissions)
CREATE TABLE IF NOT EXISTS user_roles (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  role app_role NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(user_id, role)
);

ALTER TABLE user_roles ENABLE ROW LEVEL SECURITY;

-- Helper function: public.has_role
-- This is essential for the RLS policies to work.
CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role app_role)
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 1. Create Tables if they don't exist

-- Table: financial_transactions
CREATE TABLE IF NOT EXISTS financial_transactions (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  created_at TIMESTAMPTZ DEFAULT now() NOT NULL,
  amount NUMERIC NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('income', 'expense')),
  category TEXT NOT NULL,
  description TEXT,
  created_by UUID REFERENCES auth.users(id),
  reference_order_id UUID REFERENCES orders(id)
);

-- Table: order_surcharges
CREATE TABLE IF NOT EXISTS order_surcharges (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  created_at TIMESTAMPTZ DEFAULT now() NOT NULL,
  name TEXT NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('fixed', 'percent')),
  value NUMERIC NOT NULL,
  is_active BOOLEAN DEFAULT true,
  is_default BOOLEAN DEFAULT false
);

-- Table: page_views
CREATE TABLE IF NOT EXISTS page_views (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  created_at TIMESTAMPTZ DEFAULT now() NOT NULL,
  path TEXT NOT NULL,
  user_agent TEXT,
  device_type TEXT,
  browser TEXT
);

-- Table: app_settings
CREATE TABLE IF NOT EXISTS app_settings (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  created_at TIMESTAMPTZ DEFAULT now() NOT NULL,
  key TEXT NOT NULL UNIQUE,
  value TEXT
);

-- 2. Enable Row Level Security (RLS)

ALTER TABLE financial_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE order_surcharges ENABLE ROW LEVEL SECURITY;
ALTER TABLE page_views ENABLE ROW LEVEL SECURITY;
ALTER TABLE app_settings ENABLE ROW LEVEL SECURITY;

-- 3. Create Policies

-- Policies for financial_transactions
DROP POLICY IF EXISTS "Admins can manage financial transactions" ON financial_transactions;
CREATE POLICY "Admins can manage financial transactions"
ON financial_transactions
FOR ALL
USING (
  public.has_role(auth.uid(), 'admin')
)
WITH CHECK (
  public.has_role(auth.uid(), 'admin')
);

-- Policies for order_surcharges
DROP POLICY IF EXISTS "Admins can manage surcharges" ON order_surcharges;
CREATE POLICY "Admins can manage surcharges"
ON order_surcharges
FOR ALL
USING (
  public.has_role(auth.uid(), 'admin')
)
WITH CHECK (
  public.has_role(auth.uid(), 'admin')
);

DROP POLICY IF EXISTS "Public can view active surcharges" ON order_surcharges;
CREATE POLICY "Public can view active surcharges"
ON order_surcharges
FOR SELECT
USING (
  is_active = true
);

-- Policies for page_views
DROP POLICY IF EXISTS "Public can insert page views" ON page_views;
CREATE POLICY "Public can insert page views"
ON page_views
FOR INSERT
WITH CHECK (true);

DROP POLICY IF EXISTS "Admins can view page views" ON page_views;
CREATE POLICY "Admins can view page views"
ON page_views
FOR SELECT
USING (
  public.has_role(auth.uid(), 'admin')
);

-- Policies for app_settings
DROP POLICY IF EXISTS "Admins can manage app settings" ON app_settings;
CREATE POLICY "Admins can manage app settings"
ON app_settings
FOR ALL
USING (
  public.has_role(auth.uid(), 'admin')
)
WITH CHECK (
  public.has_role(auth.uid(), 'admin')
);

DROP POLICY IF EXISTS "Public can view public settings" ON app_settings;
CREATE POLICY "Public can view public settings"
ON app_settings
FOR SELECT
USING (
  key IN ('SOCIAL_LINKS', 'SHIPPING_ZONE_CONFIG', 'CONTACT_INFO', 'HERO_CONFIG', 'HOMEPAGE_SECTIONS', 'SECTION_ORDER')
);
