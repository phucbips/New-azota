import cookieCom from "@/assets/cookie-com.jpg";
import cookieDua from "@/assets/cookie-dua.jpg";
import cookieMatcha from "@/assets/cookie-matcha.jpg";
import cookieQue from "@/assets/cookie-que.jpg";
import cookieCacao from "@/assets/cookie-cacao.jpg";

export interface CookieFlavor {
  id: string;
  name: string;
  province: string;
  region: "Bắc" | "Trung" | "Nam";
  description: string;
  ingredient: string;
  price: number;
  image: string;
}

export const MONTHLY_MENU: CookieFlavor[] = [
  {
    id: "1",
    name: "Cookie Cốm Hà Nội",
    province: "Hà Nội",
    region: "Bắc",
    description: "Vị cốm xanh dịu dàng, thơm mùi lúa non đặc trưng của mùa thu Hà Nội.",
    ingredient: "Cốm tươi Vòng",
    price: 25000,
    image: cookieCom,
  },
  {
    id: "2",
    name: "Cookie Dừa Bến Tre",
    province: "Bến Tre",
    region: "Nam",
    description: "Béo ngậy từ dừa nước Bến Tre, kết hợp chocolate chips.",
    ingredient: "Dừa nạo tươi",
    price: 25000,
    image: cookieDua,
  },
  {
    id: "3",
    name: "Cookie Matcha Lâm Đồng",
    province: "Lâm Đồng",
    region: "Trung",
    description: "Trà xanh Bảo Lộc thượng hạng, đắng nhẹ, hậu ngọt thanh.",
    ingredient: "Matcha Bảo Lộc",
    price: 28000,
    image: cookieMatcha,
  },
  {
    id: "4",
    name: "Cookie Quế Yên Bái",
    province: "Yên Bái",
    region: "Bắc",
    description: "Quế Văn Yên cay nồng ấm, hòa quyện bơ mặn Pháp.",
    ingredient: "Quế Văn Yên",
    price: 25000,
    image: cookieQue,
  },
  {
    id: "5",
    name: "Cookie Cacao Đắk Lắk",
    province: "Đắk Lắk",
    region: "Trung",
    description: "Cacao nguyên chất Tây Nguyên, đậm đà, hơi đắng, rất thơm.",
    ingredient: "Cacao Đắk Lắk",
    price: 28000,
    image: cookieCacao,
  },
];

export const CURRENT_MONTH = "Tháng 3/2026";

export const formatPrice = (price: number) =>
  new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND" }).format(price);
