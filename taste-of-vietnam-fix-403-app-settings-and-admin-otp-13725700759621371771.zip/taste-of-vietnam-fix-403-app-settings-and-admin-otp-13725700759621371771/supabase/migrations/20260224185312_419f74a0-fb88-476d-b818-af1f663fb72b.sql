
-- Add new columns to voucher_templates
ALTER TABLE public.voucher_templates
  ADD COLUMN IF NOT EXISTS valid_from timestamptz,
  ADD COLUMN IF NOT EXISTS valid_until timestamptz,
  ADD COLUMN IF NOT EXISTS distribution_type text NOT NULL DEFAULT 'reward',
  ADD COLUMN IF NOT EXISTS promo_code text;

-- Create unique index on promo_code for promo vouchers
CREATE UNIQUE INDEX IF NOT EXISTS idx_voucher_templates_promo_code 
  ON public.voucher_templates (promo_code) 
  WHERE promo_code IS NOT NULL;

-- Allow authenticated users to query voucher_templates by promo_code
CREATE POLICY "Authenticated users can check promo vouchers"
  ON public.voucher_templates
  FOR SELECT
  USING (distribution_type = 'promo' AND promo_code IS NOT NULL);
