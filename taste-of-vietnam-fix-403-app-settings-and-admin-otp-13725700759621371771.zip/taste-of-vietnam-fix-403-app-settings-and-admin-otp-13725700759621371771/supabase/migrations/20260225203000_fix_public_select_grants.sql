-- ==============================================================================
-- BẢN VÁ QUYỀN TRUY CẬP DỮ LIỆU CÔNG KHAI (KHẮC PHỤC 403 SELECT)
-- ==============================================================================

-- 1. Bảng VOTES (Dữ liệu bình chọn)
-- Cấp quyền Database cho phép ai cũng có thể đọc (quan trọng nhất)
GRANT SELECT ON public.votes TO anon, authenticated;

-- Xóa Policy cũ (nếu có) và tạo lại Policy mới cực kỳ mở cho việc ĐỌC
DROP POLICY IF EXISTS "Anyone can view votes" ON public.votes;
CREATE POLICY "Anyone can view votes" ON public.votes FOR SELECT TO public USING (true);


-- 2. Bảng MONTHLY_MENU (Dữ liệu Menu)
-- Đảm bảo quyền Database được cấp phát
GRANT SELECT ON public.monthly_menu TO anon, authenticated;

-- Củng cố lại Policy ĐỌC cho tất cả mọi người
DROP POLICY IF EXISTS "Anyone can view menu" ON public.monthly_menu;
CREATE POLICY "Anyone can view menu" ON public.monthly_menu FOR SELECT TO public USING (true);


-- 3. Bảng APP_SETTINGS (Cài đặt giao diện)
-- Frontend cần đọc cái này để biết render cái gì
GRANT SELECT ON public.app_settings TO anon, authenticated;

DROP POLICY IF EXISTS "Anyone can read settings" ON public.app_settings;
CREATE POLICY "Anyone can read settings" ON public.app_settings FOR SELECT TO public USING (true);


-- 4. Bảng ORDER_SURCHARGES (Phụ phí)
-- Khách hàng cần xem phụ phí lúc checkout
GRANT SELECT ON public.order_surcharges TO anon, authenticated;

DROP POLICY IF EXISTS "Anyone can view surcharges" ON public.order_surcharges;
CREATE POLICY "Anyone can view surcharges" ON public.order_surcharges FOR SELECT TO public USING (true);


-- Bắt buộc Supabase tải lại cấu hình để nhận diện quyền mới
NOTIFY pgrst, 'reload config';
