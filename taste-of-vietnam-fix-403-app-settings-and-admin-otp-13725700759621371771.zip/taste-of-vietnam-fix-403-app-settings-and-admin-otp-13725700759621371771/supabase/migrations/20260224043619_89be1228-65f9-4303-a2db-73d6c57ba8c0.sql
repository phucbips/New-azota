-- Create storage bucket for cookie images
INSERT INTO storage.buckets (id, name, public) VALUES ('cookie-images', 'cookie-images', true);

-- Anyone can view cookie images (public bucket)
CREATE POLICY "Cookie images are publicly accessible"
ON storage.objects FOR SELECT
USING (bucket_id = 'cookie-images');

-- Admins and bakers can upload cookie images
CREATE POLICY "Admins and bakers can upload cookie images"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'cookie-images'
  AND (has_role(auth.uid(), 'admin') OR has_role(auth.uid(), 'baker'))
);

-- Admins and bakers can update cookie images
CREATE POLICY "Admins and bakers can update cookie images"
ON storage.objects FOR UPDATE
USING (
  bucket_id = 'cookie-images'
  AND (has_role(auth.uid(), 'admin') OR has_role(auth.uid(), 'baker'))
);

-- Admins and bakers can delete cookie images
CREATE POLICY "Admins and bakers can delete cookie images"
ON storage.objects FOR DELETE
USING (
  bucket_id = 'cookie-images'
  AND (has_role(auth.uid(), 'admin') OR has_role(auth.uid(), 'baker'))
);