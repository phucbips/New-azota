
-- Table for storing verification codes (admin OTP + password reset)
CREATE TABLE public.verification_codes (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  email TEXT NOT NULL,
  code TEXT NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('admin_login', 'password_reset')),
  expires_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT (now() + interval '5 minutes'),
  is_used BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.verification_codes ENABLE ROW LEVEL SECURITY;

-- Only service role can manage verification codes (edge functions use service role)
-- No public access policies needed - all operations go through edge functions

-- Index for quick lookups
CREATE INDEX idx_verification_codes_email_type ON public.verification_codes (email, type, is_used);

-- Auto-cleanup old codes (optional - keep table clean)
CREATE OR REPLACE FUNCTION public.cleanup_expired_codes()
RETURNS void
LANGUAGE sql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
  DELETE FROM public.verification_codes WHERE expires_at < now() - interval '1 hour';
$$;
