import { useState, useMemo, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Minus, Plus, ShoppingBag, CreditCard, Banknote, QrCode, ArrowLeft, Check, Loader2, Heart, Star, MessageSquare, LogIn, Timer, MapPin, Navigation, Search, Ticket, X, Truck } from "lucide-react";
import { useGeolocation } from "@/hooks/useGeolocation";
import AddressMap from "@/components/AddressMap";
import { Link, useNavigate } from "react-router-dom";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { CURRENT_MONTH, formatPrice } from "@/data/mockMenu";
import { CornerVine, MotifDivider } from "@/components/decorations/VietnameseMotifs";
import { z } from "zod";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useProfile } from "@/hooks/useProfile";
import ProfileCompletionModal from "@/components/ProfileCompletionModal";

const FREE_SHIP_THRESHOLD = 150000;
const PAYMENT_TIMEOUT_MS = 10 * 60 * 1000; // 10 minutes

// Haversine distance in km
const haversineDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
};

interface PickupPoint {
  name: string;
  address: string;
  lat: number;
  lng: number;
  radius_km: number;
}

interface ShippingZoneConfig {
  pickup_points: PickupPoint[];
}

interface Surcharge {
  id: string;
  name: string;
  type: string; // 'fixed' | 'percent'
  value: number;
  is_active: boolean;
  is_default: boolean;
}

const customerSchema = z.object({
  name: z.string().trim().min(1, "Vui lòng nhập tên").max(100),
  phone: z.string().trim().regex(/^0\d{9}$/, "Số điện thoại không hợp lệ (VD: 0912345678)"),
  address: z.string().trim().min(5, "Vui lòng nhập địa chỉ giao hàng").max(300),
  note: z.string().max(500).optional(),
});

type PaymentMethod = "transfer" | "cash";
type Step = "select" | "info" | "payment" | "paying" | "done";

interface MenuItem {
  id: string;
  cookie_name: string;
  description: string | null;
  origin: string | null;
  price: number;
  image_url: string | null;
  stock: number;
  month_year: string;
  display_order: number;
  is_active: boolean;
}

// Generate short user code from user ID (first 4 chars)
const getUserShortCode = (userId: string) => userId.replace(/-/g, "").slice(0, 4).toUpperCase();

const Order = () => {
  const { user, loading: authLoading } = useAuth();
  const { profile, needsCompletion, refetch: refetchProfile } = useProfile();
  const navigate = useNavigate();
  const [quantities, setQuantities] = useState<Record<string, number>>({});
  const [step, setStep] = useState<Step>("select");
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>("transfer");
  const [customer, setCustomer] = useState({ name: "", phone: "", address: "", note: "" });
  const [useDefault, setUseDefault] = useState(true);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const geoOrder = useGeolocation((addr) => {
    setCustomer((prev) => ({ ...prev, address: addr }));
    if (errors.address) setErrors((prev) => ({ ...prev, address: "" }));
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [votedCookie, setVotedCookie] = useState<string | null>(null);
  const [isVoting, setIsVoting] = useState(false);
  const [hasVoted, setHasVoted] = useState(false);
  const [existingVoteCookie, setExistingVoteCookie] = useState<string | null>(null);
  const [feedbackRating, setFeedbackRating] = useState(0);
  const [feedbackHover, setFeedbackHover] = useState(0);
  const [feedbackComment, setFeedbackComment] = useState("");
  const [isSubmittingFeedback, setIsSubmittingFeedback] = useState(false);
  const [hasFeedback, setHasFeedback] = useState(false);
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [menuLoading, setMenuLoading] = useState(true);
  // Surcharges
  const [surcharges, setSurcharges] = useState<Surcharge[]>([]);
  const [selectedSurcharges, setSelectedSurcharges] = useState<Set<string>>(new Set());
  // PayOS
  const [payosLoading, setPayosLoading] = useState(false);
  const [checkoutUrl, setCheckoutUrl] = useState<string | null>(null);
  // Payment countdown
  const [paymentDeadline, setPaymentDeadline] = useState<Date | null>(null);
  const [timeLeft, setTimeLeft] = useState<number>(0);
  const [orderCode, setOrderCode] = useState("");
  // Voucher
  const [voucherCode, setVoucherCode] = useState("");
  const [appliedVoucher, setAppliedVoucher] = useState<{ id: string; type: string; value: number; min_order_amount: number; code: string } | null>(null);
  const [voucherLoading, setVoucherLoading] = useState(false);
  const [voucherError, setVoucherError] = useState("");
  const [orderId, setOrderId] = useState("");
  // Shipping zone
  const [shippingZone, setShippingZone] = useState<ShippingZoneConfig | null>(null);
  const [deliveryMode, setDeliveryMode] = useState<"pickup" | "custom">("pickup");
  const [selectedPickup, setSelectedPickup] = useState<number>(0);
  // Fetch menu, surcharges and shipping zone from DB
  useEffect(() => {
    const fetchMenu = async () => {
      const { data, error } = await supabase
        .from("monthly_menu")
        .select("*")
        .eq("is_active", true)
        .order("display_order");
      if (!error && data) setMenuItems(data as MenuItem[]);
      setMenuLoading(false);
    };
    const fetchSurcharges = async () => {
      const { data } = await supabase
        .from("order_surcharges")
        .select("*")
        .eq("is_active", true);
      if (data) {
        setSurcharges(data as Surcharge[]);
        const defaults = new Set(data.filter((s: any) => s.is_default).map((s: any) => s.id));
        setSelectedSurcharges(defaults);
      }
    };
    const fetchShippingZone = async () => {
      const { data } = await supabase
        .from("app_settings")
        .select("value")
        .eq("key", "SHIPPING_ZONE_CONFIG")
        .maybeSingle();
      if (data?.value) {
        try {
          const config = JSON.parse(data.value) as ShippingZoneConfig;
          setShippingZone(config);
          if (config.pickup_points.length > 0) {
            setDeliveryMode("pickup");
            setSelectedPickup(0);
          }
        } catch { /* ignore */ }
      }
    };
    fetchMenu();
    fetchSurcharges();
    fetchShippingZone();
  }, []);

  // Pre-fill from profile
  useEffect(() => {
    if (profile) {
      setCustomer((prev) => ({
        ...prev,
        name: profile.full_name || "",
        phone: profile.phone || "",
      }));
    }
  }, [profile]);

  // Countdown timer for payment
  useEffect(() => {
    if (!paymentDeadline) return;
    const interval = setInterval(() => {
      const remaining = paymentDeadline.getTime() - Date.now();
      if (remaining <= 0) {
        setTimeLeft(0);
        clearInterval(interval);
        // Auto-cancel order
        handlePaymentTimeout();
      } else {
        setTimeLeft(remaining);
      }
    }, 1000);
    return () => clearInterval(interval);
  }, [paymentDeadline]);

  const handlePaymentTimeout = useCallback(async () => {
    if (!orderId) return;
    // Cancel the order
    await supabase
      .from("orders")
      .update({ status: "cancelled", payment_status: "expired" } as any)
      .eq("id", orderId);
    toast.error("Đơn hàng đã bị hủy do quá thời gian thanh toán (10 phút)");
    setStep("select");
    setCheckoutUrl(null);
    setPaymentDeadline(null);
  }, [orderId]);

  // Generate order code: NC-{userShortCode}-{orderSequence}
  const generateOrderCode = async () => {
    if (!user) return `NC${Date.now().toString(36).toUpperCase().slice(-6)}`;
    const shortCode = getUserShortCode(user.id);
    // Count existing orders for this user
    const { count } = await supabase
      .from("orders")
      .select("*", { count: "exact", head: true })
      .eq("user_id", user.id);
    const seq = (count || 0) + 1;
    return `NC-${shortCode}-${String(seq).padStart(3, "0")}`;
  };

  const updateQty = (id: string, delta: number) => {
    const item = menuItems.find((m) => m.id === id);
    setQuantities((prev) => {
      const current = prev[id] || 0;
      const max = item ? item.stock : 99;
      const next = Math.max(0, Math.min(max, current + delta));
      if (next === 0) {
        const { [id]: _, ...rest } = prev;
        return rest;
      }
      return { ...prev, [id]: next };
    });
  };

  const totalItems = useMemo(() => Object.values(quantities).reduce((a, b) => a + b, 0), [quantities]);

  const subtotal = useMemo(
    () => menuItems.reduce((sum, c) => sum + (quantities[c.id] || 0) * c.price, 0),
    [quantities, menuItems]
  );

  // Calculate surcharges dynamically
  const surchargeDetails = useMemo(() => {
    return surcharges
      .filter((s) => selectedSurcharges.has(s.id))
      .map((s) => ({
        ...s,
        computed: s.type === "fixed" ? s.value : Math.round(subtotal * s.value / 100),
      }));
  }, [surcharges, selectedSurcharges, subtotal]);

  // Check if custom address is within any pickup point's radius
  const isWithinPickupRadius = useMemo(() => {
    if (deliveryMode !== "custom" || !shippingZone || !geoOrder.coords) return false;
    return shippingZone.pickup_points.some((pp) => {
      const dist = haversineDistance(geoOrder.coords!.lat, geoOrder.coords!.lng, pp.lat, pp.lng);
      return dist <= pp.radius_km;
    });
  }, [deliveryMode, shippingZone, geoOrder.coords]);

  // Free ship if pickup point selected OR within radius OR subtotal >= threshold
  const isPickupFreeShip = deliveryMode === "pickup" && shippingZone && shippingZone.pickup_points.length > 0;
  const shippingSurcharge = surchargeDetails.find((s) => s.name.toLowerCase().includes("ship"));
  const shipping = shippingSurcharge
    ? (isPickupFreeShip || isWithinPickupRadius || subtotal >= FREE_SHIP_THRESHOLD ? 0 : shippingSurcharge.computed)
    : 0;

  const nonShippingSurcharges = surchargeDetails.filter((s) => !s.name.toLowerCase().includes("ship"));
  const surchargesTotal = nonShippingSurcharges.reduce((s, sc) => s + sc.computed, 0);
  const greenFund = nonShippingSurcharges.find((s) => s.name.toLowerCase().includes("quỹ") || s.name.toLowerCase().includes("xanh"))?.computed || 0;
  
  // Voucher discount
  const voucherDiscount = useMemo(() => {
    if (!appliedVoucher) return 0;
    if (appliedVoucher.type === "percent") {
      return Math.round((subtotal * appliedVoucher.value) / 100);
    }
    return appliedVoucher.value;
  }, [appliedVoucher, subtotal]);
  
  const total = Math.max(0, subtotal + shipping + surchargesTotal - voucherDiscount);

  const submitOrder = async () => {
    setIsSubmitting(true);
    try {
      const code = await generateOrderCode();
      setOrderCode(code);

      const deadline = paymentMethod === "transfer" ? new Date(Date.now() + PAYMENT_TIMEOUT_MS) : null;
      const newOrderId = crypto.randomUUID();
      setOrderId(newOrderId);

      const { error: orderError } = await supabase
        .from("orders")
        .insert({
          id: newOrderId,
          order_code: code,
          customer_name: customer.name.trim(),
          phone: customer.phone.trim(),
          address: customer.address.trim(),
          notes: customer.note?.trim() || null,
          payment_method: paymentMethod === "transfer" ? "bank_transfer" : "cash",
          subtotal,
          shipping_fee: shipping,
          total,
          green_fund_amount: greenFund,
          status: "pending",
          user_id: user?.id || null,
          payment_deadline: deadline?.toISOString() || null,
          payment_status: "pending",
        } as any);

      if (orderError) throw orderError;

      const items = menuItems
        .filter((c) => quantities[c.id])
        .map((c) => ({
          id: crypto.randomUUID(),
          order_id: newOrderId,
          cookie_name: c.cookie_name,
          quantity: quantities[c.id]!,
          unit_price: c.price,
          total_price: c.price * quantities[c.id]!,
        }));

      const { error: itemsError } = await supabase.from("order_items").insert(items);
      if (itemsError) throw itemsError;

      // Notify admin
      supabase.functions.invoke("notify-new-order", {
        body: {
          orderCode: code,
          customerName: customer.name.trim(),
          phone: customer.phone.trim(),
          address: customer.address.trim(),
          total,
          items,
          paymentMethod: paymentMethod === "transfer" ? "bank_transfer" : "cash",
        },
      }).catch(console.error);

      // Mark voucher as used
      if (appliedVoucher) {
        await supabase
          .from("user_vouchers")
          .update({ is_used: true, used_at: new Date().toISOString(), order_id: newOrderId } as any)
          .eq("id", appliedVoucher.id);
      }

      // If transfer, create PayOS link and go to paying step
      if (paymentMethod === "transfer") {
        setPaymentDeadline(deadline);
        await createPayOSLink(code, newOrderId);
        setStep("paying");
      } else {
        setStep("done");
        toast.success("Đặt hàng thành công! 🎉");
      }
    } catch (err: any) {
      console.error("Order error:", err);
      toast.error(err.message || "Có lỗi xảy ra, vui lòng thử lại!");
    } finally {
      setIsSubmitting(false);
    }
  };

  const createPayOSLink = async (code: string, dbOrderId: string) => {
    setPayosLoading(true);
    try {
      const returnUrl = `${window.location.origin}/order?code=${code}`;
      const cancelUrl = `${window.location.origin}/order?cancel=true&code=${code}`;

      const payItems = menuItems
        .filter((c) => quantities[c.id])
        .map((c) => ({
          name: c.cookie_name,
          quantity: quantities[c.id]!,
          price: c.price,
        }));

      const { data, error } = await supabase.functions.invoke("create-payment-link", {
        body: {
          orderCode: code,
          amount: total,
          description: `Nova Cookie ${code}`,
          items: payItems,
          returnUrl,
          cancelUrl,
        },
      });

      if (error) throw error;
      if (data?.checkoutUrl) {
        setCheckoutUrl(data.checkoutUrl);
      }
      // Save payos_order_code to DB
      if (data?.orderCodeNum) {
        await supabase
          .from("orders")
          .update({ payos_order_code: data.orderCodeNum } as any)
          .eq("id", dbOrderId);
      }
    } catch (err: any) {
      console.error("PayOS error:", err);
      toast.error("Lỗi tạo link thanh toán: " + (err.message || "Vui lòng thử lại"));
      throw err; // Re-throw to prevent changing step in submitOrder
    } finally {
      setPayosLoading(false);
    }
  };

  // Handle return from PayOS (returnUrl redirect)
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const code = params.get("code");
    if (code && !params.get("cancel")) {
      // Returned from PayOS - start polling for payment status
      setOrderCode(code);
      setStep("paying");

      // Fetch orderId and payment_deadline from DB
      supabase
        .from("orders")
        .select("id, payment_deadline")
        .eq("order_code", code)
        .single()
        .then(({ data }) => {
          if (data) {
            setOrderId(data.id);
            if (data.payment_deadline) {
              setPaymentDeadline(new Date(data.payment_deadline));
            } else {
              setPaymentDeadline(new Date(Date.now() + PAYMENT_TIMEOUT_MS));
            }
          }
        });
      window.history.replaceState({}, "", "/order");
    } else if (params.get("cancel") === "true") {
      toast.error("Thanh toán đã bị hủy");
      window.history.replaceState({}, "", "/order");
    }
  }, []);

  // Polling: check payment status every 3 seconds when in "paying" step
  useEffect(() => {
    if (step !== "paying" || !orderCode) return;

    const pollInterval = setInterval(async () => {
      const { data } = await supabase
        .from("orders")
        .select("payment_status")
        .eq("order_code", orderCode)
        .single();

      if (data?.payment_status === "paid") {
        clearInterval(pollInterval);
        setStep("done");
        setCheckoutUrl(null);
        setPaymentDeadline(null);
        toast.success("Thanh toán thành công! 🎉");
      } else if (data?.payment_status === "cancelled" || data?.payment_status === "expired") {
        clearInterval(pollInterval);
        setCheckoutUrl(null);
        setPaymentDeadline(null);
        setStep("select");
        toast.error("Thanh toán đã bị hủy hoặc hết hạn");
      }
    }, 3000);

    return () => clearInterval(pollInterval);
  }, [step, orderCode]);

  // Check if user already voted this month when reaching done step
  useEffect(() => {
    if (step !== "done" || !user) return;
    const checkExistingVote = async () => {
      const { data: existingVote } = await supabase
        .from("votes")
        .select("cookie_name")
        .eq("user_id", user.id)
        .eq("month_year", CURRENT_MONTH)
        .maybeSingle();
      if (existingVote) {
        setHasVoted(true);
        setExistingVoteCookie(existingVote.cookie_name);
      }
    };
    checkExistingVote();
  }, [step, user]);

  const submitVote = async () => {
    if (!votedCookie) return;
    setIsVoting(true);
    try {
      const cookieName = menuItems.find((c) => c.id === votedCookie)?.cookie_name;
      if (!cookieName) return;
      const { error } = await supabase.from("votes").insert({
        order_code: orderCode,
        cookie_name: cookieName,
        month_year: CURRENT_MONTH,
        user_id: user?.id || null,
      });
      if (error) throw error;
      setHasVoted(true);
      setExistingVoteCookie(cookieName);
      toast.success("Cảm ơn bạn đã bình chọn! 🎉");
    } catch (err) {
      console.error("Vote error:", err);
      toast.error("Không thể gửi vote, thử lại sau!");
    } finally {
      setIsVoting(false);
    }
  };

  const submitFeedback = async () => {
    if (feedbackRating === 0) {
      toast.error("Vui lòng chọn số sao!");
      return;
    }
    setIsSubmittingFeedback(true);
    try {
      const { error } = await supabase.from("feedback").insert({
        order_code: orderCode,
        customer_name: customer.name.trim(),
        rating: feedbackRating,
        comment: feedbackComment.trim() || null,
      });
      if (error) throw error;
      setHasFeedback(true);
      toast.success("Cảm ơn bạn đã đánh giá! 💛");
    } catch (err) {
      console.error("Feedback error:", err);
      toast.error("Không thể gửi đánh giá, thử lại sau!");
    } finally {
      setIsSubmittingFeedback(false);
    }
  };

  const applyVoucher = async () => {
    if (!voucherCode.trim() || !user) return;
    setVoucherLoading(true);
    setVoucherError("");
    const code = voucherCode.trim().toUpperCase();
    const now = new Date();
    try {
      // Step 1: Check personal reward vouchers (user_vouchers)
      const { data: voucher } = await supabase
        .from("user_vouchers")
        .select("*, voucher_templates(*)")
        .eq("code", code)
        .eq("user_id", user.id)
        .eq("is_used", false)
        .maybeSingle();

      if (voucher) {
        // Check expiry
        if (voucher.expires_at && new Date(voucher.expires_at) < now) {
          setVoucherError("Voucher đã hết hạn");
          return;
        }
        const template = voucher.voucher_templates as any;
        if (!template) { setVoucherError("Voucher không hợp lệ"); return; }
        if (subtotal < template.min_order_amount) {
          setVoucherError(`Đơn tối thiểu ${formatPrice(template.min_order_amount)}`);
          return;
        }
        setAppliedVoucher({
          id: voucher.id,
          type: template.type,
          value: template.value,
          min_order_amount: template.min_order_amount,
          code: voucher.code,
        });
        return;
      }

      // Step 2: Check promo vouchers (voucher_templates with promo_code)
      const { data: promoTemplate } = await supabase
        .from("voucher_templates")
        .select("*")
        .eq("promo_code", code)
        .eq("distribution_type", "promo")
        .eq("is_active", true)
        .maybeSingle();

      if (!promoTemplate) {
        setVoucherError("Mã voucher không hợp lệ hoặc đã sử dụng");
        return;
      }

      // Check date validity
      if (promoTemplate.valid_from && new Date(promoTemplate.valid_from) > now) {
        setVoucherError("Voucher chưa có hiệu lực");
        return;
      }
      if (promoTemplate.valid_until && new Date(promoTemplate.valid_until) < now) {
        setVoucherError("Voucher đã hết hạn");
        return;
      }

      // Check usage count
      const { count: usedCount } = await supabase
        .from("user_vouchers")
        .select("*", { count: "exact", head: true })
        .eq("voucher_template_id", promoTemplate.id)
        .eq("is_used", true);

      if ((usedCount || 0) >= promoTemplate.max_quantity) {
        setVoucherError("Voucher đã hết lượt sử dụng");
        return;
      }

      // Check if this user already used this promo
      const { count: userUsedCount } = await supabase
        .from("user_vouchers")
        .select("*", { count: "exact", head: true })
        .eq("voucher_template_id", promoTemplate.id)
        .eq("user_id", user.id);

      if ((userUsedCount || 0) > 0) {
        setVoucherError("Bạn đã sử dụng mã promo này rồi");
        return;
      }

      if (subtotal < promoTemplate.min_order_amount) {
        setVoucherError(`Đơn tối thiểu ${formatPrice(promoTemplate.min_order_amount)}`);
        return;
      }

      // Create a user_voucher record for tracking (will be marked used on order)
      const { data: newVoucher, error: insertErr } = await supabase
        .from("user_vouchers")
        .insert({
          user_id: user.id,
          voucher_template_id: promoTemplate.id,
          code: code,
          expires_at: promoTemplate.valid_until,
          is_used: false,
        })
        .select("id")
        .single();

      if (insertErr) {
        setVoucherError("Lỗi áp dụng voucher promo");
        return;
      }

      setAppliedVoucher({
        id: newVoucher.id,
        type: promoTemplate.type,
        value: promoTemplate.value,
        min_order_amount: promoTemplate.min_order_amount,
        code: code,
      });
    } catch (err) {
      setVoucherError("Lỗi kiểm tra voucher");
    } finally {
      setVoucherLoading(false);
    }
  };

  const removeVoucher = () => {
    setAppliedVoucher(null);
    setVoucherCode("");
    setVoucherError("");
  };

  const handleNext = () => {
    if (step === "select") {
      if (totalItems === 0) {
        toast.error("Vui lòng chọn ít nhất 1 cookie!");
        return;
      }
      if (!user) {
        toast("Vui lòng đăng nhập để đặt hàng", {
          action: {
            label: "Đăng nhập",
            onClick: () => navigate("/auth?redirect=/order"),
          },
        });
        return;
      }
      // if (needsCompletion) {
      //   setShowProfileModal(true);
      //   return;
      // }
      setStep("info");
    } else if (step === "info") {
      const result = customerSchema.safeParse(customer);
      if (!result.success) {
        const fieldErrors: Record<string, string> = {};
        result.error.errors.forEach((e) => {
          if (e.path[0]) fieldErrors[e.path[0] as string] = e.message;
        });
        setErrors(fieldErrors);
        return;
      }
      setErrors({});
      setStep("payment");
    } else if (step === "payment") {
      submitOrder();
    }
  };

  const formatCountdown = (ms: number) => {
    const mins = Math.floor(ms / 60000);
    const secs = Math.floor((ms % 60000) / 1000);
    return `${mins}:${String(secs).padStart(2, "0")}`;
  };

  if (menuLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <ProfileCompletionModal
        open={showProfileModal}
        onClose={() => {
          setShowProfileModal(false);
          refetchProfile();
        }}
      />
      <main className="relative pt-16">
        <CornerVine className="absolute left-0 top-16 h-32 w-32 md:h-44 md:w-44" position="top-left" />
        <CornerVine className="absolute right-0 top-16 h-32 w-32 md:h-44 md:w-44" position="top-right" />

        <div className="container mx-auto px-4 py-10 md:py-16">
          {/* Header */}
          <div className="mb-10 text-center">
            <span className="mb-2 inline-block rounded-full border border-secondary bg-secondary/10 px-4 py-1 text-sm font-semibold text-secondary-foreground">
              {CURRENT_MONTH}
            </span>
            <h1 className="font-display text-4xl font-extrabold text-foreground md:text-5xl">
              Đặt hàng
            </h1>
          </div>

          {/* Progress steps */}
          <div className="mx-auto mb-12 flex max-w-md items-center justify-center gap-2">
            {(["select", "info", "payment", "done"] as Step[]).map((s, i) => {
              const labels = ["Chọn vị", "Thông tin", "Thanh toán", "Hoàn tất"];
              const currentStepOrder = ["select", "info", "payment", "paying", "done"];
              const stepIndex = currentStepOrder.indexOf(step);
              const displayIndex = s === "done" ? 3 : i;
              const isActive = stepIndex >= i || (step === "paying" && i <= 2);
              return (
                <div key={s} className="flex items-center gap-2">
                  <div
                    className={`flex h-8 w-8 items-center justify-center rounded-full text-xs font-bold transition-colors ${
                      isActive ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
                    }`}
                  >
                    {stepIndex > i || (step === "done" && i < 4) ? <Check className="h-4 w-4" /> : i + 1}
                  </div>
                  <span className={`hidden text-xs font-medium sm:inline ${isActive ? "text-foreground" : "text-muted-foreground"}`}>
                    {labels[i]}
                  </span>
                  {i < 3 && <div className={`h-px w-6 ${isActive ? "bg-primary" : "bg-border"}`} />}
                </div>
              );
            })}
          </div>

          <AnimatePresence mode="wait">
            {/* STEP 1: Select flavors */}
            {step === "select" && (
              <motion.div
                key="select"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="mx-auto max-w-3xl"
              >
                {menuItems.length === 0 ? (
                  <div className="rounded-2xl border border-border bg-card p-10 text-center">
                    <p className="text-muted-foreground">Chưa có menu cho tháng này</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {menuItems.map((cookie) => {
                      const qty = quantities[cookie.id] || 0;
                      const outOfStock = cookie.stock <= 0;
                      return (
                        <div
                          key={cookie.id}
                          className={`flex items-center gap-4 rounded-2xl border p-4 transition-colors ${
                            outOfStock ? "border-border bg-muted/50 opacity-60" :
                            qty > 0 ? "border-primary/30 bg-primary/5" : "border-border bg-card"
                          }`}
                        >
                          {cookie.image_url ? (
                            <img
                              src={cookie.image_url}
                              alt={cookie.cookie_name}
                              className="h-20 w-20 flex-shrink-0 rounded-xl object-cover"
                            />
                          ) : (
                            <div className="flex h-20 w-20 flex-shrink-0 items-center justify-center rounded-xl bg-muted text-2xl">
                              🍪
                            </div>
                          )}
                          <div className="flex-1 min-w-0">
                            <h3 className="font-display text-base font-bold text-foreground md:text-lg">
                              {cookie.cookie_name}
                            </h3>
                            <p className="text-xs text-muted-foreground">{cookie.origin}</p>
                            <div className="mt-1 flex items-center gap-3">
                              <span className="font-bold text-primary">{formatPrice(cookie.price)}</span>
                              <span className={`text-xs font-medium ${cookie.stock <= 5 ? "text-destructive" : "text-muted-foreground"}`}>
                                {outOfStock ? "Hết hàng" : `Còn ${cookie.stock}`}
                              </span>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <button
                              onClick={() => updateQty(cookie.id, -1)}
                              disabled={qty === 0 || outOfStock}
                              className="flex h-9 w-9 items-center justify-center rounded-full border border-border text-foreground transition-colors hover:bg-muted disabled:opacity-30"
                            >
                              <Minus className="h-4 w-4" />
                            </button>
                            <span className="w-8 text-center font-bold text-foreground">{qty}</span>
                            <button
                              onClick={() => updateQty(cookie.id, 1)}
                              disabled={outOfStock || qty >= cookie.stock}
                              className="flex h-9 w-9 items-center justify-center rounded-full bg-primary text-primary-foreground transition-transform hover:scale-110 disabled:opacity-30"
                            >
                              <Plus className="h-4 w-4" />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}

                {/* Order summary */}
                {totalItems > 0 && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="mt-8 rounded-2xl border border-border bg-card p-6"
                  >
                    <h3 className="mb-3 font-display text-lg font-bold text-foreground">Tóm tắt đơn hàng</h3>
                    <div className="space-y-2 text-sm">
                      {menuItems.filter((c) => quantities[c.id]).map((c) => (
                        <div key={c.id} className="flex justify-between">
                          <span className="text-muted-foreground">
                            {c.cookie_name} × {quantities[c.id]}
                          </span>
                          <span className="font-medium text-foreground">
                            {formatPrice(c.price * quantities[c.id]!)}
                          </span>
                        </div>
                      ))}
                      <MotifDivider className="my-3" />
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Tạm tính</span>
                        <span className="font-medium text-foreground">{formatPrice(subtotal)}</span>
                      </div>
                      {shippingSurcharge && (
                        <>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Phí ship</span>
                            <span className="font-medium text-foreground">
                              {shipping === 0 ? (
                                <span className="text-primary">Miễn phí 🎉</span>
                              ) : (
                                formatPrice(shipping)
                              )}
                            </span>
                          </div>
                          {shipping > 0 && (
                            <p className="text-xs text-muted-foreground">
                              Miễn phí ship cho đơn từ {formatPrice(FREE_SHIP_THRESHOLD)} hoặc trong vùng giao hàng
                            </p>
                          )}
                          {shipping === 0 && isWithinPickupRadius && deliveryMode === "custom" && (
                            <p className="text-xs text-primary">
                              📍 Địa chỉ nằm trong vùng free ship!
                            </p>
                          )}
                        </>
                      )}
                      {nonShippingSurcharges.map((sc) => (
                        <div key={sc.id} className="flex justify-between text-xs text-primary">
                          <span>{sc.name} ({sc.type === "percent" ? `${sc.value}%` : "cố định"})</span>
                          <span>{formatPrice(sc.computed)}</span>
                        </div>
                      ))}
                      <div className="flex justify-between pt-2 text-base font-bold">
                        <span className="text-foreground">Tổng cộng</span>
                        <span className="text-primary">{formatPrice(total)}</span>
                      </div>
                    </div>
                  </motion.div>
                )}
              </motion.div>
            )}

            {/* STEP 2: Customer info */}
            {step === "info" && (
              <motion.div
                key="info"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="mx-auto max-w-lg"
              >
                <div className="space-y-5 rounded-2xl border border-border bg-card p-6 md:p-8">
                  {/* Name & Phone fields */}
                  {[
                    { key: "name", label: "Họ tên", placeholder: "Nguyễn Văn A", type: "text" },
                    { key: "phone", label: "Số điện thoại", placeholder: "0912345678", type: "tel" },
                  ].map((field) => (
                    <div key={field.key}>
                      <label className="mb-1.5 block text-sm font-semibold text-foreground">
                        {field.label} <span className="text-destructive">*</span>
                      </label>
                      <input
                        type={field.type}
                        placeholder={field.placeholder}
                        value={customer[field.key as keyof typeof customer]}
                        onChange={(e) => {
                          setCustomer((prev) => ({ ...prev, [field.key]: e.target.value }));
                          if (errors[field.key]) setErrors((prev) => ({ ...prev, [field.key]: "" }));
                        }}
                        className={`w-full rounded-xl border px-4 py-3 text-sm text-foreground outline-none transition-colors placeholder:text-muted-foreground focus:border-primary focus:ring-2 focus:ring-primary/20 ${
                          errors[field.key] ? "border-destructive" : "border-border"
                        } bg-background`}
                      />
                      {errors[field.key] && (
                        <p className="mt-1 text-xs text-destructive">{errors[field.key]}</p>
                      )}
                    </div>
                  ))}

                  {/* Delivery mode: pickup vs custom */}
                  {shippingZone && shippingZone.pickup_points.length > 0 && (
                    <div>
                      <label className="mb-2 block text-sm font-semibold text-foreground">
                        Hình thức nhận hàng <span className="text-destructive">*</span>
                      </label>
                      <div className="flex gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            setDeliveryMode("pickup");
                            const pp = shippingZone.pickup_points[selectedPickup];
                            if (pp) setCustomer((prev) => ({ ...prev, address: `${pp.name} - ${pp.address}` }));
                          }}
                          className={`flex-1 rounded-xl border-2 px-4 py-2.5 text-sm font-semibold transition-all ${deliveryMode === "pickup" ? "border-primary bg-primary/5 text-primary" : "border-border text-muted-foreground"}`}
                        >
                          <MapPin className="mr-1.5 inline h-4 w-4" />
                          Điểm nhận hàng
                          <span className="ml-1 text-xs font-normal">(Free ship)</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setDeliveryMode("custom");
                            setCustomer((prev) => ({ ...prev, address: "" }));
                          }}
                          className={`flex-1 rounded-xl border-2 px-4 py-2.5 text-sm font-semibold transition-all ${deliveryMode === "custom" ? "border-primary bg-primary/5 text-primary" : "border-border text-muted-foreground"}`}
                        >
                          <Truck className="mr-1.5 inline h-4 w-4" />
                          Giao tận nơi
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Pickup point selector */}
                  {deliveryMode === "pickup" && shippingZone && shippingZone.pickup_points.length > 0 ? (
                    <div>
                      <label className="mb-1.5 block text-sm font-semibold text-foreground">
                        Chọn điểm nhận hàng <span className="text-destructive">*</span>
                      </label>
                      <div className="space-y-2">
                        {shippingZone.pickup_points.map((pp, idx) => (
                          <button
                            key={idx}
                            type="button"
                            onClick={() => {
                              setSelectedPickup(idx);
                              setCustomer((prev) => ({ ...prev, address: `${pp.name} - ${pp.address}` }));
                              if (errors.address) setErrors((prev) => ({ ...prev, address: "" }));
                            }}
                            className={`w-full rounded-xl border-2 p-3 text-left text-sm transition-all ${
                              selectedPickup === idx ? "border-primary bg-primary/5" : "border-border hover:border-muted-foreground/30"
                            }`}
                          >
                            <span className="font-bold text-foreground">{pp.name}</span>
                            <br />
                            <span className="text-xs text-muted-foreground">{pp.address}</span>
                            {selectedPickup === idx && (
                              <span className="ml-2 inline-block rounded-full bg-primary px-2 py-0.5 text-xs font-bold text-primary-foreground">
                                ✓ Free ship
                              </span>
                            )}
                          </button>
                        ))}
                      </div>
                      {errors.address && (
                        <p className="mt-1 text-xs text-destructive">{errors.address}</p>
                      )}
                    </div>
                  ) : (
                    /* Custom address input */
                    <div>
                      <label className="mb-1.5 block text-sm font-semibold text-foreground">
                        Địa chỉ giao hàng <span className="text-destructive">*</span>
                      </label>
                      <div className="relative">
                        <input
                          type="text"
                          placeholder="Số nhà, đường, phường/xã, quận/huyện, tỉnh/TP"
                          value={customer.address}
                          onChange={(e) => {
                            setCustomer((prev) => ({ ...prev, address: e.target.value }));
                            if (errors.address) setErrors((prev) => ({ ...prev, address: "" }));
                          }}
                          className={`w-full rounded-xl border px-4 py-3 pr-40 text-sm text-foreground outline-none transition-colors placeholder:text-muted-foreground focus:border-primary focus:ring-2 focus:ring-primary/20 ${
                            errors.address ? "border-destructive" : "border-border"
                          } bg-background`}
                        />
                        <div className="absolute right-1.5 top-1/2 -translate-y-1/2 flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => geoOrder.geocodeAddress(customer.address)}
                            disabled={geoOrder.searchLoading}
                            className="flex items-center gap-1 rounded-lg bg-accent/80 px-2.5 py-1.5 text-xs font-semibold text-accent-foreground transition-colors hover:bg-accent disabled:opacity-50"
                          >
                            {geoOrder.searchLoading ? (
                              <Loader2 className="h-3.5 w-3.5 animate-spin" />
                            ) : (
                              <Search className="h-3.5 w-3.5" />
                            )}
                            Tìm
                          </button>
                          <button
                            type="button"
                            onClick={() => geoOrder.getLocation()}
                            disabled={geoOrder.loading}
                            className="flex items-center gap-1 rounded-lg bg-primary/10 px-2.5 py-1.5 text-xs font-semibold text-primary transition-colors hover:bg-primary/20 disabled:opacity-50"
                          >
                            {geoOrder.loading ? (
                              <Loader2 className="h-3.5 w-3.5 animate-spin" />
                            ) : (
                              <Navigation className="h-3.5 w-3.5" />
                            )}
                            GPS
                          </button>
                        </div>
                      </div>
                      {errors.address && (
                        <p className="mt-1 text-xs text-destructive">{errors.address}</p>
                      )}
                    </div>
                  )}
                  {geoOrder.coords && (
                    <AddressMap
                      coords={geoOrder.coords}
                      onMapClick={(newCoords) => geoOrder.reverseGeocode(newCoords)}
                    />
                  )}
                  <div>
                    <label className="mb-1.5 block text-sm font-semibold text-foreground">Ghi chú</label>
                    <textarea
                      placeholder="Ghi chú cho shop (không bắt buộc)"
                      value={customer.note}
                      onChange={(e) => setCustomer((prev) => ({ ...prev, note: e.target.value }))}
                      rows={3}
                      className="w-full rounded-xl border border-border bg-background px-4 py-3 text-sm text-foreground outline-none transition-colors placeholder:text-muted-foreground focus:border-primary focus:ring-2 focus:ring-primary/20"
                    />
                  </div>
                </div>
              </motion.div>
            )}

            {/* STEP 3: Payment method */}
            {step === "payment" && (
              <motion.div
                key="payment"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="mx-auto max-w-lg"
              >
                <div className="space-y-5">
                  <div className="grid grid-cols-2 gap-3">
                    {[
                      { method: "transfer" as const, icon: QrCode, label: "Chuyển khoản", desc: "PayOS / QR Code" },
                      { method: "cash" as const, icon: Banknote, label: "Tiền mặt", desc: "Thanh toán khi nhận" },
                    ].map(({ method, icon: Icon, label, desc }) => (
                      <button
                        key={method}
                        onClick={() => setPaymentMethod(method)}
                        className={`flex flex-col items-center gap-2 rounded-2xl border-2 p-5 text-center transition-all ${
                          paymentMethod === method
                            ? "border-primary bg-primary/5"
                            : "border-border bg-card hover:border-muted-foreground/30"
                        }`}
                      >
                        <Icon className={`h-8 w-8 ${paymentMethod === method ? "text-primary" : "text-muted-foreground"}`} />
                        <span className="font-display text-base font-bold text-foreground">{label}</span>
                        <span className="text-xs text-muted-foreground">{desc}</span>
                      </button>
                    ))}
                  </div>

                  {/* Order details */}
                  <div className="rounded-2xl border border-border bg-card p-6">
                    <h3 className="mb-3 font-display text-base font-bold text-foreground">Chi tiết đơn hàng</h3>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Khách hàng</span>
                        <span className="text-foreground">{customer.name}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">SĐT</span>
                        <span className="text-foreground">{customer.phone}</span>
                      </div>
                      <MotifDivider className="my-3" />
                      {menuItems.filter((c) => quantities[c.id]).map((c) => (
                        <div key={c.id} className="flex justify-between">
                          <span className="text-muted-foreground">{c.cookie_name} × {quantities[c.id]}</span>
                          <span className="text-foreground">{formatPrice(c.price * quantities[c.id]!)}</span>
                        </div>
                      ))}
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Phí ship</span>
                        <span className="text-foreground">{shipping === 0 ? "Miễn phí" : formatPrice(shipping)}</span>
                      </div>
                      {nonShippingSurcharges.map((sc) => (
                        <div key={sc.id} className="flex justify-between text-xs text-primary">
                          <span>{sc.name} ({sc.type === "percent" ? `${sc.value}%` : ""})</span>
                          <span>{formatPrice(sc.computed)}</span>
                        </div>
                      ))}
                      {appliedVoucher && (
                        <div className="flex justify-between text-xs text-primary font-semibold">
                          <span>🎫 Voucher ({appliedVoucher.code})</span>
                          <span>-{formatPrice(voucherDiscount)}</span>
                        </div>
                      )}
                      <div className="flex justify-between pt-2 text-lg font-bold">
                        <span className="text-foreground">Tổng</span>
                        <span className="text-primary">{formatPrice(total)}</span>
                      </div>
                    </div>
                  </div>

                  {/* Voucher input */}
                  {user && (
                    <div className="rounded-2xl border border-border bg-card p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <Ticket className="h-4 w-4 text-primary" />
                        <span className="text-sm font-bold text-foreground">Mã giảm giá</span>
                      </div>
                      {appliedVoucher ? (
                        <div className="flex items-center justify-between rounded-xl bg-primary/10 px-4 py-3">
                          <span className="text-sm font-semibold text-primary">
                            {appliedVoucher.code} · -{appliedVoucher.type === "percent" ? `${appliedVoucher.value}%` : formatPrice(appliedVoucher.value)}
                          </span>
                          <button onClick={removeVoucher} className="text-muted-foreground hover:text-destructive">
                            <X className="h-4 w-4" />
                          </button>
                        </div>
                      ) : (
                        <div className="flex gap-2">
                          <input
                            value={voucherCode}
                            onChange={(e) => { setVoucherCode(e.target.value.toUpperCase()); setVoucherError(""); }}
                            placeholder="Nhập mã voucher"
                            className="flex-1 rounded-xl border border-border bg-background px-3 py-2 text-sm font-mono outline-none focus:border-primary"
                          />
                          <button
                            onClick={applyVoucher}
                            disabled={!voucherCode.trim() || voucherLoading}
                            className="rounded-xl bg-primary px-4 py-2 text-sm font-bold text-primary-foreground disabled:opacity-50"
                          >
                            {voucherLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : "Áp dụng"}
                          </button>
                        </div>
                      )}
                      {voucherError && <p className="mt-2 text-xs text-destructive">{voucherError}</p>}
                    </div>
                  )}

                  {paymentMethod === "transfer" && (
                    <div className="rounded-2xl border border-primary/20 bg-primary/5 p-4 text-center text-sm text-muted-foreground">
                      <Timer className="inline h-4 w-4 mr-1" />
                      Sau khi xác nhận, bạn có <span className="font-bold text-foreground">10 phút</span> để hoàn tất thanh toán. Đơn sẽ tự động hủy nếu chưa thanh toán.
                    </div>
                  )}

                  {paymentMethod === "cash" && (
                    <div className="rounded-2xl border border-secondary/20 bg-secondary/5 p-6 text-center">
                      <Banknote className="mx-auto mb-3 h-10 w-10 text-secondary" />
                      <p className="font-semibold text-foreground">Thanh toán khi nhận hàng</p>
                      <p className="mt-1 text-sm text-muted-foreground">
                        Bạn sẽ trả {formatPrice(total)} khi shipper giao đến.
                      </p>
                    </div>
                  )}
                </div>
              </motion.div>
            )}

            {/* STEP 3.5: Paying - inline payment */}
            {step === "paying" && (
              <motion.div
                key="paying"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="mx-auto max-w-lg"
              >
                <div className="space-y-4">
                  {/* Countdown */}
                  <div className={`flex items-center justify-center gap-3 rounded-2xl border p-4 ${
                    timeLeft < 60000 ? "border-destructive/50 bg-destructive/5" : "border-primary/20 bg-primary/5"
                  }`}>
                    <Timer className={`h-6 w-6 ${timeLeft < 60000 ? "text-destructive" : "text-primary"}`} />
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground">Thời gian còn lại</p>
                      <p className={`font-mono text-3xl font-extrabold ${timeLeft < 60000 ? "text-destructive" : "text-primary"}`}>
                        {formatCountdown(timeLeft)}
                      </p>
                    </div>
                  </div>

                  <div className="rounded-2xl border border-border bg-card p-4 text-center">
                    <p className="text-sm text-muted-foreground mb-1">Mã đơn hàng</p>
                    <p className="font-mono text-lg font-bold text-foreground">{orderCode}</p>
                    <p className="mt-2 text-sm font-bold text-primary">{formatPrice(total)}</p>
                  </div>

                  {/* PayOS iframe */}
                  {checkoutUrl ? (
                    <div className="overflow-hidden rounded-2xl border border-border pointer-events-auto select-none" style={{ touchAction: "pan-y" }}>
                      <iframe
                        src={checkoutUrl}
                        title="Thanh toán PayOS"
                        className="h-[500px] w-full border-0 pointer-events-auto"
                        allow="payment"
                        style={{ touchAction: "auto", userSelect: "none" }}
                        scrolling="no"
                      />
                    </div>
                  ) : payosLoading ? (
                    <div className="flex flex-col items-center gap-3 rounded-2xl border border-border bg-card p-10">
                      <Loader2 className="h-8 w-8 animate-spin text-primary" />
                      <p className="text-sm text-muted-foreground">Đang tạo link thanh toán...</p>
                    </div>
                  ) : (
                    <div className="rounded-2xl border border-border bg-card p-6 text-center">
                      <p className="text-sm text-muted-foreground mb-3">Không thể tạo link PayOS. Vui lòng chuyển khoản thủ công:</p>
                      <img
                        src={`https://img.vietqr.io/image/970422-0123456789-compact2.png?amount=${total}&addInfo=${encodeURIComponent(`Nova Cookie ${orderCode}`)}&accountName=${encodeURIComponent("NOVA COOKIE")}`}
                        alt="QR thanh toán"
                        className="mx-auto h-56 w-56 rounded-xl border border-border bg-white object-contain p-2"
                      />
                      <p className="mt-3 text-xs text-muted-foreground">
                        Nội dung CK: <span className="font-mono font-bold text-foreground">Nova Cookie {orderCode}</span>
                      </p>
                    </div>
                  )}

                  <div className="flex flex-col items-center gap-2 rounded-2xl border border-primary/20 bg-primary/5 p-4">
                    <Loader2 className="h-5 w-5 animate-spin text-primary" />
                    <p className="text-sm font-semibold text-foreground">Đang chờ xác nhận thanh toán...</p>
                    <p className="text-xs text-muted-foreground">Thanh toán sẽ được xác nhận tự động sau khi chuyển khoản thành công</p>
                  </div>
                </div>
              </motion.div>
            )}

            {/* STEP 4: Done */}
            {step === "done" && (
              <motion.div
                key="done"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="mx-auto max-w-md text-center"
              >
                <div className="rounded-2xl border border-primary/20 bg-primary/5 p-10">
                  <div className="mx-auto mb-4 flex h-20 w-20 items-center justify-center rounded-full bg-primary text-primary-foreground">
                    <Check className="h-10 w-10" />
                  </div>
                  <h2 className="mb-2 font-display text-2xl font-extrabold text-foreground">
                    Đặt hàng thành công! 🎉
                  </h2>
                  <p className="mb-1 text-sm text-muted-foreground">
                    Mã đơn: <span className="font-mono font-bold text-foreground">{orderCode}</span>
                  </p>
                  <p className="mb-6 text-sm text-muted-foreground">
                    Nova Cookie sẽ liên hệ bạn qua SĐT <span className="font-semibold text-foreground">{customer.phone}</span> để xác nhận đơn.
                  </p>

                  {/* Vote section */}
                  <div className="mt-8 rounded-2xl border border-border bg-card p-6 text-left">
                    <div className="mb-4 flex items-center gap-2">
                      <Heart className="h-5 w-5 text-primary" />
                      <h3 className="font-display text-lg font-bold text-foreground">
                        Bình chọn vị yêu thích
                      </h3>
                    </div>
                    <p className="mb-4 text-sm text-muted-foreground">
                      Chọn vị cookie bạn thích nhất tháng này!
                    </p>
                    {hasVoted ? (
                      <motion.div
                        initial={{ opacity: 0, y: 5 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="flex items-center gap-2 rounded-xl bg-primary/10 p-4 text-sm font-semibold text-primary"
                      >
                        <Star className="h-5 w-5 fill-primary" />
                        Đã bình chọn cho {existingVoteCookie || menuItems.find((c) => c.id === votedCookie)?.cookie_name} tháng này! Cảm ơn bạn ❤️
                      </motion.div>
                    ) : (
                      <div className="space-y-2">
                        {menuItems.map((cookie) => (
                          <button
                            key={cookie.id}
                            onClick={() => setVotedCookie(cookie.id)}
                            className={`flex w-full items-center gap-3 rounded-xl border p-3 text-left transition-all ${
                              votedCookie === cookie.id
                                ? "border-primary bg-primary/5 ring-1 ring-primary/30"
                                : "border-border bg-background hover:border-muted-foreground/30"
                            }`}
                          >
                            {cookie.image_url ? (
                              <img src={cookie.image_url} alt={cookie.cookie_name} className="h-10 w-10 rounded-lg object-cover" />
                            ) : (
                              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-muted text-lg">🍪</div>
                            )}
                            <div className="flex-1">
                              <span className="text-sm font-semibold text-foreground">{cookie.cookie_name}</span>
                              <span className="ml-2 text-xs text-muted-foreground">{cookie.origin}</span>
                            </div>
                            <div className={`flex h-5 w-5 items-center justify-center rounded-full border-2 transition-colors ${
                              votedCookie === cookie.id ? "border-primary bg-primary" : "border-muted-foreground/30"
                            }`}>
                              {votedCookie === cookie.id && <Check className="h-3 w-3 text-primary-foreground" />}
                            </div>
                          </button>
                        ))}
                        <button
                          onClick={submitVote}
                          disabled={!votedCookie || isVoting}
                          className="mt-3 w-full rounded-full bg-primary px-6 py-3 text-sm font-bold text-primary-foreground transition-transform hover:scale-[1.02] disabled:opacity-50"
                        >
                          {isVoting ? (
                            <span className="flex items-center justify-center gap-2">
                              <Loader2 className="h-4 w-4 animate-spin" />
                              Đang gửi...
                            </span>
                          ) : (
                            "Gửi bình chọn 🗳️"
                          )}
                        </button>
                      </div>
                    )}
                  </div>

                  {/* Feedback section */}
                  <div className="mt-6 rounded-2xl border border-border bg-card p-6 text-left">
                    <div className="mb-4 flex items-center gap-2">
                      <MessageSquare className="h-5 w-5 text-primary" />
                      <h3 className="font-display text-lg font-bold text-foreground">
                        Đánh giá trải nghiệm
                      </h3>
                    </div>
                    {hasFeedback ? (
                      <motion.div
                        initial={{ opacity: 0, y: 5 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="flex items-center gap-2 rounded-xl bg-primary/10 p-4 text-sm font-semibold text-primary"
                      >
                        <Star className="h-5 w-5 fill-primary" />
                        Đã đánh giá {feedbackRating} sao! Cảm ơn bạn 💛
                      </motion.div>
                    ) : (
                      <div className="space-y-4">
                        <div>
                          <p className="mb-2 text-sm text-muted-foreground">Bạn hài lòng bao nhiêu?</p>
                          <div className="flex gap-1">
                            {[1, 2, 3, 4, 5].map((star) => (
                              <button
                                key={star}
                                onClick={() => setFeedbackRating(star)}
                                onMouseEnter={() => setFeedbackHover(star)}
                                onMouseLeave={() => setFeedbackHover(0)}
                                className="p-1 transition-transform hover:scale-110"
                              >
                                <Star
                                  className={`h-8 w-8 transition-colors ${
                                    star <= (feedbackHover || feedbackRating)
                                      ? "fill-primary text-primary"
                                      : "text-muted-foreground/30"
                                  }`}
                                />
                              </button>
                            ))}
                          </div>
                        </div>
                        <textarea
                          placeholder="Chia sẻ cảm nhận của bạn (không bắt buộc)"
                          value={feedbackComment}
                          onChange={(e) => setFeedbackComment(e.target.value.slice(0, 500))}
                          rows={3}
                          className="w-full rounded-xl border border-border bg-background px-4 py-3 text-sm text-foreground outline-none transition-colors placeholder:text-muted-foreground focus:border-primary focus:ring-2 focus:ring-primary/20"
                        />
                        <button
                          onClick={submitFeedback}
                          disabled={feedbackRating === 0 || isSubmittingFeedback}
                          className="w-full rounded-full bg-primary px-6 py-3 text-sm font-bold text-primary-foreground transition-transform hover:scale-[1.02] disabled:opacity-50"
                        >
                          {isSubmittingFeedback ? (
                            <span className="flex items-center justify-center gap-2">
                              <Loader2 className="h-4 w-4 animate-spin" />
                              Đang gửi...
                            </span>
                          ) : (
                            "Gửi đánh giá ⭐"
                          )}
                        </button>
                      </div>
                    )}
                  </div>

                  <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:justify-center">
                    <Link
                      to="/"
                      className="rounded-full bg-primary px-8 py-3 text-sm font-bold text-primary-foreground transition-transform hover:scale-105"
                    >
                      Về trang chủ
                    </Link>
                    {user && (
                      <Link
                        to="/orders"
                        className="rounded-full border border-primary px-8 py-3 text-sm font-bold text-primary transition-colors hover:bg-primary/5"
                      >
                        Xem đơn hàng
                      </Link>
                    )}
                    <Link
                      to="/ranking"
                      className="rounded-full border border-border px-8 py-3 text-sm font-bold text-foreground transition-colors hover:bg-muted"
                    >
                      Xem bảng xếp hạng
                    </Link>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Navigation buttons */}
          {step !== "done" && step !== "paying" && (
            <div className="mx-auto mt-8 flex max-w-3xl items-center justify-between">
              {step !== "select" ? (
                <button
                  onClick={() => setStep(step === "payment" ? "info" : "select")}
                  className="flex items-center gap-2 rounded-full border border-border px-6 py-3 text-sm font-semibold text-foreground transition-colors hover:bg-muted"
                >
                  <ArrowLeft className="h-4 w-4" />
                  Quay lại
                </button>
              ) : (
                <div />
              )}
              <button
                onClick={handleNext}
                disabled={isSubmitting}
                className="flex items-center gap-2 rounded-full bg-foreground px-8 py-3 text-sm font-bold text-background transition-transform hover:scale-105 disabled:opacity-50"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Đang xử lý...
                  </>
                ) : (
                  <>
                    {step === "select" && (
                      <>
                        {!user ? <LogIn className="h-4 w-4" /> : <ShoppingBag className="h-4 w-4" />}
                        {totalItems > 0 ? `Tiếp tục (${totalItems} cookie)` : "Chọn cookie"}
                      </>
                    )}
                    {step === "info" && (
                      <>
                        <CreditCard className="h-4 w-4" />
                        Chọn thanh toán
                      </>
                    )}
                    {step === "payment" && (
                      <>
                        <Check className="h-4 w-4" />
                        Xác nhận đặt hàng
                      </>
                    )}
                  </>
                )}
              </button>
            </div>
          )}
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Order;
