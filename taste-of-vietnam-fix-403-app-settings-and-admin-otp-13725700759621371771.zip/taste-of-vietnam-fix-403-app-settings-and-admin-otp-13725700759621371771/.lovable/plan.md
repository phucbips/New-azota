
# Ke hoach: Countdown Timer, Dang ky OTP, va Admin Settings nang cao

Yeu cau nay bao gom 3 nhom tinh nang chinh. Do pham vi rat lon (dac biet phan Admin Settings ca nhan hoa), de xuat chia thanh **3 giai doan** de trien khai tung buoc, dam bao chat luong.

---

## Giai doan 1: Countdown Timer + Dang ky bang OTP (Lam ngay)

### 1.1 Countdown Timer cho nut "Gui lai ma"

Them bo dem nguoc 60 giay cho tat ca cac nut "Gui lai ma" trong:
- Trang Auth.tsx (quen mat khau)
- Trang AdminDashboard.tsx (xac thuc admin)

```text
Logic:
- Khi gui ma thanh cong -> bat dau dem nguoc 60s
- Hien thi "Gui lai ma (45s)" va disable nut
- Het 60s -> enable lai nut "Gui lai ma"
- State: resendCountdown (number), dung useEffect + setInterval
```

### 1.2 Dang ky tai khoan moi bang OTP (thay vi link email)

Thay doi luong dang ky:
1. Nguoi dung nhap Ho ten, Email, Mat khau -> bam "Dang ky"
2. Goi edge function `send-verification-code` voi type moi `"signup_verify"`
3. Hien thi man hinh nhap OTP 6 chu so
4. Xac thuc OTP thanh cong -> tao tai khoan Supabase (auto-confirm) + dang nhap

```text
Luong moi:
[Nhap thong tin] -> [Gui OTP ve email] -> [Nhap OTP] -> [Tao account + Login]
```

**Thay doi can thiet:**

| File | Thay doi |
|------|----------|
| `src/pages/Auth.tsx` | Them state `signupOtp`, countdown timer, man hinh OTP cho dang ky |
| `supabase/functions/send-verification-code/index.ts` | Them type `signup_verify`, them email template tieng Viet cho dang ky |

---

## Giai doan 2: Admin Settings - Ca nhan hoa trang web (Lam sau giai doan 1)

Tao mot tab "Giao dien" moi trong Admin Dashboard de cho phep admin tuy chinh toan bo trang web. Tat ca cau hinh luu vao bang `app_settings` voi cac key rieng.

### 2.1 Quan ly Hero Banner

- Cho phep thay doi hero thanh **anh** hoac **video** (URL)
- Thay doi tieu de, mo ta, nut CTA
- Xem truoc truc tiep (preview)

```text
Key: HERO_CONFIG
Value (JSON): {
  "type": "image" | "video",
  "media_url": "...",
  "title": "Nova Cookie",
  "subtitle": "34 vi · 1 trai tim xanh",
  "cta_text": "Dat hang ngay",
  "cta_link": "/order"
}
```

### 2.2 An/Hien thanh phan trang chu

Toggle bat/tat cac section:
- Hero Section
- Menu Section
- Testimonial Carousel
- About Section
- Green Fund Section

```text
Key: HOMEPAGE_SECTIONS
Value (JSON): {
  "hero": true,
  "menu": true,
  "testimonials": true,
  "about": true,
  "green_fund": true
}
```

### 2.3 Sap xep thu tu bo cuc

Keo tha hoac nhap so thu tu de thay doi vi tri cac section tren trang chu.

```text
Key: SECTION_ORDER
Value (JSON): ["hero", "menu", "testimonials", "about", "green_fund"]
```

### 2.4 Chinh sua Email Templates

Cho phep admin tuy chinh noi dung cac email gui ra:
- Email xac thuc dang ky (signup_verify)
- Email quen mat khau (password_reset)
- Email xac thuc admin (admin_login)
- Email thong bao don hang moi

Moi template co the chinh sua:
- Tieu de email (subject)
- Noi dung chinh (title, description)
- Mau sac header
- Logo text

```text
Key: EMAIL_TEMPLATES
Value (JSON): {
  "signup_verify": {
    "subject": "...",
    "title": "...",
    "description": "...",
    "header_color": "#2d5a27"
  },
  "password_reset": { ... },
  "admin_login": { ... }
}
```

**Thay doi can thiet:**

| File | Thay doi |
|------|----------|
| `src/pages/AdminDashboard.tsx` | Them tab "Giao dien" voi cac form tuy chinh |
| `src/pages/Index.tsx` | Doc cau hinh tu `app_settings` de hien thi dong |
| `src/components/home/HeroSection.tsx` | Ho tro hien thi video/anh tu cau hinh |
| `supabase/functions/send-verification-code/index.ts` | Doc email template tu DB thay vi hardcode |
| RLS Policy | Them policy cho phep doc public cac key moi (`HERO_CONFIG`, `HOMEPAGE_SECTIONS`, `SECTION_ORDER`) |

---

## Giai doan 3: Tinh chinh nang cao (Tuong lai)

- Them/bot section tu dinh nghia (custom blocks)
- Chinh sua noi dung About, Green Fund truc tiep tu admin
- Quan ly font, mau sac toan cuc (theme editor)
- Lich gui email tu dong, triggers

---

## Chi tiet ky thuat - Giai doan 1 (se lam ngay)

### Database

- Them type `signup_verify` vao edge function `send-verification-code`
- Khong can tao bang moi (dung lai `verification_codes`)

### Auth.tsx - State moi

```text
resendCountdown: number (0 = co the gui, >0 = dang dem nguoc)
signupOtpStep: "none" | "verify"
signupOtpEmail: string
signupPendingData: { fullName, email, password }
```

### Edge function thay doi

- `send-verification-code`: Them type `signup_verify` + email template moi
- Khi xac thuc signup OTP thanh cong: Frontend goi `supabase.auth.signUp()` voi option auto-confirm (hoac dung edge function tao user qua admin API)

### Luu y

- File AdminDashboard.tsx hien da rat lon (2315 dong). Nen tach cac tab thanh component rieng de de quan ly khi them tab "Giao dien" o giai doan 2.
- Giai doan 2 se can them RLS policy cho cac key moi trong `app_settings` de frontend doc duoc.
