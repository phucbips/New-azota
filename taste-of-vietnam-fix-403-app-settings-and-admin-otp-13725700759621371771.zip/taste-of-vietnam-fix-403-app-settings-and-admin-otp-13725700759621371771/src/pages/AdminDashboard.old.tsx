import { useState, useEffect, useMemo, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Package, Users, BarChart3, Settings, Clock, ChefHat, Truck,
  CheckCircle2, Loader2, Search, Filter, Eye, EyeOff, RefreshCw, Mail,
  ChevronDown, CreditCard, Banknote, XCircle, Shield, UserPlus, UserMinus,
  DollarSign, TrendingUp, TrendingDown, PlusCircle, Trash2, Receipt, Ticket,
  ExternalLink, Phone, MapPin, Copy, Calendar, Tag, ShieldCheck, Palette
} from "lucide-react";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useRole } from "@/hooks/useRole";
import { formatPrice } from "@/data/mockMenu";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import { TagsInput } from "@/components/ui/tags-input";
import {
  SidebarProvider, Sidebar, SidebarContent, SidebarGroup,
  SidebarGroupLabel, SidebarGroupContent, SidebarMenu,
  SidebarMenuItem, SidebarMenuButton, SidebarTrigger
} from "@/components/ui/sidebar";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, BarChart, Bar
} from "recharts";
import VoucherManagement from "@/components/admin/VoucherManagement";
import InterfaceSettings from "@/components/admin/InterfaceSettings";

// --- Sub-components for Admin Dashboard Tabs ---

const StatsTab = ({ orders }: { orders: Order[] }) => {
  const stats = useMemo(() => {
    return {
      total: orders.length,
      pending: orders.filter((o) => o.status === "pending").length,
      revenue: orders.filter((o) => o.status === "delivered").reduce((s, o) => s + o.total, 0),
      today: orders.filter((o) => new Date(o.created_at).toDateString() === new Date().toDateString()).length,
    };
  }, [orders]);

  return (
    <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
      <div className="rounded-2xl border border-border bg-card p-6">
        <div className="mb-2 flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
          <Package className="h-5 w-5 text-primary" />
        </div>
        <p className="text-sm text-muted-foreground">Tổng đơn</p>
        <h3 className="text-2xl font-extrabold text-foreground">{stats.total}</h3>
      </div>
      <div className="rounded-2xl border border-border bg-card p-6">
        <div className="mb-2 flex h-10 w-10 items-center justify-center rounded-full bg-yellow-50">
          <Clock className="h-5 w-5 text-yellow-600" />
        </div>
        <p className="text-sm text-muted-foreground">Chờ xử lý</p>
        <h3 className="text-2xl font-extrabold text-foreground">{stats.pending}</h3>
      </div>
      <div className="rounded-2xl border border-border bg-card p-6">
        <div className="mb-2 flex h-10 w-10 items-center justify-center rounded-full bg-green-50">
          <DollarSign className="h-5 w-5 text-green-600" />
        </div>
        <p className="text-sm text-muted-foreground">Doanh thu</p>
        <h3 className="text-2xl font-extrabold text-foreground">{formatPrice(stats.revenue)}</h3>
      </div>
      <div className="rounded-2xl border border-border bg-card p-6">
        <div className="mb-2 flex h-10 w-10 items-center justify-center rounded-full bg-blue-50">
          <Calendar className="h-5 w-5 text-blue-600" />
        </div>
        <p className="text-sm text-muted-foreground">Đơn hôm nay</p>
        <h3 className="text-2xl font-extrabold text-foreground">{stats.today}</h3>
      </div>
    </div>
  );
};

const FinanceTab = () => (
  <div className="rounded-2xl border border-border bg-card p-10 text-center text-muted-foreground">
    <DollarSign className="mx-auto h-10 w-10 mb-4 opacity-50" />
    <p>Tính năng quản lý tài chính đang được phát triển.</p>
  </div>
);

const UsersTab = () => (
  <div className="rounded-2xl border border-border bg-card p-10 text-center text-muted-foreground">
    <Users className="mx-auto h-10 w-10 mb-4 opacity-50" />
    <p>Tính năng quản lý người dùng đang được phát triển.</p>
  </div>
);

const RolesTab = () => (
  <div className="rounded-2xl border border-border bg-card p-10 text-center text-muted-foreground">
    <Shield className="mx-auto h-10 w-10 mb-4 opacity-50" />
    <p>Tính năng phân quyền đang được phát triển.</p>
  </div>
);

const SurchargesTab = () => (
  <div className="rounded-2xl border border-border bg-card p-10 text-center text-muted-foreground">
    <PlusCircle className="mx-auto h-10 w-10 mb-4 opacity-50" />
    <p>Tính năng quản lý phụ phí đang được phát triển.</p>
  </div>
);

const AnalyticsTab = () => (
  <div className="rounded-2xl border border-border bg-card p-10 text-center text-muted-foreground">
    <TrendingUp className="mx-auto h-10 w-10 mb-4 opacity-50" />
    <p>Tính năng phân tích nâng cao đang được phát triển.</p>
  </div>
);

const SettingsTab = () => (
  <div className="rounded-2xl border border-border bg-card p-10 text-center text-muted-foreground">
    <Settings className="mx-auto h-10 w-10 mb-4 opacity-50" />
    <p>Cài đặt hệ thống đang được phát triển.</p>
  </div>
);

const STATUS_MAP: Record<string, { label: string; icon: React.ElementType; color: string }> = {
  pending: { label: "Chờ xác nhận", icon: Clock, color: "text-yellow-600 bg-yellow-50" },
  preparing: { label: "Đang chuẩn bị", icon: ChefHat, color: "text-orange-500 bg-orange-50" },
  delivering: { label: "Đang giao", icon: Truck, color: "text-blue-500 bg-blue-50" },
  delivered: { label: "Đã giao", icon: CheckCircle2, color: "text-primary bg-primary/10" },
  cancelled: { label: "Đã hủy", icon: XCircle, color: "text-destructive bg-destructive/10" },
};

const STATUSES = ["pending", "preparing", "delivering", "delivered", "cancelled"];

type Tab = "orders" | "users" | "stats" | "finance" | "surcharges" | "settings" | "roles" | "analytics" | "vouchers" | "interface";

interface Order {
  id: string;
  order_code: string;
  customer_name: string;
  phone: string;
  address: string;
  total: number;
  subtotal: number;
  shipping_fee: number;
  green_fund_amount: number;
  status: string;
  created_at: string;
  payment_method: string;
  payment_status: string;
  notes: string | null;
}

interface OrderItem {
  id: string;
  cookie_name: string;
  quantity: number;
  unit_price: number;
  total_price: number;
}

const sidebarItems = [
  { title: "Đơn hàng", tab: "orders" as const, icon: Package },
  { title: "Thống kê", tab: "stats" as const, icon: BarChart3 },
  { title: "Tài chính", tab: "finance" as const, icon: DollarSign },
  { title: "Người dùng", tab: "users" as const, icon: Users },
  { title: "Phân quyền", tab: "roles" as const, icon: Shield },
  { title: "Phụ phí", tab: "surcharges" as const, icon: PlusCircle },
  { title: "Voucher", tab: "vouchers" as const, icon: Ticket },
  { title: "Phân tích", tab: "analytics" as const, icon: TrendingUp },
  { title: "Giao diện", tab: "interface" as const, icon: Palette },
  { title: "Cài đặt", tab: "settings" as const, icon: Settings },
];

const AdminDashboard = () => {
  const { user, loading: authLoading } = useAuth();
  const { isAdmin, loading: roleLoading } = useRole();
  const navigate = useNavigate();
  const [tab, setTab] = useState<Tab>("orders");
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [orderItems, setOrderItems] = useState<Record<string, OrderItem[]>>({});
  const [loadingItems, setLoadingItems] = useState<string | null>(null);
  const [updatingStatus, setUpdatingStatus] = useState<string | null>(null);
  const [orderVouchers, setOrderVouchers] = useState<Record<string, any | null>>({});

  // Admin OTP verification state
  const [adminVerified, setAdminVerified] = useState(false);
  const [otpStep, setOtpStep] = useState<"sending" | "verify" | "done">("sending");
  const [otpCode, setOtpCode] = useState("");
  const [otpLoading, setOtpLoading] = useState(false);
  const [resendCountdown, setResendCountdown] = useState(0);

  const formatRemainingTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return mins > 0 ? `${mins}m ${secs}s` : `${secs}s`;
  };

  // Countdown effect
  useEffect(() => {
    if (resendCountdown <= 0) return;
    const timer = setInterval(() => {
      setResendCountdown((prev) => (prev <= 1 ? 0 : prev - 1));
    }, 1000);
    return () => clearInterval(timer);
  }, [resendCountdown]);

  const toggleExpand = async (orderId: string) => {
    if (expandedId === orderId) { setExpandedId(null); return; }
    setExpandedId(orderId);
    if (!orderItems[orderId]) {
      setLoadingItems(orderId);
      const [itemsRes, voucherRes] = await Promise.all([
        supabase.from("order_items").select("*").eq("order_id", orderId),
        supabase.from("user_vouchers").select("*, voucher_templates(name, type, value)").eq("order_id", orderId).maybeSingle(),
      ]);
      if (itemsRes.data) setOrderItems((prev) => ({ ...prev, [orderId]: itemsRes.data }));
      setOrderVouchers((prev) => ({ ...prev, [orderId]: voucherRes.data || null }));
      setLoadingItems(null);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success("Đã sao chép!");
  };

  useEffect(() => {
    if (!authLoading && !roleLoading) {
      if (!user) navigate("/auth");
      else if (!isAdmin) navigate("/");
    }
  }, [user, isAdmin, authLoading, roleLoading, navigate]);

  // Send admin OTP when page loads and user is admin (only once per session window)
  const otpSentRef = useRef(false);
  useEffect(() => {
    if (!isAdmin || !user || adminVerified) return;
    if (otpSentRef.current) return;

    const sessionKey = `admin_otp_last_sent_${user.id}`;
    const lastSentAt = Number(sessionStorage.getItem(sessionKey) || 0);
    const elapsedSeconds = Math.floor((Date.now() - lastSentAt) / 1000);

    if (lastSentAt > 0 && elapsedSeconds < 300) {
      otpSentRef.current = true;
      setOtpStep("verify");
      if (elapsedSeconds < 60) {
        setResendCountdown(60 - elapsedSeconds);
      }
      return;
    }

    otpSentRef.current = true;
    const sendOtp = async () => {
      if (!user?.email) return;
      setOtpStep("sending");

      const { data, error } = await supabase.functions.invoke("send-verification-code", {
        body: { email: user.email, type: "admin_login" },
      });

      if (error || (data && !data.success)) {
        toast.error("Không thể gửi mã xác thực: " + (error?.message || data?.error));
        setOtpStep("verify");
      } else {
        sessionStorage.setItem(sessionKey, String(Date.now()));
        toast.info("Mã xác thực đã được gửi đến email của bạn");
        setOtpStep("verify");
        setResendCountdown(60);
      }
    };

    sendOtp();
  }, [isAdmin, user, adminVerified]);

  const handleAdminOtpVerify = async () => {
    if (otpCode.length !== 6) {
      toast.error("Vui lòng nhập đủ 6 chữ số");
      return;
    }
    setOtpLoading(true);

    try {
      const { data, error } = await supabase.functions.invoke("verify-code", {
        body: { email: user!.email!, code: otpCode, type: "admin_login" },
      });

      if (error || !data?.valid) {
        toast.error("Mã không hợp lệ hoặc đã hết hạn");
      } else {
        setAdminVerified(true);
        setOtpStep("done");
        toast.success("Xác thực thành công!");
      }
    } catch (err: any) {
      console.error("OTP verify error:", err);
      toast.error("Lỗi xác thực: " + (err.message || "Vui lòng thử lại"));
    } finally {
      setOtpLoading(false);
    }
  };

  const handleResendAdminOtp = async () => {
    if (!user?.email) {
      toast.error("Không tìm thấy email admin");
      return;
    }
    if (resendCountdown > 0) return;

    setOtpLoading(true);
    // Clear old code immediately to force re-entry
    setOtpCode("");

    try {
      const { data, error } = await supabase.functions.invoke("send-verification-code", {
        body: { email: user.email, type: "admin_login" },
      });

      if (error || (data && !data.success)) {
        toast.error("Không thể gửi lại mã: " + (error?.message || data?.error));
      } else {
        sessionStorage.setItem(`admin_otp_last_sent_${user.id}`, String(Date.now()));
        toast.success("Đã gửi lại mã xác thực!");
        setResendCountdown(60);
        // Ensure UI stays on verify step
        setOtpStep("verify");
      }
    } catch (err: any) {
      console.error("OTP resend error:", err);
      toast.error("Lỗi gửi mã: " + (err.message || "Vui lòng thử lại"));
    } finally {
      setOtpLoading(false);
    }
  };

  // ... (rest of the file content remains the same)

  const fetchOrders = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("orders")
      .select("*")
      .order("created_at", { ascending: false });
    if (!error && data) setOrders(data);
    setLoading(false);
  };

  useEffect(() => {
    if (isAdmin && adminVerified) fetchOrders();
  }, [isAdmin, adminVerified]);

  const updateOrderStatus = async (orderId: string, newStatus: string) => {
    setUpdatingStatus(orderId);
    const order = orders.find((o) => o.id === orderId);
    const previousStatus = order?.status;

    const { error } = await supabase
      .from("orders")
      .update({ status: newStatus })
      .eq("id", orderId);

    if (!error) {
      setOrders((prev) => prev.map((o) => o.id === orderId ? { ...o, status: newStatus } : o));

      // When delivered: decrease stock + auto-add revenue
      if (newStatus === "delivered" && previousStatus !== "delivered" && order) {
        // Fetch order items to decrease stock
        let items = orderItems[orderId];
        if (!items) {
          const { data } = await supabase.from("order_items").select("*").eq("order_id", orderId);
          if (data) {
            items = data;
            setOrderItems((prev) => ({ ...prev, [orderId]: data }));
          }
        }
        if (items) {
          // Decrease stock for each item
          for (const item of items) {
            await supabase.rpc("has_role", { _user_id: user!.id, _role: "admin" as any }); // just to keep auth context
            const { data: menuItem } = await supabase
              .from("monthly_menu")
              .select("id, stock")
              .eq("cookie_name", item.cookie_name)
              .eq("is_active", true)
              .maybeSingle();
            if (menuItem) {
              await supabase
                .from("monthly_menu")
                .update({ stock: Math.max(0, menuItem.stock - item.quantity) } as any)
                .eq("id", menuItem.id);
            }
          }
        }

        // Auto-add revenue transaction
        await supabase.from("financial_transactions").insert({
          type: "income",
          category: "order_revenue",
          amount: order.total,
          description: `Đơn hàng ${order.order_code} giao thành công`,
          created_by: user!.id,
          reference_order_id: orderId,
        } as any);
      }
    }
    setUpdatingStatus(null);
  };

  const filteredOrders = orders.filter((o) => {
    const matchSearch = searchQuery === "" ||
      o.order_code.toLowerCase().includes(searchQuery.toLowerCase()) ||
      o.customer_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      o.phone.includes(searchQuery);
    const matchStatus = statusFilter === "all" || o.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const stats = {
    total: orders.length,
    pending: orders.filter((o) => o.status === "pending").length,
    revenue: orders.filter((o) => o.status === "delivered").reduce((s, o) => s + o.total, 0),
    today: orders.filter((o) => new Date(o.created_at).toDateString() === new Date().toDateString()).length,
  };

  if (authLoading || roleLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  // Admin OTP verification gate
  if (isAdmin && !adminVerified) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background px-4">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-md">
          <div className="mb-8 text-center">
            <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-primary/10">
              <ShieldCheck className="h-7 w-7 text-primary" />
            </div>
            <h1 className="font-display text-3xl font-extrabold text-foreground">Xác thực Admin</h1>
            <p className="mt-2 text-sm text-muted-foreground">
              Mã 6 chữ số đã được gửi đến <span className="font-semibold text-foreground">{user?.email}</span>
            </p>
          </div>

          <div className="space-y-6 rounded-2xl border border-border bg-card p-6">
            {otpStep === "sending" ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-6 w-6 animate-spin text-primary" />
              </div>
            ) : (
              <>
                <div className="flex justify-center">
                  <InputOTP maxLength={6} value={otpCode} onChange={setOtpCode}>
                    <InputOTPGroup>
                      <InputOTPSlot index={0} />
                      <InputOTPSlot index={1} />
                      <InputOTPSlot index={2} />
                      <InputOTPSlot index={3} />
                      <InputOTPSlot index={4} />
                      <InputOTPSlot index={5} />
                    </InputOTPGroup>
                  </InputOTP>
                </div>

                <button
                  onClick={handleAdminOtpVerify}
                  disabled={otpLoading || otpCode.length !== 6}
                  className="w-full rounded-full bg-primary px-6 py-3 text-sm font-bold text-primary-foreground transition-transform hover:scale-[1.02] disabled:opacity-50"
                >
                  {otpLoading ? (
                    <span className="flex items-center justify-center gap-2">
                      <Loader2 className="h-4 w-4 animate-spin" />
                      Đang xác thực...
                    </span>
                  ) : "Xác nhận"}
                </button>

                <div className="flex items-center justify-between text-sm">
                  <button
                    onClick={handleResendAdminOtp}
                    disabled={otpLoading || resendCountdown > 0}
                    className="font-semibold text-primary hover:underline disabled:opacity-50 disabled:no-underline"
                  >
                    {resendCountdown > 0 ? `Gửi lại mã (${resendCountdown}s)` : "Gửi lại mã"}
                  </button>
                  <button
                    onClick={() => navigate("/")}
                    className="text-muted-foreground hover:text-foreground"
                  >
                    Quay lại
                  </button>
                </div>
              </>
            )}
          </div>
        </motion.div>
      </div>
    );
  }

  // ... (rest of sidebar and main content components - copy paste original)
  // Re-pasting the sidebar and return structure from previous read:

  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full bg-background">
        <Sidebar className="w-60 border-r border-border" collapsible="icon">
          <SidebarContent className="pt-4">
            <div className="mb-6 px-4">
              <h2 className="font-display text-lg font-extrabold text-foreground">Admin</h2>
              <p className="text-xs text-muted-foreground">Nova Cookie</p>
            </div>
            <SidebarGroup>
              <SidebarGroupLabel>Quản lý</SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  {sidebarItems.map((item) => (
                    <SidebarMenuItem key={item.tab}>
                      <SidebarMenuButton
                        onClick={() => setTab(item.tab)}
                        className={`cursor-pointer ${tab === item.tab ? "bg-primary/10 text-primary font-medium" : ""}`}
                      >
                        <item.icon className="mr-2 h-4 w-4" />
                        <span>{item.title}</span>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
            <div className="mt-auto px-4 py-4">
              <button
                onClick={() => navigate("/")}
                className="text-xs text-muted-foreground hover:text-foreground"
              >
                ← Về trang chủ
              </button>
            </div>
          </SidebarContent>
        </Sidebar>

        <main className="flex-1 p-6 md:p-8">
          <div className="mb-6 flex items-center gap-3">
            <SidebarTrigger />
            <h1 className="font-display text-2xl font-extrabold text-foreground">
              {sidebarItems.find((i) => i.tab === tab)?.title}
            </h1>
          </div>

          {tab === "orders" && (
            <div className="space-y-4">
              {/* ... (Orders tab content) ... */}
              <div className="flex flex-col gap-3 sm:flex-row">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <input
                    placeholder="Tìm mã đơn, tên, SĐT..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full rounded-xl border border-border bg-background py-2.5 pl-10 pr-4 text-sm outline-none focus:border-primary"
                  />
                </div>
                <div className="flex gap-2 flex-wrap">
                  {["all", ...STATUSES].map((s) => (
                    <button
                      key={s}
                      onClick={() => setStatusFilter(s)}
                      className={`rounded-full px-3 py-1.5 text-xs font-semibold transition-colors ${
                        statusFilter === s ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:bg-muted/80"
                      }`}
                    >
                      {s === "all" ? "Tất cả" : STATUS_MAP[s]?.label}
                    </button>
                  ))}
                </div>
                <button onClick={fetchOrders} className="rounded-xl border border-border p-2.5 hover:bg-muted">
                  <RefreshCw className="h-4 w-4" />
                </button>
              </div>

              {loading ? (
                <div className="flex justify-center py-20">
                  <Loader2 className="h-6 w-6 animate-spin text-primary" />
                </div>
              ) : filteredOrders.length === 0 ? (
                <div className="rounded-2xl border border-border bg-card p-10 text-center text-muted-foreground">
                  Không có đơn hàng nào
                </div>
              ) : (
                <div className="space-y-3">
                  {filteredOrders.map((order) => {
                    const status = STATUS_MAP[order.status] || STATUS_MAP.pending;
                    const StatusIcon = status.icon;
                    const isExpanded = expandedId === order.id;
                    const items = orderItems[order.id];
                    const paymentLabel = order.payment_status === "paid" ? "Đã TT" : order.payment_status === "expired" ? "Hết hạn" : "Chưa TT";
                    const paymentColor = order.payment_status === "paid" ? "text-primary bg-primary/10" : order.payment_status === "expired" ? "text-destructive bg-destructive/10" : "text-yellow-600 bg-yellow-50";
                    return (
                      <motion.div
                        key={order.id}
                        initial={{ opacity: 0, y: 5 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="rounded-2xl border border-border bg-card overflow-hidden hover:shadow-sm transition-shadow"
                      >
                        <div className="p-4 cursor-pointer" onClick={() => toggleExpand(order.id)}>
                          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1 flex-wrap">
                                <span className="font-mono text-sm font-bold text-foreground">{order.order_code}</span>
                                <span className={`flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-semibold ${status.color}`}>
                                  <StatusIcon className="h-3 w-3" />
                                  {status.label}
                                </span>
                                <span className={`rounded-full px-2 py-0.5 text-xs font-semibold ${paymentColor}`}>
                                  {paymentLabel}
                                </span>
                                <ChevronDown className={`h-4 w-4 text-muted-foreground transition-transform ml-auto ${isExpanded ? "rotate-180" : ""}`} />
                              </div>
                              <p className="text-sm text-foreground">{order.customer_name} · {order.phone}</p>
                              <p className="mt-1 text-xs text-muted-foreground">
                                {new Date(order.created_at).toLocaleString("vi-VN")} · {order.payment_method === "bank_transfer" ? "Chuyển khoản" : "Tiền mặt"}
                              </p>
                            </div>
                            <div className="flex items-center gap-3" onClick={(e) => e.stopPropagation()}>
                              <span className="font-bold text-primary">{formatPrice(order.total)}</span>
                              <div className="flex gap-1">
                                {STATUSES.map((s) => {
                                  const si = STATUS_MAP[s];
                                  const Icon = si.icon;
                                  const isCurrent = order.status === s;
                                  return (
                                    <button
                                      key={s}
                                      title={si.label}
                                      disabled={isCurrent || updatingStatus === order.id}
                                      onClick={() => updateOrderStatus(order.id, s)}
                                      className={`rounded-lg p-1.5 transition-colors ${
                                        isCurrent ? "bg-primary/10 text-primary" : "text-muted-foreground hover:bg-muted"
                                      } disabled:opacity-30`}
                                    >
                                      <Icon className="h-4 w-4" />
                                    </button>
                                  );
                                })}
                              </div>
                            </div>
                          </div>
                        </div>

                        <AnimatePresence>
                          {isExpanded && (
                            <motion.div
                              initial={{ height: 0, opacity: 0 }}
                              animate={{ height: "auto", opacity: 1 }}
                              exit={{ height: 0, opacity: 0 }}
                              className="border-t border-border"
                            >
                              <div className="p-4">
                                <div className="flex items-center gap-2 mb-4">
                                  <span className="font-mono text-lg font-bold text-foreground">{order.order_code}</span>
                                  <button onClick={() => copyToClipboard(order.order_code)} className="rounded-lg p-1 text-muted-foreground hover:bg-muted hover:text-foreground transition-colors" title="Sao chép mã đơn">
                                    <Copy className="h-4 w-4" />
                                  </button>
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                  <div className="space-y-3">
                                    <h4 className="text-xs font-semibold uppercase text-muted-foreground tracking-wider">Khách hàng</h4>

                                    <div className="flex items-center gap-2 text-sm text-foreground">
                                      <Phone className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                                      <a href={`tel:${order.phone}`} className="text-primary hover:underline font-medium">
                                        {order.phone}
                                      </a>
                                    </div>

                                    <div className="flex items-start gap-2 text-sm">
                                      <MapPin className="h-4 w-4 text-muted-foreground flex-shrink-0 mt-0.5" />
                                      <a
                                        href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(order.address)}`}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="text-primary hover:underline break-all"
                                      >
                                        {order.address}
                                        <ExternalLink className="inline-block h-3 w-3 ml-1 -mt-0.5" />
                                      </a>
                                    </div>

                                    <div className="flex items-center gap-2 text-sm text-foreground">
                                      <Calendar className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                                      <span>{new Date(order.created_at).toLocaleDateString("vi-VN", { weekday: "long", day: "2-digit", month: "2-digit", year: "numeric" })} · {new Date(order.created_at).toLocaleTimeString("vi-VN", { hour: "2-digit", minute: "2-digit" })}</span>
                                    </div>

                                    <div className="flex items-center gap-2 text-sm text-foreground">
                                      {order.payment_method === "bank_transfer" ? <CreditCard className="h-4 w-4 text-muted-foreground" /> : <Banknote className="h-4 w-4 text-muted-foreground" />}
                                      <span>{order.payment_method === "bank_transfer" ? "Chuyển khoản" : "Tiền mặt"}</span>
                                      <span className={`rounded-full px-2 py-0.5 text-xs font-semibold ${paymentColor}`}>{paymentLabel}</span>
                                    </div>

                                    {order.notes && (
                                      <div className="rounded-lg bg-muted/50 px-3 py-2 text-xs text-muted-foreground">📝 {order.notes}</div>
                                    )}
                                  </div>

                                  <div className="space-y-3">
                                    <h4 className="text-xs font-semibold uppercase text-muted-foreground tracking-wider">Chi tiết đơn</h4>
                                    {loadingItems === order.id ? (
                                      <Loader2 className="h-5 w-5 animate-spin text-primary mx-auto" />
                                    ) : items ? (
                                      <div className="space-y-2 text-sm">
                                        {items.map((item) => (
                                          <div key={item.id} className="flex justify-between">
                                            <span className="text-foreground">{item.cookie_name} × {item.quantity}</span>
                                            <span className="text-foreground font-medium">{formatPrice(item.total_price)}</span>
                                          </div>
                                        ))}
                                        <div className="border-t border-border pt-2 space-y-1">
                                          <div className="flex justify-between text-xs">
                                            <span className="text-muted-foreground">Tạm tính</span>
                                            <span>{formatPrice(order.subtotal)}</span>
                                          </div>
                                          <div className="flex justify-between text-xs">
                                            <span className="text-muted-foreground">Ship</span>
                                            <span>{order.shipping_fee === 0 ? "Miễn phí" : formatPrice(order.shipping_fee)}</span>
                                          </div>
                                          <div className="flex justify-between text-xs text-primary">
                                            <span>🌱 Quỹ xanh</span>
                                            <span>{formatPrice(order.green_fund_amount)}</span>
                                          </div>
                                          {orderVouchers[order.id] && (
                                            <div className="flex justify-between text-xs text-accent-foreground">
                                              <span className="flex items-center gap-1"><Tag className="h-3 w-3" /> Voucher: {orderVouchers[order.id].code}</span>
                                              <span>-{orderVouchers[order.id].voucher_templates?.type === "percent" ? `${orderVouchers[order.id].voucher_templates.value}%` : formatPrice(orderVouchers[order.id].voucher_templates?.value || 0)}</span>
                                            </div>
                                          )}
                                          <div className="flex justify-between text-sm font-bold pt-1 border-t border-border">
                                            <span>Tổng</span>
                                            <span className="text-primary">{formatPrice(order.total)}</span>
                                          </div>
                                        </div>
                                      </div>
                                    ) : null}
                                  </div>
                                </div>
                              </div>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </motion.div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {tab === "stats" && <StatsTab orders={orders} />}
          {tab === "finance" && <FinanceTab />}
          {tab === "surcharges" && <SurchargesTab />}
          {tab === "users" && <UsersTab />}
          {tab === "roles" && <RolesTab />}
          {tab === "analytics" && <AnalyticsTab />}
          {tab === "vouchers" && <VoucherManagement />}
          {tab === "interface" && <InterfaceSettings />}
          {tab === "settings" && <SettingsTab />}
        </main>
      </div>
    </SidebarProvider>
  );
};

export default AdminDashboard;
