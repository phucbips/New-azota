import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { getRequiredEnv, corsHeaders } from "../_shared/utils.ts";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      getRequiredEnv("SUPABASE_URL"),
      getRequiredEnv("SUPABASE_SERVICE_ROLE_KEY")
    );

    // Find all transfer orders that are pending payment and past deadline
    const now = new Date().toISOString();

    const { data: expiredOrders, error: fetchError } = await supabase
      .from("orders")
      .select("id, order_code")
      .eq("payment_method", "bank_transfer")
      .eq("payment_status", "pending")
      .eq("status", "pending")
      .not("payment_deadline", "is", null)
      .lt("payment_deadline", now);

    if (fetchError) {
      console.error("Error fetching expired orders:", fetchError);
      return new Response(JSON.stringify({ error: fetchError.message }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (!expiredOrders || expiredOrders.length === 0) {
      return new Response(JSON.stringify({ cancelled: 0 }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const ids = expiredOrders.map((o) => o.id);

    const { error: updateError } = await supabase
      .from("orders")
      .update({ status: "cancelled", payment_status: "expired" })
      .in("id", ids);

    if (updateError) {
      console.error("Error cancelling orders:", updateError);
      return new Response(JSON.stringify({ error: updateError.message }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    console.log(`Auto-cancelled ${ids.length} expired orders:`, expiredOrders.map((o) => o.order_code));

    return new Response(
      JSON.stringify({ cancelled: ids.length, orders: expiredOrders.map((o) => o.order_code) }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Error:", error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
