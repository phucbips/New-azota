import { useState, useEffect } from "react";
import { toast } from "sonner";
import { Loader2, Save, Eye, EyeOff, GripVertical, Image, Video, Mail, ChevronDown, ChevronUp } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

interface HeroConfig {
  type: "image" | "video";
  media_url: string;
  title: string;
  subtitle: string;
  cta_text: string;
  cta_link: string;
}

interface HomepageSections {
  hero: boolean;
  menu: boolean;
  testimonials: boolean;
  about: boolean;
  green_fund: boolean;
}

interface SectionOrderItem {
  key: string;
  label: string;
}

interface EmailTemplateConfig {
  subject: string;
  title: string;
  description: string;
  header_color: string;
}

interface EmailTemplates {
  signup_verify: EmailTemplateConfig;
  password_reset: EmailTemplateConfig;
  admin_login: EmailTemplateConfig;
}

const DEFAULT_HERO: HeroConfig = {
  type: "image",
  media_url: "",
  title: "Nova Cookie",
  subtitle: "34 vị · 1 trái tim xanh",
  cta_text: "Đặt hàng ngay",
  cta_link: "/order",
};

const DEFAULT_SECTIONS: HomepageSections = {
  hero: true,
  menu: true,
  testimonials: true,
  about: true,
  green_fund: true,
};

const SECTION_LABELS: Record<string, string> = {
  hero: "Hero Banner",
  menu: "Menu sản phẩm",
  testimonials: "Đánh giá khách hàng",
  about: "Giới thiệu",
  green_fund: "Quỹ xanh",
};

const DEFAULT_ORDER = ["hero", "menu", "testimonials", "about", "green_fund"];

const DEFAULT_EMAIL_TEMPLATES: EmailTemplates = {
  signup_verify: {
    subject: "✉️ Xác thực email đăng ký - Nova Cookie",
    title: "Xác thực email đăng ký",
    description: "Vui lòng nhập mã bên dưới để hoàn tất đăng ký tài khoản Nova Cookie.",
    header_color: "#2d5a27",
  },
  password_reset: {
    subject: "🔑 Mã đặt lại mật khẩu - Nova Cookie",
    title: "Đặt lại mật khẩu",
    description: "Vui lòng nhập mã bên dưới để đặt lại mật khẩu của bạn.",
    header_color: "#2d5a27",
  },
  admin_login: {
    subject: "🔐 Mã xác thực đăng nhập Admin - Nova Cookie",
    title: "Xác thực đăng nhập Admin",
    description: "Vui lòng nhập mã bên dưới để hoàn tất đăng nhập vào trang quản trị.",
    header_color: "#2d5a27",
  },
};

const InterfaceSettings = () => {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  // Hero config
  const [heroConfig, setHeroConfig] = useState<HeroConfig>(DEFAULT_HERO);

  // Sections visibility
  const [sections, setSections] = useState<HomepageSections>(DEFAULT_SECTIONS);

  // Section order
  const [sectionOrder, setSectionOrder] = useState<string[]>(DEFAULT_ORDER);

  // Email templates
  const [emailTemplates, setEmailTemplates] = useState<EmailTemplates>(DEFAULT_EMAIL_TEMPLATES);

  // Accordion states
  const [openPanel, setOpenPanel] = useState<string | null>("hero");

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    setLoading(true);
    const { data } = await supabase
      .from("app_settings")
      .select("key, value")
      .in("key", ["HERO_CONFIG", "HOMEPAGE_SECTIONS", "SECTION_ORDER", "EMAIL_TEMPLATES"]);

    if (data) {
      data.forEach((row) => {
        try {
          const parsed = JSON.parse(row.value);
          switch (row.key) {
            case "HERO_CONFIG":
              setHeroConfig({ ...DEFAULT_HERO, ...parsed });
              break;
            case "HOMEPAGE_SECTIONS":
              setSections({ ...DEFAULT_SECTIONS, ...parsed });
              break;
            case "SECTION_ORDER":
              if (Array.isArray(parsed)) setSectionOrder(parsed);
              break;
            case "EMAIL_TEMPLATES":
              setEmailTemplates({ ...DEFAULT_EMAIL_TEMPLATES, ...parsed });
              break;
          }
        } catch {}
      });
    }
    setLoading(false);
  };

  const saveSetting = async (key: string, value: any) => {
    const jsonValue = JSON.stringify(value);
    // Upsert: try update first, then insert if not exists
    const { data: existing } = await supabase
      .from("app_settings")
      .select("id")
      .eq("key", key)
      .maybeSingle();

    if (existing) {
      await supabase.from("app_settings").update({ value: jsonValue } as any).eq("key", key);
    } else {
      await supabase.from("app_settings").insert({ key, value: jsonValue } as any);
    }
  };

  const handleSaveAll = async () => {
    setSaving(true);
    try {
      await Promise.all([
        saveSetting("HERO_CONFIG", heroConfig),
        saveSetting("HOMEPAGE_SECTIONS", sections),
        saveSetting("SECTION_ORDER", sectionOrder),
        saveSetting("EMAIL_TEMPLATES", emailTemplates),
      ]);
      toast.success("Đã lưu cấu hình giao diện!");
    } catch (err) {
      toast.error("Không thể lưu cấu hình");
    }
    setSaving(false);
  };

  const moveSection = (index: number, direction: "up" | "down") => {
    const newOrder = [...sectionOrder];
    const targetIndex = direction === "up" ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= newOrder.length) return;
    [newOrder[index], newOrder[targetIndex]] = [newOrder[targetIndex], newOrder[index]];
    setSectionOrder(newOrder);
  };

  const togglePanel = (panel: string) => {
    setOpenPanel(openPanel === panel ? null : panel);
  };

  if (loading) {
    return (
      <div className="flex justify-center py-20">
        <Loader2 className="h-6 w-6 animate-spin text-primary" />
      </div>
    );
  }

  const inputClass = "w-full rounded-xl border border-border bg-background px-4 py-2.5 text-sm text-foreground outline-none focus:border-primary focus:ring-2 focus:ring-primary/20";

  return (
    <div className="space-y-4">
      {/* Save button */}
      <div className="flex justify-end">
        <button
          onClick={handleSaveAll}
          disabled={saving}
          className="flex items-center gap-2 rounded-full bg-primary px-6 py-2.5 text-sm font-bold text-primary-foreground transition-transform hover:scale-[1.02] disabled:opacity-50"
        >
          {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
          Lưu tất cả
        </button>
      </div>

      {/* Panel 1: Hero Banner */}
      <div className="rounded-2xl border border-border bg-card overflow-hidden">
        <button
          onClick={() => togglePanel("hero")}
          className="flex w-full items-center justify-between p-5 text-left"
        >
          <div className="flex items-center gap-3">
            <Image className="h-5 w-5 text-primary" />
            <span className="font-semibold text-foreground">Hero Banner</span>
          </div>
          {openPanel === "hero" ? <ChevronUp className="h-4 w-4 text-muted-foreground" /> : <ChevronDown className="h-4 w-4 text-muted-foreground" />}
        </button>
        {openPanel === "hero" && (
          <div className="space-y-4 border-t border-border p-5">
            <div className="flex gap-3">
              <button
                onClick={() => setHeroConfig({ ...heroConfig, type: "image" })}
                className={`flex items-center gap-2 rounded-full px-4 py-2 text-sm font-medium transition-colors ${heroConfig.type === "image" ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}
              >
                <Image className="h-4 w-4" /> Ảnh
              </button>
              <button
                onClick={() => setHeroConfig({ ...heroConfig, type: "video" })}
                className={`flex items-center gap-2 rounded-full px-4 py-2 text-sm font-medium transition-colors ${heroConfig.type === "video" ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}
              >
                <Video className="h-4 w-4" /> Video
              </button>
            </div>

            <div>
              <label className="mb-1.5 block text-sm font-semibold text-foreground">
                URL {heroConfig.type === "video" ? "Video" : "Ảnh"} (để trống = mặc định)
              </label>
              <input
                value={heroConfig.media_url}
                onChange={(e) => setHeroConfig({ ...heroConfig, media_url: e.target.value })}
                placeholder={heroConfig.type === "video" ? "https://example.com/video.mp4" : "https://example.com/image.jpg"}
                className={inputClass}
              />
            </div>

            {heroConfig.media_url && (
              <div className="rounded-xl border border-border overflow-hidden">
                <p className="px-3 py-1.5 text-xs font-medium text-muted-foreground bg-muted/50">Xem trước</p>
                {heroConfig.type === "video" ? (
                  <video src={heroConfig.media_url} className="w-full max-h-48 object-cover" autoPlay muted loop playsInline />
                ) : (
                  <img src={heroConfig.media_url} alt="Preview" className="w-full max-h-48 object-cover" />
                )}
              </div>
            )}

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div>
                <label className="mb-1.5 block text-sm font-semibold text-foreground">Tiêu đề</label>
                <input
                  value={heroConfig.title}
                  onChange={(e) => setHeroConfig({ ...heroConfig, title: e.target.value })}
                  className={inputClass}
                />
              </div>
              <div>
                <label className="mb-1.5 block text-sm font-semibold text-foreground">Mô tả</label>
                <input
                  value={heroConfig.subtitle}
                  onChange={(e) => setHeroConfig({ ...heroConfig, subtitle: e.target.value })}
                  className={inputClass}
                />
              </div>
              <div>
                <label className="mb-1.5 block text-sm font-semibold text-foreground">Nút CTA</label>
                <input
                  value={heroConfig.cta_text}
                  onChange={(e) => setHeroConfig({ ...heroConfig, cta_text: e.target.value })}
                  className={inputClass}
                />
              </div>
              <div>
                <label className="mb-1.5 block text-sm font-semibold text-foreground">Link CTA</label>
                <input
                  value={heroConfig.cta_link}
                  onChange={(e) => setHeroConfig({ ...heroConfig, cta_link: e.target.value })}
                  className={inputClass}
                />
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Panel 2: Section visibility & order */}
      <div className="rounded-2xl border border-border bg-card overflow-hidden">
        <button
          onClick={() => togglePanel("sections")}
          className="flex w-full items-center justify-between p-5 text-left"
        >
          <div className="flex items-center gap-3">
            <Eye className="h-5 w-5 text-primary" />
            <span className="font-semibold text-foreground">Ẩn / Hiện & Sắp xếp Section</span>
          </div>
          {openPanel === "sections" ? <ChevronUp className="h-4 w-4 text-muted-foreground" /> : <ChevronDown className="h-4 w-4 text-muted-foreground" />}
        </button>
        {openPanel === "sections" && (
          <div className="space-y-2 border-t border-border p-5">
            {sectionOrder.map((key, index) => (
              <div
                key={key}
                className="flex items-center gap-3 rounded-xl border border-border bg-background p-3"
              >
                <GripVertical className="h-4 w-4 text-muted-foreground shrink-0" />
                <span className="flex-1 text-sm font-medium text-foreground">{SECTION_LABELS[key] || key}</span>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => moveSection(index, "up")}
                    disabled={index === 0}
                    className="rounded p-1 hover:bg-muted disabled:opacity-30"
                  >
                    <ChevronUp className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => moveSection(index, "down")}
                    disabled={index === sectionOrder.length - 1}
                    className="rounded p-1 hover:bg-muted disabled:opacity-30"
                  >
                    <ChevronDown className="h-4 w-4" />
                  </button>
                </div>
                <button
                  onClick={() => setSections({ ...sections, [key]: !sections[key as keyof HomepageSections] })}
                  className={`rounded-full p-1.5 transition-colors ${sections[key as keyof HomepageSections] ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground"}`}
                >
                  {sections[key as keyof HomepageSections] ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Panel 3: Email Templates */}
      <div className="rounded-2xl border border-border bg-card overflow-hidden">
        <button
          onClick={() => togglePanel("emails")}
          className="flex w-full items-center justify-between p-5 text-left"
        >
          <div className="flex items-center gap-3">
            <Mail className="h-5 w-5 text-primary" />
            <span className="font-semibold text-foreground">Email Templates</span>
          </div>
          {openPanel === "emails" ? <ChevronUp className="h-4 w-4 text-muted-foreground" /> : <ChevronDown className="h-4 w-4 text-muted-foreground" />}
        </button>
        {openPanel === "emails" && (
          <div className="space-y-6 border-t border-border p-5">
            {(["signup_verify", "password_reset", "admin_login"] as const).map((templateKey) => {
              const labels: Record<string, string> = {
                signup_verify: "📧 Email xác thực đăng ký",
                password_reset: "🔑 Email đặt lại mật khẩu",
                admin_login: "🔐 Email xác thực Admin",
              };
              const template = emailTemplates[templateKey];
              return (
                <div key={templateKey} className="space-y-3 rounded-xl border border-border p-4">
                  <h4 className="text-sm font-bold text-foreground">{labels[templateKey]}</h4>
                  <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                    <div>
                      <label className="mb-1 block text-xs font-semibold text-muted-foreground">Tiêu đề email</label>
                      <input
                        value={template.subject}
                        onChange={(e) =>
                          setEmailTemplates({
                            ...emailTemplates,
                            [templateKey]: { ...template, subject: e.target.value },
                          })
                        }
                        className={inputClass}
                      />
                    </div>
                    <div>
                      <label className="mb-1 block text-xs font-semibold text-muted-foreground">Tiêu đề nội dung</label>
                      <input
                        value={template.title}
                        onChange={(e) =>
                          setEmailTemplates({
                            ...emailTemplates,
                            [templateKey]: { ...template, title: e.target.value },
                          })
                        }
                        className={inputClass}
                      />
                    </div>
                    <div className="sm:col-span-2">
                      <label className="mb-1 block text-xs font-semibold text-muted-foreground">Mô tả</label>
                      <input
                        value={template.description}
                        onChange={(e) =>
                          setEmailTemplates({
                            ...emailTemplates,
                            [templateKey]: { ...template, description: e.target.value },
                          })
                        }
                        className={inputClass}
                      />
                    </div>
                    <div>
                      <label className="mb-1 block text-xs font-semibold text-muted-foreground">Màu header</label>
                      <div className="flex items-center gap-2">
                        <input
                          type="color"
                          value={template.header_color}
                          onChange={(e) =>
                            setEmailTemplates({
                              ...emailTemplates,
                              [templateKey]: { ...template, header_color: e.target.value },
                            })
                          }
                          className="h-9 w-9 cursor-pointer rounded border-0"
                        />
                        <input
                          value={template.header_color}
                          onChange={(e) =>
                            setEmailTemplates({
                              ...emailTemplates,
                              [templateKey]: { ...template, header_color: e.target.value },
                            })
                          }
                          className={inputClass + " flex-1"}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

export default InterfaceSettings;
