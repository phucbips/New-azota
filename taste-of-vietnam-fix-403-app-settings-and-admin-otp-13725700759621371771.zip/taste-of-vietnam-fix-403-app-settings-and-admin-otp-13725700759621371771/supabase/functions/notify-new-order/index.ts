import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { getRequiredEnv, corsHeaders } from "../_shared/utils.ts";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { orderCode, customerName, phone, address, total, items, paymentMethod } = await req.json();

    const supabase = createClient(
      getRequiredEnv("SUPABASE_URL"),
      getRequiredEnv("SUPABASE_SERVICE_ROLE_KEY")
    );

    // Get admin emails from app_settings first, fallback to env secret
    const { data: emailSetting } = await supabase
      .from("app_settings")
      .select("value")
      .eq("key", "ADMIN_NOTIFICATION_EMAIL")
      .maybeSingle();

    const rawEmails = emailSetting?.value || getRequiredEnv("ADMIN_NOTIFICATION_EMAIL") || "";
    const adminEmails = rawEmails.split(",").map((e: string) => e.trim()).filter((e: string) => e.length > 0);
    if (adminEmails.length === 0) {
      console.log("No admin email configured, skipping notification");
      return new Response(
        JSON.stringify({ success: false, message: "No admin email configured" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Get Resend API key from app_settings first, fallback to env secret
    const { data: resendSetting } = await supabase
      .from("app_settings")
      .select("value")
      .eq("key", "RESEND_API_KEY")
      .maybeSingle();

    const resendApiKey = resendSetting?.value || getRequiredEnv("RESEND_API_KEY");
    if (!resendApiKey) {
      console.log("No RESEND_API_KEY configured, skipping email");
      return new Response(
        JSON.stringify({ success: false, message: "No Resend API key configured" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const itemsList = items?.map((i: any) => `<li>${i.cookie_name} × ${i.quantity} — ${new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND" }).format(i.total_price || i.unit_price * i.quantity)}</li>`).join("") || "<li>N/A</li>";

    const totalFormatted = new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND" }).format(total);
    const paymentLabel = paymentMethod === "bank_transfer" ? "Chuyển khoản" : "Tiền mặt";

    const htmlBody = `
<div style="font-family: 'Segoe UI', Arial, sans-serif; max-width: 500px; margin: 0 auto; padding: 24px; background: #fefcf6; border-radius: 16px; border: 1px solid #e8e0d4;">
  <div style="text-align: center; margin-bottom: 20px;">
    <h1 style="color: #2d5a27; font-size: 22px; margin: 0;">🍪 Đơn hàng mới!</h1>
    <p style="color: #8b7355; font-size: 13px; margin-top: 4px;">Nova Cookie</p>
  </div>
  <table style="width: 100%; border-collapse: collapse; font-size: 14px;">
    <tr><td style="padding: 8px 0; color: #8b7355;">Mã đơn</td><td style="padding: 8px 0; font-weight: bold; text-align: right;">${orderCode}</td></tr>
    <tr><td style="padding: 8px 0; color: #8b7355;">Khách hàng</td><td style="padding: 8px 0; text-align: right;">${customerName}</td></tr>
    <tr><td style="padding: 8px 0; color: #8b7355;">SĐT</td><td style="padding: 8px 0; text-align: right;">${phone}</td></tr>
    <tr><td style="padding: 8px 0; color: #8b7355;">Địa chỉ</td><td style="padding: 8px 0; text-align: right; max-width: 200px; word-break: break-word;">${address}</td></tr>
    <tr><td style="padding: 8px 0; color: #8b7355;">Thanh toán</td><td style="padding: 8px 0; text-align: right;">${paymentLabel}</td></tr>
  </table>
  <hr style="border: none; border-top: 1px solid #e8e0d4; margin: 16px 0;" />
  <h3 style="color: #2d5a27; font-size: 14px; margin-bottom: 8px;">Sản phẩm:</h3>
  <ul style="padding-left: 20px; color: #333; font-size: 14px; line-height: 1.8;">${itemsList}</ul>
  <hr style="border: none; border-top: 1px solid #e8e0d4; margin: 16px 0;" />
  <div style="text-align: right; font-size: 18px; font-weight: bold; color: #2d5a27;">
    Tổng: ${totalFormatted}
  </div>
</div>`;

    // Send email via Resend
    const resendRes = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${resendApiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: "Nova Cookie <onboarding@resend.dev>",
        to: adminEmails,
        subject: `🍪 Đơn hàng mới ${orderCode} - Nova Cookie`,
        html: htmlBody,
      }),
    });

    const resendData = await resendRes.json();

    if (!resendRes.ok) {
      console.error("Resend error:", resendData);
      return new Response(
        JSON.stringify({ success: false, error: resendData }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log(`📧 Email sent to ${adminEmails.join(", ")}, id: ${resendData.id}`);

    return new Response(
      JSON.stringify({ success: true, message: "Email sent", emailId: resendData.id }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Notification error:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
