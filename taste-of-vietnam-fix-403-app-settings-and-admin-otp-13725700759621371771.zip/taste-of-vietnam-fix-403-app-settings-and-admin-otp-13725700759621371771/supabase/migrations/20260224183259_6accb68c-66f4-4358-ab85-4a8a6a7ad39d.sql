-- Allow anyone to read specific public settings (SHIPPING_ZONE_CONFIG, SOCIAL_LINKS)
CREATE POLICY "Anyone can read public settings"
ON public.app_settings
FOR SELECT
USING (key IN ('SHIPPING_ZONE_CONFIG', 'SOCIAL_LINKS'));