-- FIX PERMISSIONS: Run this to grant yourself ADMIN access

-- 1. Replace 'YOUR_EMAIL@EXAMPLE.COM' with your actual login email address
-- 2. Run this script in the Supabase SQL Editor

DO $$
DECLARE
  target_email TEXT := 'thanhphucn4u@gmail.com'; -- Email của bạn
  target_user_id UUID;
BEGIN
  -- Find the user ID from auth.users
  SELECT id INTO target_user_id FROM auth.users WHERE email = target_email;

  IF target_user_id IS NOT NULL THEN
    -- Insert admin role if it doesn't exist
    INSERT INTO public.user_roles (user_id, role)
    VALUES (target_user_id, 'admin')
    ON CONFLICT (user_id, role) DO NOTHING;

    RAISE NOTICE 'Admin role granted to % (ID: %)', target_email, target_user_id;
  ELSE
    RAISE WARNING 'User with email % not found in auth.users. Please sign up first.', target_email;
  END IF;
END $$;

-- 3. Verify Policies (Just in case)
-- Ensure admin policies exist and are correct
BEGIN;
  -- Re-apply critical admin policies
  DROP POLICY IF EXISTS "Admins can manage order_surcharges" ON order_surcharges;
  CREATE POLICY "Admins can manage order_surcharges"
  ON order_surcharges
  FOR ALL
  USING ( public.has_role(auth.uid(), 'admin') )
  WITH CHECK ( public.has_role(auth.uid(), 'admin') );

  DROP POLICY IF EXISTS "Admins can manage financial_transactions" ON financial_transactions;
  CREATE POLICY "Admins can manage financial_transactions"
  ON financial_transactions
  FOR ALL
  USING ( public.has_role(auth.uid(), 'admin') )
  WITH CHECK ( public.has_role(auth.uid(), 'admin') );
COMMIT;
