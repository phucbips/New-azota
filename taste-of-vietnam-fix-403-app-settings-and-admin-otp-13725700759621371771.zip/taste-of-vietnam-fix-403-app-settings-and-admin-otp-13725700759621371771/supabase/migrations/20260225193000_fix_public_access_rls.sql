-- Force RLS policies to allow public read access for critical tables
-- This fixes the 403 Forbidden error on monthly_menu even when API key is correct

-- 1. Monthly Menu
DROP POLICY IF EXISTS "Anyone can view menu" ON public.monthly_menu;
CREATE POLICY "Anyone can view menu"
ON public.monthly_menu FOR SELECT
TO public
USING (true);

-- 2. App Settings (Fixes "No API key" misleading error if settings fetch fails)
DROP POLICY IF EXISTS "Anyone can read settings" ON public.app_settings;
CREATE POLICY "Anyone can read settings"
ON public.app_settings FOR SELECT
TO public
USING (true);

-- 3. Grant explicit permissions to anon role (Just to be safe)
GRANT SELECT ON public.monthly_menu TO anon;
GRANT SELECT ON public.app_settings TO anon;
GRANT SELECT ON public.order_surcharges TO anon;
GRANT SELECT ON public.voucher_templates TO anon;

-- Force reload schema cache
NOTIFY pgrst, 'reload config';
