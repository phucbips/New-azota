# Biến môi trường Vercel (Environment Variables)

Khi triển khai ứng dụng này lên Vercel, bạn cần cấu hình các biến môi trường sau trong phần **Settings > Environment Variables** của dự án:

## Supabase
*   `VITE_SUPABASE_PROJECT_ID`: ID dự án Supabase.
*   `VITE_SUPABASE_PUBLISHABLE_KEY`: Key publishable của Supabase.
*   `VITE_SUPABASE_URL`: URL của Supabase.

## PayOS (Thanh toán)
*   `PAYOS_CLIENT_ID`: Client ID của PayOS.
*   `PAYOS_API_KEY`: API Key của PayOS.
*   `PAYOS_CHECKSUM_KEY`: Checksum Key của PayOS.

## Cloudinary (Lưu trữ ảnh)
*   `CLOUDINARY_CLOUD_NAME`: Tên cloud của Cloudinary.
*   `CLOUDINARY_API_KEY`: API Key của Cloudinary.
*   `CLOUDINARY_API_SECRET`: API Secret của Cloudinary.

## Email (Resend)
*   `RESEND_API_KEY`: API Key của Resend (nếu dùng email notification).
*   `ADMIN_NOTIFICATION_EMAIL`: Email nhận thông báo admin.

---

# Cấu hình sau khi Deploy (Quan trọng)

Sau khi ứng dụng đã được deploy lên Vercel (ví dụ có domain `https://nova-cookie.vercel.app`), bạn **BẮT BUỘC** phải thực hiện các bước sau để chức năng đăng nhập Google hoạt động:

## 1. Cấu hình Supabase Auth Redirect

1.  Truy cập **Supabase Dashboard** > **Authentication** > **URL Configuration**.
2.  Tại mục **Site URL**, nhập URL của ứng dụng Vercel (ví dụ: `https://nova-cookie.vercel.app`).
3.  Tại mục **Redirect URLs**, thêm các URL sau:
    *   `https://nova-cookie.vercel.app`
    *   `https://nova-cookie.vercel.app/`
    *   `https://nova-cookie.vercel.app/**`

**Lưu ý:** Nếu bạn không thêm đúng Redirect URL, chức năng đăng nhập Google sẽ báo lỗi "Redirect URL mismatch".

## 2. Deploy Edge Functions (Nếu cần)

Các chức năng backend (gửi mail, upload ảnh, thanh toán) chạy trên Supabase Edge Functions. Bạn cần deploy chúng từ máy local (nếu chưa deploy):

```bash
npx supabase functions deploy
```
Hoặc cấu hình GitHub Action để tự động deploy functions.

---

# Cấu hình Vercel Rewrite (OAuth)

Ứng dụng sử dụng Lovable Auth, mặc định gọi đến endpoint `/~oauth/initiate`.
File `vercel.json` đã được cấu hình để rewrite request này đến server xác thực của Lovable:

```json
{
  "source": "/~oauth/(.*)",
  "destination": "https://oauth.lovable.app/api/oauth/$1"
}
```

Nếu vẫn gặp lỗi 404 khi đăng nhập Google, hãy thử thay đổi destination thành `https://oauth.lovable.app/oauth/$1` (bỏ `/api`).
