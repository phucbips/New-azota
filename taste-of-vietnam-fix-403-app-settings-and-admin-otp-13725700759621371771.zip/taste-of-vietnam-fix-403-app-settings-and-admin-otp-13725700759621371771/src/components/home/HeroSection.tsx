import { useState, useEffect, useCallback } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import useEmblaCarousel from "embla-carousel-react";
import { Star, TrendingUp, ShoppingBag } from "lucide-react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import heroCookieDefault from "@/assets/hero-cookie.jpg";
import logoNova from "@/assets/logo-nova.jpg";
import { CornerVine, FloatingLeaf, DetailedLotus, BananaLeaf } from "@/components/decorations/VietnameseMotifs";
import { supabase } from "@/integrations/supabase/client";
import { formatPrice } from "@/data/mockMenu";

interface TopCookie {
  cookie_name: string;
  total_sold: number;
  avg_rating: number;
  image_url?: string | null;
  price?: number;
}

interface HeroConfig {
  type: "image" | "video";
  media_url: string;
  title: string;
  subtitle: string;
  cta_text: string;
  cta_link: string;
}

const DEFAULT_HERO: HeroConfig = {
  type: "image",
  media_url: "",
  title: "Nova Cookie",
  subtitle: "34 vị · 1 trái tim xanh",
  cta_text: "Đặt hàng ngay",
  cta_link: "/order",
};

const HeroSection = () => {
  const [emblaRef, emblaApi] = useEmblaCarousel({ loop: true });
  const [selectedIndex, setSelectedIndex] = useState(0);
  const queryClient = useQueryClient();

  useEffect(() => {
    queryClient.invalidateQueries({ queryKey: ["top-cookies-hero"] });
  }, [queryClient]);

  const { data: heroConfig = DEFAULT_HERO } = useQuery({
    queryKey: ["hero-config"],
    queryFn: async () => {
      const { data } = await supabase
        .from("app_settings")
        .select("value")
        .eq("key", "HERO_CONFIG")
        .maybeSingle();
      if (data) {
        try {
          return { ...DEFAULT_HERO, ...JSON.parse(data.value) };
        } catch {}
      }
      return DEFAULT_HERO;
    },
    staleTime: 60_000,
  });

  const { data: topCookies = [] } = useQuery({
    queryKey: ["top-cookies-hero"],
    queryFn: async () => {
      const { data, error } = await supabase.rpc("get_top_cookies", { p_limit: 3 });
      if (error || !data || data.length === 0) return [];
      const { data: menuData } = await supabase
        .from("monthly_menu")
        .select("cookie_name, image_url, price")
        .eq("is_active", true);
      return data.map((c: any) => {
        const menu = menuData?.find((m: any) => m.cookie_name === c.cookie_name);
        return { ...c, image_url: menu?.image_url, price: menu?.price };
      });
    },
  });

  useEffect(() => {
    if (!emblaApi) return;
    const interval = setInterval(() => emblaApi.scrollNext(), 7000);
    return () => clearInterval(interval);
  }, [emblaApi]);

  const onSelect = useCallback(() => {
    if (!emblaApi) return;
    setSelectedIndex(emblaApi.selectedScrollSnap());
  }, [emblaApi]);

  useEffect(() => {
    if (!emblaApi) return;
    onSelect();
    emblaApi.on("select", onSelect);
    return () => { emblaApi.off("select", onSelect); };
  }, [emblaApi, onSelect]);

  const slideCount = topCookies.length > 0 ? 2 : 1;
  const heroMediaUrl = heroConfig.media_url || heroCookieDefault;
  const isVideo = heroConfig.type === "video" && heroConfig.media_url;

  return (
    <section className="relative">
      <div ref={emblaRef} className="overflow-hidden">
        <div className="flex">
          {/* Slide 1: Hero */}
          <div className="relative min-h-[85vh] w-full flex-[0_0_100%] overflow-hidden bg-foreground md:min-h-screen">
            <div className="absolute inset-0">
              {isVideo ? (
                <video
                  src={heroConfig.media_url}
                  className="h-full w-full object-cover"
                  autoPlay
                  muted
                  loop
                  playsInline
                />
              ) : (
                <img src={heroMediaUrl} alt="Nova Cookie hero" className="h-full w-full object-cover" />
              )}
              <div className="absolute inset-0 bg-gradient-to-t from-foreground/80 via-foreground/40 to-foreground/10" />
              <div className="absolute inset-0 bg-gradient-to-br from-[hsl(var(--secondary)/0.1)] via-transparent to-[hsl(var(--primary)/0.08)]" />
            </div>

            <FloatingLeaf className="absolute left-[5%] top-[15%] h-16 w-10 opacity-40" delay={0} />
            <FloatingLeaf className="absolute right-[8%] top-[25%] h-12 w-8 opacity-30" delay={1.5} />
            <FloatingLeaf className="absolute left-[80%] top-[60%] h-14 w-9 opacity-25" delay={3} />
            <CornerVine className="absolute left-0 top-0 h-32 w-32 opacity-30 md:h-48 md:w-48" position="top-left" />
            <CornerVine className="absolute bottom-0 right-0 h-32 w-32 opacity-25 md:h-48 md:w-48" position="bottom-right" />
            <BananaLeaf className="absolute -left-4 top-[20%] hidden h-48 w-24 opacity-20 md:block" />
            <BananaLeaf className="absolute -right-4 top-[30%] hidden h-48 w-24 opacity-15 md:block" flip />
            <DetailedLotus className="absolute bottom-[15%] left-[8%] hidden h-16 w-20 opacity-20 md:block" size="sm" />
            <DetailedLotus className="absolute right-[5%] top-[12%] hidden h-20 w-24 opacity-15 md:block" size="md" />

            <div className="relative flex min-h-[85vh] flex-col items-center justify-between py-16 text-center md:min-h-screen md:py-24">
              <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8 }}
                className="flex flex-col items-center gap-4"
              >
                <img src={logoNova} alt="Nova Cookie" className="h-20 w-20 rounded-full object-cover shadow-2xl ring-4 ring-[hsl(var(--background)/0.3)] md:h-28 md:w-28" />
                <h1 className="font-display text-4xl font-extrabold leading-none text-[hsl(var(--background))] md:text-6xl lg:text-7xl">
                  {heroConfig.title}
                </h1>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 40 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.2 }}
                className="px-4"
              >
                <p className="mb-8 text-lg font-medium text-[hsl(var(--background)/0.8)] md:text-xl">
                  {heroConfig.subtitle}
                </p>
                <Link
                  to={heroConfig.cta_link}
                  className="inline-block rounded-full bg-[hsl(var(--background))] px-10 py-4 text-base font-bold text-foreground shadow-2xl transition-transform hover:scale-105"
                >
                  {heroConfig.cta_text}
                </Link>
              </motion.div>
            </div>
          </div>

          {/* Slide 2: Trending Cookies */}
          {topCookies.length > 0 && (
            <div className="relative min-h-[85vh] w-full flex-[0_0_100%] overflow-hidden bg-foreground md:min-h-screen">
              <div className="absolute inset-0 bg-gradient-to-br from-foreground via-foreground/95 to-foreground/90" />
              <CornerVine className="absolute left-0 top-0 h-32 w-32 opacity-20 md:h-48 md:w-48" position="top-left" />
              <CornerVine className="absolute bottom-0 right-0 h-32 w-32 opacity-15 md:h-48 md:w-48" position="bottom-right" />

              <div className="relative flex min-h-[85vh] flex-col items-center justify-center px-4 py-16 md:min-h-screen md:py-24">
                <motion.div
                  initial={{ opacity: 0, y: -20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mb-10 text-center"
                >
                  <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-primary/20">
                    <TrendingUp className="h-7 w-7 text-primary" />
                  </div>
                  <h2 className="font-display text-3xl font-extrabold text-[hsl(var(--background))] md:text-5xl">
                    Thịnh hành
                  </h2>
                  <p className="mt-2 text-[hsl(var(--background)/0.6)]">Được yêu thích nhất hiện tại</p>
                </motion.div>

                <div className="grid w-full max-w-3xl grid-cols-1 gap-5 sm:grid-cols-3 sm:gap-6">
                  {topCookies.slice(0, 3).map((cookie, i) => {
                    const medals = ["🥇", "🥈", "🥉"];
                    const scales = i === 0 ? "sm:scale-105 sm:-translate-y-2" : "";
                    return (
                      <motion.div
                        key={cookie.cookie_name}
                        initial={{ opacity: 0, y: 30 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: i * 0.15 }}
                        className={`group relative overflow-hidden rounded-2xl border border-[hsl(var(--background)/0.1)] bg-[hsl(var(--background)/0.06)] backdrop-blur-sm transition-transform ${scales}`}
                      >
                        <div className="aspect-[4/3] overflow-hidden">
                          {cookie.image_url ? (
                            <img
                              src={cookie.image_url}
                              alt={cookie.cookie_name}
                              className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
                            />
                          ) : (
                            <div className="flex h-full w-full items-center justify-center bg-muted/20 text-5xl">🍪</div>
                          )}
                        </div>
                        <div className="p-4 text-center">
                          <p className="text-sm font-bold text-[hsl(var(--background))] truncate">{cookie.cookie_name}</p>
                          <div className="mt-2 flex items-center justify-center gap-3">
                            <div className="flex items-center gap-1">
                              <ShoppingBag className="h-3.5 w-3.5 text-primary" />
                              <span className="text-xs text-[hsl(var(--background)/0.7)]">{cookie.total_sold} đã bán</span>
                            </div>
                            {cookie.avg_rating > 0 && (
                              <div className="flex items-center gap-1">
                                <Star className="h-3.5 w-3.5 fill-secondary text-secondary" />
                                <span className="text-xs text-[hsl(var(--background)/0.7)]">{Number(cookie.avg_rating).toFixed(1)}</span>
                              </div>
                            )}
                          </div>
                          {cookie.price && (
                            <p className="mt-2 text-sm font-semibold text-primary">{formatPrice(cookie.price)}</p>
                          )}
                        </div>
                        <div className="absolute left-2 top-2 text-xl">{medals[i]}</div>
                      </motion.div>
                    );
                  })}
                </div>

                <Link
                  to="/order"
                  className="mt-10 inline-block rounded-full bg-[hsl(var(--background))] px-10 py-4 text-base font-bold text-foreground shadow-2xl transition-transform hover:scale-105"
                >
                  Đặt hàng ngay
                </Link>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Dot indicators */}
      {slideCount > 1 && (
        <div className="absolute bottom-6 left-1/2 z-10 flex -translate-x-1/2 gap-2">
          {Array.from({ length: slideCount }).map((_, i) => (
            <button
              key={i}
              onClick={() => emblaApi?.scrollTo(i)}
              className={`h-2 rounded-full transition-all ${
                i === selectedIndex ? "w-6 bg-[hsl(var(--background))]" : "w-2 bg-[hsl(var(--background)/0.4)]"
              }`}
            />
          ))}
        </div>
      )}
    </section>
  );
};

export default HeroSection;
