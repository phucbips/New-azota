import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Package, Clock, Truck, CheckCircle2, ChefHat, Loader2, ChevronDown, CreditCard, Banknote, XCircle } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { formatPrice } from "@/data/mockMenu";

interface OrderItem {
  id: string;
  cookie_name: string;
  quantity: number;
  unit_price: number;
  total_price: number;
}

interface OrderWithItems {
  id: string;
  order_code: string;
  created_at: string;
  status: string;
  total: number;
  subtotal: number;
  shipping_fee: number;
  green_fund_amount: number;
  customer_name: string;
  phone: string;
  address: string;
  payment_method: string;
  payment_status: string;
  payment_deadline: string | null;
  notes: string | null;
}

const STATUS_MAP: Record<string, { label: string; icon: React.ElementType; color: string }> = {
  pending: { label: "Chờ xác nhận", icon: Clock, color: "text-yellow-600" },
  preparing: { label: "Đang chuẩn bị", icon: ChefHat, color: "text-orange-500" },
  delivering: { label: "Đang giao", icon: Truck, color: "text-blue-500" },
  delivered: { label: "Đã giao", icon: CheckCircle2, color: "text-primary" },
  cancelled: { label: "Đã hủy", icon: XCircle, color: "text-destructive" },
};

const PAYMENT_STATUS_MAP: Record<string, { label: string; color: string }> = {
  pending: { label: "Chưa thanh toán", color: "text-yellow-600 bg-yellow-50" },
  paid: { label: "Đã thanh toán", color: "text-primary bg-primary/10" },
  expired: { label: "Hết hạn", color: "text-destructive bg-destructive/10" },
};

const OrderHistory = () => {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [orders, setOrders] = useState<OrderWithItems[]>([]);
  const [loading, setLoading] = useState(true);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [orderItems, setOrderItems] = useState<Record<string, OrderItem[]>>({});
  const [loadingItems, setLoadingItems] = useState<string | null>(null);

  useEffect(() => {
    if (!authLoading && !user) {
      navigate("/auth");
    }
  }, [user, authLoading, navigate]);

  useEffect(() => {
    if (!user) return;
    const fetchOrders = async () => {
      const { data, error } = await supabase
        .from("orders")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false });

      if (!error && data) setOrders(data as any);
      setLoading(false);
    };
    fetchOrders();
  }, [user]);

  const toggleExpand = async (orderId: string) => {
    if (expandedId === orderId) {
      setExpandedId(null);
      return;
    }
    setExpandedId(orderId);
    if (!orderItems[orderId]) {
      setLoadingItems(orderId);
      const { data } = await supabase
        .from("order_items")
        .select("*")
        .eq("order_id", orderId);
      if (data) setOrderItems((prev) => ({ ...prev, [orderId]: data }));
      setLoadingItems(null);
    }
  };

  if (authLoading || loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="container mx-auto px-4 pt-24 pb-16">
        <div className="mb-8 text-center">
          <h1 className="font-display text-3xl font-extrabold text-foreground md:text-4xl">
            Lịch sử đơn hàng
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Theo dõi trạng thái các đơn hàng của bạn
          </p>
        </div>

        {orders.length === 0 ? (
          <div className="mx-auto max-w-md rounded-2xl border border-border bg-card p-10 text-center">
            <Package className="mx-auto mb-4 h-12 w-12 text-muted-foreground/50" />
            <p className="text-muted-foreground">Bạn chưa có đơn hàng nào</p>
            <Link
              to="/order"
              className="mt-4 inline-block rounded-full bg-primary px-6 py-2.5 text-sm font-bold text-primary-foreground hover:scale-105 transition-transform"
            >
              Đặt hàng ngay
            </Link>
          </div>
        ) : (
          <div className="mx-auto max-w-2xl space-y-4">
            {orders.map((order, i) => {
              const status = STATUS_MAP[order.status] || STATUS_MAP.pending;
              const StatusIcon = status.icon;
              const isExpanded = expandedId === order.id;
              const paymentStatus = PAYMENT_STATUS_MAP[order.payment_status] || PAYMENT_STATUS_MAP.pending;
              const items = orderItems[order.id];

              return (
                <motion.div
                  key={order.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.05 }}
                  className="rounded-2xl border border-border bg-card overflow-hidden"
                >
                  {/* Header - clickable */}
                  <button
                    onClick={() => toggleExpand(order.id)}
                    className="w-full p-5 text-left hover:bg-muted/30 transition-colors"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-sm font-bold text-foreground">{order.order_code}</span>
                        <span className={`flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-semibold ${status.color} bg-muted`}>
                          <StatusIcon className="h-3 w-3" />
                          {status.label}
                        </span>
                      </div>
                      <ChevronDown className={`h-4 w-4 text-muted-foreground transition-transform ${isExpanded ? "rotate-180" : ""}`} />
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">
                        {new Date(order.created_at).toLocaleDateString("vi-VN", {
                          day: "2-digit", month: "2-digit", year: "numeric",
                          hour: "2-digit", minute: "2-digit",
                        })}
                      </span>
                      <span className="font-bold text-primary">{formatPrice(order.total)}</span>
                    </div>
                  </button>

                  {/* Expanded detail */}
                  <AnimatePresence>
                    {isExpanded && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="border-t border-border"
                      >
                        <div className="p-5 space-y-4">
                          {/* Payment info */}
                          <div className="flex flex-wrap gap-2">
                            <span className={`flex items-center gap-1 rounded-full px-3 py-1 text-xs font-semibold ${paymentStatus.color}`}>
                              {order.payment_method === "bank_transfer" ? (
                                <CreditCard className="h-3 w-3" />
                              ) : (
                                <Banknote className="h-3 w-3" />
                              )}
                              {order.payment_method === "bank_transfer" ? "Chuyển khoản" : "Tiền mặt"}
                            </span>
                            <span className={`rounded-full px-3 py-1 text-xs font-semibold ${paymentStatus.color}`}>
                              {paymentStatus.label}
                            </span>
                          </div>

                          {/* Customer info */}
                          <div className="space-y-1 text-sm">
                            <p className="text-foreground font-medium">{order.customer_name} · {order.phone}</p>
                            <p className="text-muted-foreground">{order.address}</p>
                            {order.notes && (
                              <p className="text-muted-foreground">📝 {order.notes}</p>
                            )}
                          </div>

                          {/* Items */}
                          {loadingItems === order.id ? (
                            <div className="flex justify-center py-4">
                              <Loader2 className="h-5 w-5 animate-spin text-primary" />
                            </div>
                          ) : items ? (
                            <div className="space-y-2">
                              <p className="text-xs font-semibold text-muted-foreground uppercase">Chi tiết đơn hàng</p>
                              {items.map((item) => (
                                <div key={item.id} className="flex justify-between text-sm">
                                  <span className="text-foreground">{item.cookie_name} × {item.quantity}</span>
                                  <span className="text-foreground font-medium">{formatPrice(item.total_price)}</span>
                                </div>
                              ))}
                              <div className="border-t border-border pt-2 mt-2 space-y-1 text-sm">
                                <div className="flex justify-between">
                                  <span className="text-muted-foreground">Tạm tính</span>
                                  <span className="text-foreground">{formatPrice(order.subtotal)}</span>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-muted-foreground">Phí ship</span>
                                  <span className="text-foreground">{order.shipping_fee === 0 ? "Miễn phí" : formatPrice(order.shipping_fee)}</span>
                                </div>
                                <div className="flex justify-between text-xs text-primary">
                                  <span>🌱 Quỹ trồng cây</span>
                                  <span>{formatPrice(order.green_fund_amount)}</span>
                                </div>
                                <div className="flex justify-between font-bold text-base pt-1">
                                  <span className="text-foreground">Tổng</span>
                                  <span className="text-primary">{formatPrice(order.total)}</span>
                                </div>
                              </div>
                            </div>
                          ) : null}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
              );
            })}
          </div>
        )}
      </main>
      <Footer />
    </div>
  );
};

export default OrderHistory;
