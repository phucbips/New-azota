import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { supabase } from "@/integrations/supabase/client";
import logoNova from "@/assets/logo-nova.jpg";

interface LoadingScreenProps {
  onLoaded: () => void;
}

const LoadingScreen = ({ onLoaded }: LoadingScreenProps) => {
  const [progress, setProgress] = useState(0);
  const [done, setDone] = useState(false);

  useEffect(() => {
    const preloadAll = async () => {
      // Static assets
      const staticImages = [
        "/assets/cookie-cacao.jpg",
        "/assets/cookie-com.jpg",
        "/assets/cookie-dua.jpg",
        "/assets/cookie-matcha.jpg",
        "/assets/cookie-que.jpg",
      ];

      const moduleImages = import.meta.glob("/src/assets/*.jpg", { eager: true, query: "?url", import: "default" }) as Record<string, string>;

      // Fetch menu images from DB
      const { data: menuItems } = await supabase
        .from("monthly_menu")
        .select("image_url")
        .eq("is_active", true);

      const menuUrls = (menuItems || [])
        .map((item) => item.image_url)
        .filter(Boolean) as string[];

      const allSources = [...staticImages, ...Object.values(moduleImages), ...menuUrls];
      const total = allSources.length;

      if (total === 0) {
        setProgress(100);
        setDone(true);
        return;
      }

      let loaded = 0;
      allSources.forEach((src) => {
        const img = new Image();
        img.onload = img.onerror = () => {
          loaded++;
          setProgress(Math.round((loaded / total) * 100));
          if (loaded >= total) setTimeout(() => setDone(true), 400);
        };
        img.src = src;
      });
    };

    preloadAll();

    const timeout = setTimeout(() => setDone(true), 8000);
    return () => clearTimeout(timeout);
  }, []);

  useEffect(() => {
    if (done) {
      const timer = setTimeout(onLoaded, 600);
      return () => clearTimeout(timer);
    }
  }, [done, onLoaded]);

  const petalCount = 8;
  const petals = Array.from({ length: petalCount }, (_, i) => ({
    rotate: (360 / petalCount) * i,
    delay: i * 0.08,
  }));

  return (
    <AnimatePresence>
      {!done && (
        <motion.div
          key="loading"
          initial={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5 }}
          className="fixed inset-0 z-[9999] flex flex-col items-center justify-center gap-6 bg-[hsl(var(--background))]"
        >
          <div className="relative flex items-center justify-center">
            {petals.map((petal, i) => (
              <motion.div
                key={i}
                className="absolute"
                initial={{ opacity: 0, scale: 0.3 }}
                animate={{ opacity: [0, 0.25, 0.15], scale: [0.3, 1, 0.9] }}
                transition={{ duration: 1.5, delay: petal.delay, repeat: Infinity, repeatDelay: 1 }}
                style={{ transform: `rotate(${petal.rotate}deg) translateY(-52px)` }}
              >
                <svg width="20" height="32" viewBox="0 0 20 32" fill="none">
                  <ellipse cx="10" cy="16" rx="8" ry="15" fill="hsl(var(--nova-lotus))" fillOpacity="0.3" />
                </svg>
              </motion.div>
            ))}

            {[0, 1, 2].map((i) => (
              <motion.div
                key={`leaf-${i}`}
                className="absolute"
                initial={{ opacity: 0, y: 0 }}
                animate={{
                  opacity: [0, 0.3, 0],
                  y: [-20, -60],
                  x: [0, (i - 1) * 30],
                  rotate: [0, (i - 1) * 20],
                }}
                transition={{ duration: 2.5, delay: i * 0.5, repeat: Infinity, repeatDelay: 0.5 }}
              >
                <svg width="16" height="24" viewBox="0 0 16 24" fill="none">
                  <path d="M8 2 Q14 8, 12 16 Q10 22, 8 22 Q6 22, 4 16 Q2 8, 8 2Z" fill="hsl(var(--primary))" fillOpacity="0.25" />
                </svg>
              </motion.div>
            ))}

            <motion.img
              src={logoNova}
              alt="Nova Cookie"
              className="h-28 w-28 rounded-full object-cover shadow-lg ring-4 ring-primary/20"
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.5 }}
            />
          </div>

          <div className="flex flex-col items-center gap-2">
            <div className="h-1 w-48 overflow-hidden rounded-full bg-muted">
              <motion.div
                className="h-full rounded-full bg-primary"
                initial={{ width: 0 }}
                animate={{ width: `${progress}%` }}
                transition={{ duration: 0.3 }}
              />
            </div>
            <p className="text-xs text-muted-foreground">{progress}%</p>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default LoadingScreen;
