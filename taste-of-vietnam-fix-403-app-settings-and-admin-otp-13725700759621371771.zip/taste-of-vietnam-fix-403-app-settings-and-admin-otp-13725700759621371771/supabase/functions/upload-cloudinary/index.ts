import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { getRequiredEnv, corsHeaders } from "../_shared/utils.ts";

const DEFAULT_CLOUD_NAME = "dkkvom3um";

async function getCloudinaryConfig() {
  const { createClient } = await import("https://esm.sh/@supabase/supabase-js@2");
  const serviceClient = createClient(
    getRequiredEnv("SUPABASE_URL"),
    getRequiredEnv("SUPABASE_SERVICE_ROLE_KEY")
  );
  const { data } = await serviceClient
    .from("app_settings")
    .select("key, value")
    .in("key", ["CLOUDINARY_CLOUD_NAME", "CLOUDINARY_API_KEY", "CLOUDINARY_API_SECRET"]);

  const map: Record<string, string> = {};
  data?.forEach((s: any) => (map[s.key] = s.value?.trim()));

  return {
    cloudName: (map["CLOUDINARY_CLOUD_NAME"] || DEFAULT_CLOUD_NAME).trim(),
    apiKey: (map["CLOUDINARY_API_KEY"] || getRequiredEnv("CLOUDINARY_API_KEY") || "").trim(),
    apiSecret: (map["CLOUDINARY_API_SECRET"] || getRequiredEnv("CLOUDINARY_API_SECRET") || "").trim(),
  };
}

async function sha1Hex(message: string): Promise<string> {
  const msgBuffer = new TextEncoder().encode(message);
  const hashBuffer = await crypto.subtle.digest("SHA-1", msgBuffer);
  return Array.from(new Uint8Array(hashBuffer))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { cloudName, apiKey, apiSecret } = await getCloudinaryConfig();

    const CLOUDINARY_API_KEY = apiKey;
    const CLOUDINARY_API_SECRET = apiSecret;

    if (!CLOUDINARY_API_KEY || !CLOUDINARY_API_SECRET) {
      return new Response(
        JSON.stringify({ error: "Cloudinary credentials not configured" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const formData = await req.formData();
    const file = formData.get("file") as File;

    if (!file) {
      return new Response(
        JSON.stringify({ error: "No file provided" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const timestamp = Math.floor(Date.now() / 1000).toString();
    const folder = "nova-cookie";
    const transformation = "c_fill,w_800,h_800,q_auto,f_webp";

    // Create signature
    const paramsToSign = `folder=${folder}&timestamp=${timestamp}&transformation=${transformation}`;
    const signature = await sha1Hex(paramsToSign + CLOUDINARY_API_SECRET);

    // Upload to Cloudinary
    const uploadForm = new FormData();
    uploadForm.append("file", file);
    uploadForm.append("api_key", CLOUDINARY_API_KEY);
    uploadForm.append("timestamp", timestamp);
    uploadForm.append("signature", signature);
    uploadForm.append("folder", folder);
    uploadForm.append("transformation", transformation);

    const uploadRes = await fetch(
      `https://api.cloudinary.com/v1_1/${cloudName}/image/upload`,
      { method: "POST", body: uploadForm }
    );

    const result = await uploadRes.json();

    if (!uploadRes.ok) {
      console.error("Cloudinary error:", result);
      return new Response(
        JSON.stringify({ error: result.error?.message || "Upload failed" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    return new Response(
      JSON.stringify({ url: result.secure_url, public_id: result.public_id }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Upload error:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
