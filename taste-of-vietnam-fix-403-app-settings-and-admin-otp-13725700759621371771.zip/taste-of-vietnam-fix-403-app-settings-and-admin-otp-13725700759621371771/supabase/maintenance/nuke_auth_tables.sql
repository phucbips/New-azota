-- ==============================================================================
-- BƯỚC 1: ĐẢM BẢO QUYỀN ĐI VÀO SCHEMA (CỔNG NGOÀI CÙNG)
-- ==============================================================================
GRANT USAGE ON SCHEMA public TO anon, authenticated, service_role;

-- ==============================================================================
-- BƯỚC 2: CẤP QUYỀN CƠ BẢN LÊN CÁC BẢNG QUAN TRỌNG (GRANTS)
-- Bảng: verification_codes và profiles
-- ==============================================================================
-- Hủy toàn bộ quyền của public trên bảng verification_codes (chỉ service_role dùng)
REVOKE ALL ON public.verification_codes FROM anon, authenticated;
GRANT ALL ON public.verification_codes TO service_role;

-- Khách có thể đọc profiles (để hiển thị tên v.v.) và User tự sửa profile của mình
GRANT SELECT ON public.profiles TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.profiles TO authenticated, service_role;


-- ==============================================================================
-- BƯỚC 3: NUKE (XÓA SỔ TOÀN BỘ RLS CŨ ĐỂ TRÁNH XUNG ĐỘT)
-- ==============================================================================
DO $$
DECLARE
    pol RECORD;
BEGIN
    -- Nuke policy bảng verification_codes
    FOR pol IN
        SELECT policyname FROM pg_policies WHERE schemaname = 'public' AND tablename = 'verification_codes'
    LOOP
        EXECUTE format('DROP POLICY IF EXISTS %I ON public.verification_codes', pol.policyname);
    END LOOP;

    -- Nuke policy bảng profiles
    FOR pol IN
        SELECT policyname FROM pg_policies WHERE schemaname = 'public' AND tablename = 'profiles'
    LOOP
        EXECUTE format('DROP POLICY IF EXISTS %I ON public.profiles', pol.policyname);
    END LOOP;
END
$$;

-- ==============================================================================
-- BƯỚC 4: BẬT RLS VÀ TẠO POLICY MỚI RÕ RÀNG
-- ==============================================================================
ALTER TABLE public.verification_codes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- ------------------------------------------------------------------------------
-- A. Bảng verification_codes
-- Bảng này KHÔNG có policy cho public (anon/authenticated).
-- CHỈ Service Role (Edge Functions) có quyền thao tác CRUD.
CREATE POLICY "Service_Role_All_VerificationCodes"
ON public.verification_codes
FOR ALL
TO service_role
USING (true);

-- ------------------------------------------------------------------------------
-- B. Bảng profiles
-- Policy 1: Ai cũng đọc được profile (cần thiết để lấy tên khách, đánh giá)
CREATE POLICY "Public_Select_Profiles"
ON public.profiles
FOR SELECT
USING (true);

-- Policy 2: Người dùng tự tạo profile cho họ (Trigger tạo tự động, hoặc user tự insert)
CREATE POLICY "User_Insert_Own_Profile"
ON public.profiles
FOR INSERT
WITH CHECK (auth.uid() = user_id);

-- Policy 3: Người dùng tự sửa profile của họ
CREATE POLICY "User_Update_Own_Profile"
ON public.profiles
FOR UPDATE
USING (auth.uid() = user_id);

-- Policy 4: Admin có toàn quyền quản lý profile
CREATE POLICY "Admin_All_Profiles"
ON public.profiles
FOR ALL
TO authenticated
USING (public.has_role(auth.uid(), 'admin'::text));
