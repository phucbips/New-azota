import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { Menu, X, User, LogOut, Package, Shield, ChefHat, Home, ShoppingBag, Trophy } from "lucide-react";
import logoNova from "@/assets/logo-nova.jpg";
import { AnimatePresence, motion } from "framer-motion";
import { useAuth } from "@/hooks/useAuth";
import { useRole } from "@/hooks/useRole";
import type { Easing } from "framer-motion";

const menuItemVariants = {
  hidden: { opacity: 0, x: -20 },
  visible: (i: number) => ({
    opacity: 1,
    x: 0,
    transition: { delay: i * 0.05, duration: 0.3, ease: "easeOut" as Easing },
  }),
};

const Navbar = () => {
  const [open, setOpen] = useState(false);
  const location = useLocation();
  const { user, signOut } = useAuth();
  const { isAdmin, isBaker } = useRole();

  const navItems = [
    { label: "Trang chủ", path: "/", icon: Home },
    { label: "Đặt hàng", path: "/order", icon: ShoppingBag },
    { label: "Bảng xếp hạng", path: "/ranking", icon: Trophy },
  ];

  const accountItems = [
    ...(user ? [
      { label: "Hồ sơ", path: "/profile", icon: User },
      { label: "Đơn hàng của tôi", path: "/orders", icon: Package },
    ] : []),
    ...(isAdmin ? [{ label: "Admin Dashboard", path: "/admin", icon: Shield }] : []),
    ...(isAdmin ? [{ label: "Baker Dashboard", path: "/baker", icon: ChefHat }] : []),
    ...((isBaker && !isAdmin) ? [{ label: "Baker Dashboard", path: "/baker", icon: ChefHat }] : []),
  ];

  return (
    <header className="fixed left-0 right-0 top-0 z-50">
      <nav className="container mx-auto flex items-center px-4 py-4">
        <button
          onClick={() => setOpen(!open)}
          className="flex items-center gap-2 text-foreground transition-opacity hover:opacity-70"
          aria-label="Toggle menu"
        >
          {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          <span className="text-lg font-bold tracking-wide" style={{ fontFamily: "'Be Vietnam Pro', sans-serif" }}>
            Menu
          </span>
        </button>
      </nav>

      <AnimatePresence>
        {open && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="fixed inset-0 z-40 bg-foreground/50 backdrop-blur-sm"
              onClick={() => setOpen(false)}
            />
            <motion.div
              initial={{ x: "-100%" }}
              animate={{ x: 0 }}
              exit={{ x: "-100%" }}
              transition={{ type: "spring", damping: 28, stiffness: 280 }}
              className="fixed inset-y-0 left-0 z-50 w-80 bg-background p-8 shadow-2xl"
            >
              {/* Header */}
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                className="mb-10 flex items-center justify-between"
              >
                <div className="flex items-center gap-2.5">
                  <img src={logoNova} alt="Nova Cookie" className="h-9 w-9 rounded-full object-cover ring-2 ring-primary/20" />
                  <span className="font-display text-xl font-extrabold tracking-tight">Nova Cookie</span>
                </div>
                <button
                  onClick={() => setOpen(false)}
                  className="rounded-full p-1.5 transition-colors hover:bg-muted"
                  aria-label="Close menu"
                >
                  <X className="h-5 w-5 text-foreground" />
                </button>
              </motion.div>

              {/* Nav items */}
              <ul className="space-y-1">
                {navItems.map((item, i) => (
                  <motion.li
                    key={item.path}
                    custom={i}
                    initial="hidden"
                    animate="visible"
                    variants={menuItemVariants}
                  >
                    <Link
                      to={item.path}
                      onClick={() => setOpen(false)}
                      className={`flex items-center gap-3.5 rounded-2xl px-5 py-4 text-xl font-bold transition-all duration-200 ${
                        location.pathname === item.path
                          ? "bg-primary/10 text-primary"
                          : "text-foreground hover:bg-muted hover:translate-x-1"
                      }`}
                      style={{ fontFamily: "'Be Vietnam Pro', sans-serif" }}
                    >
                      <item.icon className="h-6 w-6" />
                      {item.label}
                    </Link>
                  </motion.li>
                ))}

                {/* Account section */}
                {accountItems.length > 0 && (
                  <>
                    <motion.li
                      custom={navItems.length}
                      initial="hidden"
                      animate="visible"
                      variants={menuItemVariants}
                      className="pt-5"
                    >
                      <p className="px-5 pb-2 text-xs font-bold uppercase tracking-widest text-muted-foreground">
                        Tài khoản
                      </p>
                    </motion.li>
                    {accountItems.map((item, i) => (
                      <motion.li
                        key={item.path}
                        custom={navItems.length + 1 + i}
                        initial="hidden"
                        animate="visible"
                        variants={menuItemVariants}
                      >
                        <Link
                          to={item.path}
                          onClick={() => setOpen(false)}
                          className={`flex items-center gap-3 rounded-2xl px-5 py-3.5 text-base font-semibold transition-all duration-200 ${
                            location.pathname === item.path
                              ? "bg-primary/10 text-primary"
                              : "text-foreground hover:bg-muted hover:translate-x-1"
                          }`}
                          style={{ fontFamily: "'Be Vietnam Pro', sans-serif" }}
                        >
                          <item.icon className="h-5 w-5" />
                          {item.label}
                        </Link>
                      </motion.li>
                    ))}
                  </>
                )}

                {/* Bottom action */}
                <motion.li
                  custom={navItems.length + accountItems.length + 2}
                  initial="hidden"
                  animate="visible"
                  variants={menuItemVariants}
                  className="mt-6 border-t border-border pt-5"
                >
                  {user ? (
                    <button
                      onClick={() => { signOut(); setOpen(false); }}
                      className="flex w-full items-center gap-3 rounded-2xl px-5 py-3.5 text-base font-semibold text-muted-foreground transition-all duration-200 hover:bg-muted hover:text-foreground hover:translate-x-1"
                      style={{ fontFamily: "'Be Vietnam Pro', sans-serif" }}
                    >
                      <LogOut className="h-5 w-5" />
                      Đăng xuất
                    </button>
                  ) : (
                    <Link
                      to="/auth"
                      onClick={() => setOpen(false)}
                      className="flex items-center gap-3 rounded-2xl px-5 py-3.5 text-base font-semibold text-foreground transition-all duration-200 hover:bg-muted hover:translate-x-1"
                      style={{ fontFamily: "'Be Vietnam Pro', sans-serif" }}
                    >
                      <User className="h-5 w-5" />
                      Đăng nhập
                    </Link>
                  )}
                </motion.li>
              </ul>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </header>
  );
};

export default Navbar;
