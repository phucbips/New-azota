-- Create verification_codes table if not exists
CREATE TABLE IF NOT EXISTS public.verification_codes (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    email TEXT NOT NULL,
    code TEXT NOT NULL,
    type TEXT NOT NULL,
    is_used BOOLEAN DEFAULT FALSE,
    expires_at TIMESTAMPTZ NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE public.verification_codes ENABLE ROW LEVEL SECURITY;

-- Allow Service Role full access (for Edge Functions)
CREATE POLICY "Service Role Full Access" ON public.verification_codes
    USING (true) WITH CHECK (true);

-- Allow authenticated users to read their own codes (optional, usually handled by Edge Function)
-- But primarily we rely on the Edge Function using the Service Role Key.

-- Helper function to cleanup expired codes
CREATE OR REPLACE FUNCTION cleanup_expired_codes()
RETURNS void AS $$
BEGIN
  DELETE FROM public.verification_codes WHERE expires_at < NOW();
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
