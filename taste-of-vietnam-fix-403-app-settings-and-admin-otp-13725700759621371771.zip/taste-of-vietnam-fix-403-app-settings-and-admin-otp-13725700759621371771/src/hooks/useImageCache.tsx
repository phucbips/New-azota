import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";

interface ImageCacheContextType {
  cachedUrls: Map<string, string>;
  isReady: boolean;
}

const ImageCacheContext = createContext<ImageCacheContextType>({ cachedUrls: new Map(), isReady: false });

export const useImageCache = () => useContext(ImageCacheContext);

export const ImageCacheProvider = ({ children }: { children: ReactNode }) => {
  const [cachedUrls, setCachedUrls] = useState<Map<string, string>>(new Map());
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    const preloadMenuImages = async () => {
      const { data } = await supabase
        .from("monthly_menu")
        .select("id, image_url")
        .eq("is_active", true);

      if (!data) { setIsReady(true); return; }

      const urls = new Map<string, string>();
      const promises = data
        .filter((item) => item.image_url)
        .map((item) => {
          return new Promise<void>((resolve) => {
            const img = new Image();
            img.onload = img.onerror = () => {
              urls.set(item.id, item.image_url!);
              resolve();
            };
            img.src = item.image_url!;
          });
        });

      await Promise.all(promises);
      setCachedUrls(urls);
      setIsReady(true);
    };

    preloadMenuImages();
  }, []);

  return (
    <ImageCacheContext.Provider value={{ cachedUrls, isReady }}>
      {children}
    </ImageCacheContext.Provider>
  );
};
