export const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

export function getRequiredEnv(key: string): string {
  const val = Deno.env.get(key);
  if (!val) {
    throw new Error(`Missing required environment variable: ${key}`);
  }

  // 1. Trim whitespace
  let cleanVal = val.trim();

  // 2. Remove surrounding quotes (both single and double)
  if (
    (cleanVal.startsWith('"') && cleanVal.endsWith('"')) ||
    (cleanVal.startsWith("'") && cleanVal.endsWith("'"))
  ) {
    cleanVal = cleanVal.slice(1, -1);
  }

  // 3. Normalize newlines (replace literal "\n" with actual newline)
  cleanVal = cleanVal.replace(/\\n/g, '\n');

  // 4. Final trim
  cleanVal = cleanVal.trim();

  // 5. Ensure not empty after cleaning
  if (!cleanVal) {
    throw new Error(`Environment variable ${key} is empty after cleaning`);
  }

  return cleanVal;
}
