import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Star, MessageSquare } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

interface Feedback {
  id: string;
  customer_name: string | null;
  rating: number;
  comment: string | null;
  created_at: string;
}

const TestimonialCarousel = () => {
  const [feedbacks, setFeedbacks] = useState<Feedback[]>([]);
  const [pageIndex, setPageIndex] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchFeedbacks = async () => {
      const { data } = await supabase
        .from("feedback")
        .select("*")
        .gte("rating", 4)
        .not("comment", "is", null)
        .order("created_at", { ascending: false })
        .limit(30);
      if (data) setFeedbacks(data.filter((f) => f.comment && f.comment.trim().length > 0));
      setLoading(false);
    };
    fetchFeedbacks();
  }, []);

  const pageSize = 3;
  const totalPages = Math.max(1, Math.ceil(feedbacks.length / pageSize));

  // Auto-rotate every 6 seconds
  useEffect(() => {
    if (totalPages <= 1) return;
    const interval = setInterval(() => {
      setPageIndex((prev) => (prev + 1) % totalPages);
    }, 6000);
    return () => clearInterval(interval);
  }, [totalPages]);

  if (loading || feedbacks.length === 0) return null;

  const currentFeedbacks = feedbacks.slice(pageIndex * pageSize, pageIndex * pageSize + pageSize);

  const getInitial = (name: string | null) => {
    if (!name) return "K";
    return name.charAt(0).toUpperCase();
  };

  return (
    <section className="py-16 md:py-20 bg-card/50">
      <div className="container mx-auto px-4">
        <div className="mb-10 text-center">
          <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
            <MessageSquare className="h-6 w-6 text-primary" />
          </div>
          <h2 className="font-display text-3xl font-extrabold text-foreground md:text-4xl">
            Khách hàng nói gì?
          </h2>
          <p className="mt-2 text-muted-foreground">Những đánh giá yêu thích từ khách hàng</p>
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={pageIndex}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.4 }}
            className={`mx-auto grid max-w-5xl gap-6 ${
              currentFeedbacks.length === 1
                ? "grid-cols-1 max-w-md"
                : currentFeedbacks.length === 2
                ? "grid-cols-1 md:grid-cols-2 max-w-2xl"
                : "grid-cols-1 md:grid-cols-3"
            }`}
          >
            {currentFeedbacks.map((fb) => (
              <div
                key={fb.id}
                className="flex flex-col rounded-2xl border border-border bg-card p-6 shadow-sm"
              >
                {/* Stars */}
                <div className="mb-3 flex items-center gap-1">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star
                      key={i}
                      className={`h-4 w-4 ${i < fb.rating ? "fill-secondary text-secondary" : "text-muted"}`}
                    />
                  ))}
                </div>

                {/* Comment */}
                <p className="mb-4 flex-1 text-sm text-foreground italic leading-relaxed">
                  "{fb.comment}"
                </p>

                {/* Author */}
                <div className="flex items-center gap-3 border-t border-border pt-4">
                  <div className="flex h-9 w-9 items-center justify-center rounded-full bg-primary/10 text-sm font-bold text-primary">
                    {getInitial(fb.customer_name)}
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-foreground">
                      {fb.customer_name || "Khách hàng"}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {new Date(fb.created_at).toLocaleDateString("vi-VN")}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </motion.div>
        </AnimatePresence>

        {/* Dots indicator */}
        {totalPages > 1 && (
          <div className="mt-8 flex items-center justify-center gap-2">
            {Array.from({ length: totalPages }).map((_, i) => (
              <button
                key={i}
                onClick={() => setPageIndex(i)}
                className={`h-2 rounded-full transition-all ${
                  i === pageIndex ? "w-6 bg-primary" : "w-2 bg-muted-foreground/30"
                }`}
              />
            ))}
          </div>
        )}
      </div>
    </section>
  );
};

export default TestimonialCarousel;
