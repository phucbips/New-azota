-- ==============================================================================
-- BƯỚC 1: ĐẢM BẢO QUYỀN ĐI VÀO SCHEMA (CỔNG NGOÀI CÙNG)
-- ==============================================================================
GRANT USAGE ON SCHEMA public TO anon, authenticated;

-- ==============================================================================
-- BƯỚC 2: CẤP QUYỀN THAO TÁC CƠ BẢN LÊN BẢNG (GRANTS)
-- ==============================================================================
-- Cho phép khách (anon) và người dùng (authenticated) được ĐỌC
GRANT SELECT ON public.app_settings TO anon, authenticated;
-- Cho phép người dùng (authenticated) được THÊM, SỬA, XÓA (Policy sẽ kiểm soát ai được làm)
GRANT INSERT, UPDATE, DELETE ON public.app_settings TO authenticated;

-- ==============================================================================
-- BƯỚC 3: NUKE (XÓA SỔ TOÀN BỘ RLS CŨ ĐỂ TRÁNH XUNG ĐỘT)
-- ==============================================================================
DO $$
DECLARE
    pol RECORD;
BEGIN
    FOR pol IN
        SELECT policyname
        FROM pg_policies
        WHERE schemaname = 'public' AND tablename = 'app_settings'
    LOOP
        EXECUTE format('DROP POLICY IF EXISTS %I ON public.app_settings', pol.policyname);
    END LOOP;
END
$$;

-- ==============================================================================
-- BƯỚC 4: BẬT RLS VÀ TẠO CÁC POLICY MỚI RÕ RÀNG
-- ==============================================================================
ALTER TABLE public.app_settings ENABLE ROW LEVEL SECURITY;

-- 1. Ai cũng có thể đọc app_settings (cho phép các thành phần public access được cấu hình chung)
-- 1. Ai cũng có thể đọc các cấu hình public (CHỈ được đọc các key an toàn, KHÔNG đọc Secret API Keys)
CREATE POLICY "Public_Select_AppSettings"
ON public.app_settings
FOR SELECT
USING (key IN ('SOCIAL_LINKS', 'SHIPPING_ZONE_CONFIG', 'REQUIRE_ADMIN_OTP'));

-- 2. Chỉ có Admin mới được Thêm/Sửa/Xóa app_settings
CREATE POLICY "Admin_Manage_AppSettings"
ON public.app_settings
FOR ALL
TO authenticated
USING (public.has_role(auth.uid(), 'admin'::text));
