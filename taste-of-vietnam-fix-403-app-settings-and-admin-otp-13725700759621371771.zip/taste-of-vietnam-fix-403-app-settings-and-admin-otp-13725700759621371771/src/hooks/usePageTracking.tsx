import { useEffect } from "react";
import { useLocation } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";

function detectBrowser(ua: string): string {
  if (ua.includes("Firefox")) return "Firefox";
  if (ua.includes("Edg")) return "Edge";
  if (ua.includes("Chrome")) return "Chrome";
  if (ua.includes("Safari")) return "Safari";
  if (ua.includes("Opera") || ua.includes("OPR")) return "Opera";
  return "Other";
}

function detectDevice(ua: string, width: number): string {
  if (/Mobi|Android/i.test(ua) || width < 768) return "Mobile";
  if (/Tablet|iPad/i.test(ua) || (width >= 768 && width < 1024)) return "Tablet";
  return "Desktop";
}

export const usePageTracking = () => {
  const location = useLocation();

  useEffect(() => {
    const ua = navigator.userAgent;
    supabase.from("page_views").insert({
      path: location.pathname,
      referrer: document.referrer || null,
      user_agent: ua,
      device_type: detectDevice(ua, window.innerWidth),
      browser: detectBrowser(ua),
      screen_width: window.innerWidth,
    } as any).then(() => {});
  }, [location.pathname]);
};
