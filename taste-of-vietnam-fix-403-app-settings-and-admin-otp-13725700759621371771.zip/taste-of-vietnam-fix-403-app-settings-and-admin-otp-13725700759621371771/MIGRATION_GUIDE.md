# Hướng dẫn di chuyển sang Project Supabase Mới (Full Control)

Bạn cần thực hiện theo các bước này để tạo project Supabase của riêng mình, cấu hình đầy đủ để chạy ngon lành trên Vercel.

## Bước 1: Tạo Project Supabase Mới

1.  Truy cập [Supabase Dashboard](https://supabase.com/dashboard) và tạo một tài khoản (nếu chưa có).
2.  Bấm **New Project** -> **Create new project**.
3.  Đặt tên project (ví dụ: `Nova Cookie Official`), đặt mật khẩu DB (lưu lại mật khẩu này!).
4.  Chọn Region gần nhất (ví dụ: `Singapore` cho tốc độ về VN nhanh nhất).
5.  Đợi vài phút để Supabase khởi tạo.

## Bước 2: Lấy thông tin Project

Sau khi tạo xong, vào **Project Settings** -> **API**:
1.  Copy **Project URL**.
2.  Copy **anon public key**.
3.  Copy **service_role secret** (quan trọng, dùng cho Edge Functions).

## Bước 3: Đẩy cấu trúc Database (Schema Migration)

Vì source code đã có sẵn các file migration trong `supabase/migrations/`, bạn có thể đẩy chúng lên project mới bằng dòng lệnh hoặc copy paste thủ công.

### Cách 1: Dùng SQL Editor (Thủ công - Dễ nhất)
1.  Vào thư mục `supabase/migrations/` trên máy tính hoặc GitHub.
2.  Mở lần lượt các file `.sql` từ cũ nhất đến mới nhất (theo ngày tháng).
3.  Copy nội dung từng file -> Paste vào **SQL Editor** trên Supabase Dashboard -> Bấm **Run**.
    *   *Lưu ý:* Nếu chạy file nào bị lỗi, hãy đọc kỹ lỗi. Thường thì thứ tự chạy file rất quan trọng.
    *   *Mẹo:* Bạn có thể gộp tất cả nội dung các file vào một file lớn rồi chạy một lần.

### Cách 2: Dùng Supabase CLI (Nâng cao)
Nếu bạn đã cài Docker và Supabase CLI:
```bash
supabase login
supabase link --project-ref <project-ref-id>
supabase db push
```

## Bước 4: Cấu hình Authentication (Google Login)

Xem hướng dẫn chi tiết trong file `GOOGLE_AUTH_SETUP.md`.

## Bước 5: Cấu hình Storage

Project cũ có thể có bucket chứa ảnh sản phẩm. Bạn cần tạo lại:
1.  Vào **Storage** -> **New Bucket**.
2.  Đặt tên bucket giống trong code (ví dụ `product-images`, kiểm tra trong `src/pages/BakerDashboard.tsx`).
3.  Chọn **Public**.
4.  Bấm **Create bucket**.
5.  Vào **Policies** của bucket đó, thêm policy cho phép `SELECT`, `INSERT`, `UPDATE`, `DELETE` cho user đã đăng nhập (hoặc public tùy nhu cầu).

## Bước 6: Cập nhật Biến Môi trường (Environment Variables)

Xem hướng dẫn trong file `UPDATE_VERCEL_ENV.md`.

## Bước 7: Deploy lại Backend (Edge Functions)

Sử dụng script tự động `deploy-functions.sh` để cấu hình secrets và deploy functions một cách nhanh chóng.

1.  Mở terminal tại thư mục gốc của dự án.
2.  Chạy lệnh:
    ```bash
    sh deploy-functions.sh
    ```
3.  Làm theo hướng dẫn trên màn hình (có thể cần nhập mật khẩu database nếu được hỏi).

Script này sẽ:
*   Link dự án của bạn tới Project ID mới (`iiglwrhbdddmgfzsmimv`).
*   Tự động set các biến môi trường (Secrets) cho PayOS, Cloudinary...
*   Deploy toàn bộ functions lên cloud.

---
Sau khi làm xong các bước này, website của bạn sẽ chạy trên hạ tầng do chính bạn quản lý hoàn toàn!
