-- ==============================================================================
-- GIẢI PHÁP TỔNG THỂ: CẤP LẠI QUYỀN (GRANTS) VÀ RLS CHO TOÀN BỘ CÁC BẢNG BỊ THIẾU
-- Sửa lỗi User không Vote được, không claim được voucher, v.v.
-- ==============================================================================

-- 1. Cấp quyền Thao tác (CRUD) cho User/Khách trên toàn bộ bảng
-- Giải thích: Supabase khuyên nên dùng RLS để chặn, chứ không nên dùng GRANT để chặn.
-- Do đó, chúng ta cứ GRANT INSERT, SELECT, UPDATE cho public, sau đó dùng RLS filter lại.
GRANT USAGE ON SCHEMA public TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO anon, authenticated;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO anon, authenticated;

-- *NGOẠI LỆ DUY NHẤT VÀ TỐI QUAN TRỌNG: verification_codes*
-- Khách không bao giờ được phép đụng vào bảng chứa mã OTP này.
REVOKE ALL ON public.verification_codes FROM anon, authenticated;
GRANT ALL ON public.verification_codes TO service_role, postgres;

-- ------------------------------------------------------------------------------
-- 2. ĐẢM BẢO RLS ĐÃ BẬT TRÊN TẤT CẢ CÁC BẢNG CẦN THIẾT
-- ------------------------------------------------------------------------------
ALTER TABLE public.votes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_vouchers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.feedback ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.voucher_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.monthly_menu ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_surcharges ENABLE ROW LEVEL SECURITY;

-- ------------------------------------------------------------------------------
-- 3. NUKE POLICY CŨ CỦA CÁC BẢNG CÒN LẠI VÀ XÂY LẠI
-- ------------------------------------------------------------------------------
DO $$
BEGIN
    -- Xóa policies bảng votes
    EXECUTE 'DROP POLICY IF EXISTS "Public_Select_Votes" ON public.votes';
    EXECUTE 'DROP POLICY IF EXISTS "Auth_Insert_Own_Vote" ON public.votes';
    EXECUTE 'DROP POLICY IF EXISTS "Admin_Manage_Votes" ON public.votes';

    -- Xóa policies bảng user_vouchers
    EXECUTE 'DROP POLICY IF EXISTS "Auth_Select_Own_Vouchers" ON public.user_vouchers';
    EXECUTE 'DROP POLICY IF EXISTS "Auth_Insert_Own_Vouchers" ON public.user_vouchers';
    EXECUTE 'DROP POLICY IF EXISTS "Admin_Manage_UserVouchers" ON public.user_vouchers';

    -- Xóa policies bảng feedback
    EXECUTE 'DROP POLICY IF EXISTS "Public_Select_Feedback" ON public.feedback';
    EXECUTE 'DROP POLICY IF EXISTS "Public_Insert_Feedback" ON public.feedback';
    EXECUTE 'DROP POLICY IF EXISTS "Admin_Manage_Feedback" ON public.feedback';
EXCEPTION WHEN OTHERS THEN
END
$$;

-- ------------------------------------------------------------------------------
-- 4. TẠO CÁC POLICY "CHUẨN CHỈ" MỚI (SECURE RLS)
-- ------------------------------------------------------------------------------

-- A. BẢNG `votes` (Bình chọn Ranking)
-- Ai cũng xem được số lượng bình chọn
CREATE POLICY "Public_Select_Votes" ON public.votes FOR SELECT USING (true);
-- User chỉ có thể bình chọn (Insert) cho chính họ
CREATE POLICY "Auth_Insert_Own_Vote" ON public.votes FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
-- Admin được sửa/xóa (Quản lý)
CREATE POLICY "Admin_Manage_Votes" ON public.votes FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin'::text));

-- B. BẢNG `user_vouchers` (Kho Voucher của User)
-- User chỉ xem được voucher của chính họ
CREATE POLICY "Auth_Select_Own_Vouchers" ON public.user_vouchers FOR SELECT TO authenticated USING (auth.uid() = user_id);
-- User có thể tự Insert voucher khi claim quà tặng (như chức năng Ranking)
CREATE POLICY "Auth_Insert_Own_Vouchers" ON public.user_vouchers FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
-- Admin xem hết
CREATE POLICY "Admin_Manage_UserVouchers" ON public.user_vouchers FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin'::text));

-- C. BẢNG `feedback` (Đánh giá đơn hàng)
-- Ai cũng đọc được đánh giá (để hiển thị trên trang chủ)
CREATE POLICY "Public_Select_Feedback" ON public.feedback FOR SELECT USING (true);
-- Bất kỳ ai (kể cả khách vãng lai mua hàng bằng order_code) đều được gửi đánh giá
CREATE POLICY "Public_Insert_Feedback" ON public.feedback FOR INSERT WITH CHECK (true);
-- Admin có quyền xóa đánh giá rác
CREATE POLICY "Admin_Manage_Feedback" ON public.feedback FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin'::text));

-- ==============================================================================
-- 5. CHẮC CHẮN CÁC BẢNG CONFIG PUBLIC (Menu, Vouchers, Surcharges) CHỈ CHO ĐỌC
-- ==============================================================================
-- (Bởi vì lệnh GRANT bên trên cho Insert, nên RLS phải siết lại để User không đi phá Menu)
DO $$
BEGIN
    EXECUTE 'DROP POLICY IF EXISTS "Public_Select_Menu" ON public.monthly_menu';
    EXECUTE 'DROP POLICY IF EXISTS "Public_Select_VoucherTemplates" ON public.voucher_templates';
    EXECUTE 'DROP POLICY IF EXISTS "Public_Select_Surcharges" ON public.order_surcharges';
EXCEPTION WHEN OTHERS THEN END
$$;

-- Mở quyền Đọc (Select)
CREATE POLICY "Public_Select_Menu" ON public.monthly_menu FOR SELECT USING (true);
CREATE POLICY "Public_Select_VoucherTemplates" ON public.voucher_templates FOR SELECT USING (true);
CREATE POLICY "Public_Select_Surcharges" ON public.order_surcharges FOR SELECT USING (true);

-- (Quyền Admin Update cho các bảng này đã có từ các script trước, nếu thiếu thì chạy Admin role)
