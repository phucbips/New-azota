-- Emergency Fix: Open access to remaining tables to resolve 403 errors

-- 1. Disable RLS on tables causing 403/406 errors
ALTER TABLE public.orders DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.feedback DISABLE ROW LEVEL SECURITY;

-- 2. Grant permissions to anon and authenticated
GRANT ALL ON public.orders TO anon, authenticated;
GRANT ALL ON public.profiles TO anon, authenticated;
GRANT ALL ON public.feedback TO anon, authenticated;

-- 3. Force refresh
NOTIFY pgrst, 'reload config';
