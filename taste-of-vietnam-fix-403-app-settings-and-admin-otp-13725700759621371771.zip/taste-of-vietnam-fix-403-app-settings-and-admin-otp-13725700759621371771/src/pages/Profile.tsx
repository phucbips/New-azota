import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { User, Phone, MapPin, Loader2, ArrowLeft, Save, Navigation, Search, Star, MessageSquare, Check } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";
import { useGeolocation } from "@/hooks/useGeolocation";
import AddressMap from "@/components/AddressMap";
import { z } from "zod";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

const profileSchema = z.object({
  full_name: z.string().trim().min(1, "Vui lòng nhập họ tên").max(100),
  phone: z.string().trim().regex(/^0\d{9}$/, "Số điện thoại không hợp lệ (VD: 0912345678)"),
  default_address: z.string().trim().min(5, "Vui lòng nhập địa chỉ").max(300),
});

interface DeliveredOrder {
  order_code: string;
  customer_name: string;
  created_at: string;
  hasFeedback: boolean;
}

const Profile = () => {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [fullName, setFullName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);
  const [fetching, setFetching] = useState(true);
  const geoProfile = useGeolocation((addr) => {
    setAddress(addr);
    if (errors.default_address) setErrors((p) => ({ ...p, default_address: "" }));
  });

  // Feedback state
  const [deliveredOrders, setDeliveredOrders] = useState<DeliveredOrder[]>([]);
  const [feedbackOrderCode, setFeedbackOrderCode] = useState<string | null>(null);
  const [feedbackRating, setFeedbackRating] = useState(0);
  const [feedbackHover, setFeedbackHover] = useState(0);
  const [feedbackComment, setFeedbackComment] = useState("");
  const [feedbackSubmitting, setFeedbackSubmitting] = useState(false);

  useEffect(() => {
    if (!authLoading && !user) {
      navigate("/auth");
    }
  }, [user, authLoading, navigate]);

  useEffect(() => {
    if (!user) return;
    const fetchData = async () => {
      // Profile
      const { data } = await supabase
        .from("profiles")
        .select("*")
        .eq("user_id", user.id)
        .single();
      if (data) {
        setFullName(data.full_name || "");
        setPhone(data.phone || "");
        setAddress(data.default_address || "");
      }

      // Delivered orders
      const { data: orders } = await supabase
        .from("orders")
        .select("order_code, customer_name, created_at")
        .eq("user_id", user.id)
        .eq("status", "delivered")
        .order("created_at", { ascending: false })
        .limit(20);

      if (orders && orders.length > 0) {
        const codes = orders.map((o) => o.order_code);
        const { data: feedbacks } = await supabase
          .from("feedback")
          .select("order_code")
          .in("order_code", codes);
        const feedbackSet = new Set((feedbacks || []).map((f) => f.order_code));
        setDeliveredOrders(
          orders.map((o) => ({
            ...o,
            hasFeedback: feedbackSet.has(o.order_code),
          }))
        );
      }

      setFetching(false);
    };
    fetchData();
  }, [user]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const result = profileSchema.safeParse({ full_name: fullName, phone, default_address: address });
    if (!result.success) {
      const fieldErrors: Record<string, string> = {};
      result.error.errors.forEach((err) => {
        if (err.path[0]) fieldErrors[err.path[0] as string] = err.message;
      });
      setErrors(fieldErrors);
      return;
    }
    setErrors({});
    setLoading(true);
    try {
      const { error } = await supabase
        .from("profiles")
        .update({
          full_name: fullName.trim(),
          phone: phone.trim(),
          default_address: address.trim(),
        })
        .eq("user_id", user!.id);
      if (error) throw error;
      toast.success("Cập nhật thông tin thành công!");
    } catch (err) {
      console.error(err);
      toast.error("Có lỗi xảy ra!");
    } finally {
      setLoading(false);
    }
  };

  const handleFeedbackSubmit = async () => {
    if (!feedbackOrderCode || feedbackRating === 0) {
      toast.error("Vui lòng chọn số sao!");
      return;
    }
    setFeedbackSubmitting(true);
    try {
      const order = deliveredOrders.find((o) => o.order_code === feedbackOrderCode);
      const { error } = await supabase.from("feedback").insert({
        order_code: feedbackOrderCode,
        customer_name: order?.customer_name || fullName,
        rating: feedbackRating,
        comment: feedbackComment.trim() || null,
        user_id: user?.id || null,
      } as any);
      if (error) throw error;
      toast.success("Cảm ơn bạn đã đánh giá! 💛");
      setDeliveredOrders((prev) =>
        prev.map((o) => o.order_code === feedbackOrderCode ? { ...o, hasFeedback: true } : o)
      );
      setFeedbackOrderCode(null);
      setFeedbackRating(0);
      setFeedbackComment("");
    } catch (err) {
      console.error(err);
      toast.error("Không thể gửi đánh giá!");
    } finally {
      setFeedbackSubmitting(false);
    }
  };

  if (authLoading || fetching) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  const fields = [
    { key: "full_name", label: "Họ tên", icon: User, value: fullName, setter: setFullName, placeholder: "Nguyễn Văn A", type: "text" },
    { key: "phone", label: "Số điện thoại", icon: Phone, value: phone, setter: setPhone, placeholder: "0912345678", type: "tel" },
    { key: "default_address", label: "Địa chỉ mặc định", icon: MapPin, value: address, setter: setAddress, placeholder: "Số nhà, đường, phường, quận, TP", type: "text" },
  ];

  const unfeedbackedOrders = deliveredOrders.filter((o) => !o.hasFeedback);

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="container mx-auto px-4 pb-16 pt-24">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mx-auto max-w-lg"
        >
          <button
            onClick={() => navigate(-1)}
            className="mb-6 flex items-center gap-2 text-sm font-semibold text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="h-4 w-4" />
            Quay lại
          </button>

          <h1 className="mb-2 font-display text-3xl font-extrabold text-foreground">
            Thông tin cá nhân
          </h1>
          <p className="mb-8 text-muted-foreground">
            Cập nhật thông tin để đặt hàng nhanh hơn
          </p>

          <div className="mb-6 rounded-xl border border-border bg-card p-4">
            <p className="text-sm text-muted-foreground">Email</p>
            <p className="font-semibold text-foreground">{user?.email}</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            {fields.map(({ key, label, icon: Icon, value, setter, placeholder, type }) => (
              <div key={key}>
                <label className="mb-1.5 block text-sm font-semibold text-foreground">{label}</label>
                <div className="relative">
                  <Icon className="absolute left-3.5 top-3.5 h-4 w-4 text-muted-foreground" />
                  <input
                    type={type}
                    placeholder={placeholder}
                    value={value}
                    onChange={(e) => { setter(e.target.value); if (errors[key]) setErrors((p) => ({ ...p, [key]: "" })); }}
                    className={`w-full rounded-xl border ${errors[key] ? "border-destructive" : "border-border"} bg-background px-4 py-3 pl-11 text-sm text-foreground outline-none transition-colors placeholder:text-muted-foreground focus:border-primary focus:ring-2 focus:ring-primary/20 ${key === "default_address" ? "pr-36" : ""}`}
                  />
                  {key === "default_address" && (
                    <div className="absolute right-1.5 top-1/2 -translate-y-1/2 flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => geoProfile.geocodeAddress(address)}
                        disabled={geoProfile.loading || !address.trim()}
                        className="flex items-center gap-1 rounded-lg bg-primary/10 px-2.5 py-1.5 text-xs font-semibold text-primary transition-colors hover:bg-primary/20 disabled:opacity-50"
                      >
                        <Search className="h-3.5 w-3.5" />
                        Tìm
                      </button>
                      <button
                        type="button"
                        onClick={() => geoProfile.getLocation()}
                        disabled={geoProfile.loading}
                        className="flex items-center gap-1 rounded-lg bg-primary/10 px-2.5 py-1.5 text-xs font-semibold text-primary transition-colors hover:bg-primary/20 disabled:opacity-50"
                      >
                        {geoProfile.loading ? (
                          <Loader2 className="h-3.5 w-3.5 animate-spin" />
                        ) : (
                          <Navigation className="h-3.5 w-3.5" />
                        )}
                        GPS
                      </button>
                    </div>
                  )}
                </div>
                {errors[key] && <p className="mt-1 text-xs text-destructive">{errors[key]}</p>}
              </div>
            ))}
            {geoProfile.coords && (
              <AddressMap
                coords={geoProfile.coords}
                onMapClick={(newCoords) => geoProfile.reverseGeocode(newCoords)}
              />
            )}
            <button
              type="submit"
              disabled={loading}
              className="flex w-full items-center justify-center gap-2 rounded-full bg-primary px-6 py-3 text-sm font-bold text-primary-foreground transition-transform hover:scale-[1.02] disabled:opacity-50"
            >
              {loading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Đang lưu...
                </>
              ) : (
                <>
                  <Save className="h-4 w-4" />
                  Lưu thông tin
                </>
              )}
            </button>
          </form>

          {/* Feedback Section */}
          {deliveredOrders.length > 0 && (
            <div className="mt-10">
              <div className="mb-4 flex items-center gap-2">
                <MessageSquare className="h-5 w-5 text-primary" />
                <h2 className="font-display text-xl font-bold text-foreground">Đánh giá đơn hàng</h2>
              </div>

              {unfeedbackedOrders.length === 0 ? (
                <div className="rounded-2xl border border-border bg-card p-6 text-center">
                  <Check className="mx-auto mb-2 h-8 w-8 text-primary" />
                  <p className="text-sm text-muted-foreground">Bạn đã đánh giá tất cả đơn hàng rồi! 🎉</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {unfeedbackedOrders.map((order) => (
                    <div key={order.order_code} className="rounded-2xl border border-border bg-card p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm font-bold text-foreground">#{order.order_code}</p>
                          <p className="text-xs text-muted-foreground">
                            {new Date(order.created_at).toLocaleDateString("vi-VN")}
                          </p>
                        </div>
                        {feedbackOrderCode === order.order_code ? (
                          <button
                            onClick={() => { setFeedbackOrderCode(null); setFeedbackRating(0); setFeedbackComment(""); }}
                            className="text-xs text-muted-foreground hover:text-foreground"
                          >
                            Đóng
                          </button>
                        ) : (
                          <button
                            onClick={() => setFeedbackOrderCode(order.order_code)}
                            className="rounded-full bg-primary/10 px-3 py-1.5 text-xs font-semibold text-primary hover:bg-primary/20"
                          >
                            Đánh giá ⭐
                          </button>
                        )}
                      </div>

                      {feedbackOrderCode === order.order_code && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: "auto" }}
                          className="mt-4 space-y-3"
                        >
                          <div className="flex gap-1">
                            {[1, 2, 3, 4, 5].map((star) => (
                              <button
                                key={star}
                                onClick={() => setFeedbackRating(star)}
                                onMouseEnter={() => setFeedbackHover(star)}
                                onMouseLeave={() => setFeedbackHover(0)}
                                className="p-0.5 transition-transform hover:scale-110"
                              >
                                <Star
                                  className={`h-7 w-7 ${
                                    star <= (feedbackHover || feedbackRating)
                                      ? "fill-primary text-primary"
                                      : "text-muted-foreground/30"
                                  }`}
                                />
                              </button>
                            ))}
                          </div>
                          <textarea
                            value={feedbackComment}
                            onChange={(e) => setFeedbackComment(e.target.value)}
                            placeholder="Nhận xét thêm (tùy chọn)..."
                            rows={2}
                            className="w-full rounded-xl border border-border bg-background px-3 py-2 text-sm text-foreground outline-none placeholder:text-muted-foreground focus:border-primary"
                          />
                          <button
                            onClick={handleFeedbackSubmit}
                            disabled={feedbackSubmitting || feedbackRating === 0}
                            className="w-full rounded-full bg-primary px-4 py-2.5 text-sm font-bold text-primary-foreground disabled:opacity-50"
                          >
                            {feedbackSubmitting ? (
                              <span className="flex items-center justify-center gap-2">
                                <Loader2 className="h-4 w-4 animate-spin" />
                                Đang gửi...
                              </span>
                            ) : (
                              "Gửi đánh giá"
                            )}
                          </button>
                        </motion.div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </motion.div>
      </main>
      <Footer />
    </div>
  );
};

export default Profile;
