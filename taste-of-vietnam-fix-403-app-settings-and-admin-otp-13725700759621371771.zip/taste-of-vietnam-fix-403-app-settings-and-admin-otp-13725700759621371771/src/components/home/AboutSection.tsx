import { motion } from "framer-motion";
import { MapPin, Leaf, Heart } from "lucide-react";
import { MotifDivider, CornerVine, DetailedLotus, BananaLeaf } from "@/components/decorations/VietnameseMotifs";

const pillars = [
  {
    icon: MapPin,
    title: "Văn hóa bản địa",
    desc: "34 hương vị từ nông sản tiêu biểu của 34 tỉnh thành, tôn vinh đa dạng vùng miền.",
    accent: "bg-secondary/15",
  },
  {
    icon: Leaf,
    title: "Bảo vệ môi trường",
    desc: "5% mỗi đơn hàng trích vào Quỹ Trồng Cây Xanh — hành động nhỏ, ý nghĩa lớn.",
    accent: "bg-primary/10",
  },
  {
    icon: Heart,
    title: "Khởi nguồn Chí Linh",
    desc: "Từ vùng đất Bát Cổ, nơi truyền thống cần được gìn giữ qua những trải nghiệm gần gũi.",
    accent: "bg-[hsl(var(--nova-lotus)/0.15)]",
  },
];

const AboutSection = () => {
  return (
    <section className="relative overflow-hidden bg-muted/40 py-16 md:py-24">
      {/* Corner vines */}
      <CornerVine className="absolute left-0 top-0 h-28 w-28 md:h-40 md:w-40" position="top-left" />
      <CornerVine className="absolute bottom-0 right-0 h-28 w-28 md:h-40 md:w-40" position="bottom-right" />

      {/* Background lotus decorations */}
      <DetailedLotus className="absolute -right-6 top-[10%] h-32 w-40 opacity-[0.06] md:h-48 md:w-60" size="lg" />
      <BananaLeaf className="absolute -left-8 bottom-[5%] h-40 w-20 opacity-[0.06]" />

      <div className="container relative mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-14 text-center"
        >
          <h2 className="font-display text-4xl font-extrabold text-foreground md:text-5xl">
            Về dự án
          </h2>
          <MotifDivider className="mx-auto mt-4 max-w-xs" />
          <p className="mx-auto mt-4 max-w-2xl text-lg text-muted-foreground">
            Dự án ra đời từ Chí Linh, kết hợp ẩm thực và kể chuyện trực quan để nâng cao nhận thức về bảo tồn văn hóa và môi trường.
          </p>
        </motion.div>

        <div className="grid gap-6 md:grid-cols-3">
          {pillars.map((p, i) => (
            <motion.div
              key={p.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="relative rounded-3xl border border-border bg-card p-10 text-center shadow-sm"
            >
              <div className={`mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-2xl ${p.accent}`}>
                <p.icon className="h-7 w-7 text-primary" />
              </div>
              <h3 className="mb-3 font-display text-xl font-bold text-foreground">{p.title}</h3>
              <p className="text-sm leading-relaxed text-muted-foreground">{p.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
