
-- =============================================
-- NOVA COOKIE DATABASE SCHEMA
-- =============================================

-- 1. ORDERS TABLE
CREATE TABLE public.orders (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  order_code TEXT NOT NULL UNIQUE,
  customer_name TEXT NOT NULL,
  phone TEXT NOT NULL,
  address TEXT NOT NULL,
  notes TEXT,
  payment_method TEXT NOT NULL DEFAULT 'bank_transfer',
  subtotal INTEGER NOT NULL DEFAULT 0,
  shipping_fee INTEGER NOT NULL DEFAULT 0,
  total INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'pending',
  green_fund_amount INTEGER NOT NULL DEFAULT 0
);

ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;

-- Anyone can place an order
CREATE POLICY "Anyone can create orders"
  ON public.orders FOR INSERT
  WITH CHECK (true);

-- Anyone can look up their order by order_code
CREATE POLICY "Anyone can view order by code"
  ON public.orders FOR SELECT
  USING (true);

-- 2. ORDER ITEMS TABLE
CREATE TABLE public.order_items (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  order_id UUID NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
  cookie_name TEXT NOT NULL,
  quantity INTEGER NOT NULL DEFAULT 1,
  unit_price INTEGER NOT NULL DEFAULT 0,
  total_price INTEGER NOT NULL DEFAULT 0
);

ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can create order items"
  ON public.order_items FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Anyone can view order items"
  ON public.order_items FOR SELECT
  USING (true);

-- 3. MONTHLY MENU TABLE
CREATE TABLE public.monthly_menu (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  month_year TEXT NOT NULL,
  cookie_name TEXT NOT NULL,
  origin TEXT,
  price INTEGER NOT NULL DEFAULT 25000,
  image_url TEXT,
  description TEXT,
  display_order INTEGER NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT true,
  UNIQUE(month_year, cookie_name)
);

ALTER TABLE public.monthly_menu ENABLE ROW LEVEL SECURITY;

-- Everyone can read the menu
CREATE POLICY "Anyone can view menu"
  ON public.monthly_menu FOR SELECT
  USING (true);

-- 4. VOTES TABLE
CREATE TABLE public.votes (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  order_code TEXT NOT NULL,
  cookie_name TEXT NOT NULL,
  month_year TEXT NOT NULL,
  UNIQUE(order_code, cookie_name, month_year)
);

ALTER TABLE public.votes ENABLE ROW LEVEL SECURITY;

-- Anyone can vote (1 vote per order per cookie per month)
CREATE POLICY "Anyone can create votes"
  ON public.votes FOR INSERT
  WITH CHECK (true);

-- Anyone can see vote results (for ranking)
CREATE POLICY "Anyone can view votes"
  ON public.votes FOR SELECT
  USING (true);

-- 5. FEEDBACK TABLE
CREATE TABLE public.feedback (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  order_code TEXT NOT NULL,
  rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
  comment TEXT,
  customer_name TEXT
);

ALTER TABLE public.feedback ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can create feedback"
  ON public.feedback FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Anyone can view feedback"
  ON public.feedback FOR SELECT
  USING (true);

-- 6. SEED MONTHLY MENU (March 2026)
INSERT INTO public.monthly_menu (month_year, cookie_name, origin, price, image_url, description, display_order) VALUES
  ('03/2026', 'Cookie Cốm Hà Nội', 'Hà Nội', 25000, '/assets/cookie-com.jpg', 'Hương cốm xanh thơm ngát kết hợp với bơ Pháp', 1),
  ('03/2026', 'Cookie Dừa Bến Tre', 'Bến Tre', 25000, '/assets/cookie-dua.jpg', 'Dừa tươi Bến Tre béo ngậy hòa quyện cùng chocolate', 2),
  ('03/2026', 'Cookie Matcha Lâm Đồng', 'Lâm Đồng', 28000, '/assets/cookie-matcha.jpg', 'Matcha Lâm Đồng nguyên chất với white chocolate', 3),
  ('03/2026', 'Cookie Cacao Đắk Lắk', 'Đắk Lắk', 28000, '/assets/cookie-cacao.jpg', 'Cacao nguyên chất Đắk Lắk đậm đà', 4),
  ('03/2026', 'Cookie Quế Yên Bái', 'Yên Bái', 25000, '/assets/cookie-que.jpg', 'Quế Yên Bái thơm nồng kết hợp đường nâu', 5);
