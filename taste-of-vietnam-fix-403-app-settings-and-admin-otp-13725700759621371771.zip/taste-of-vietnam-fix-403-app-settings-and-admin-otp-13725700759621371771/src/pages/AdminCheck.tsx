import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Loader2, Copy, CheckCircle2, XCircle } from "lucide-react";
import { toast } from "sonner";

const AdminCheck = () => {
  const { user, loading: authLoading } = useAuth();
  const [isAdmin, setIsAdmin] = useState<boolean | null>(null);
  const [checking, setChecking] = useState(true);
  const [roles, setRoles] = useState<string[]>([]);

  useEffect(() => {
    const checkAdmin = async () => {
      if (!user) {
        setChecking(false);
        return;
      }

      setChecking(true);

      // Check user_roles table directly
      const { data: rolesData, error } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", user.id);

      if (error) {
        console.error("Error fetching roles:", error);
      } else {
        const userRoles = rolesData.map((r) => r.role);
        setRoles(userRoles);
        setIsAdmin(userRoles.includes("admin"));
      }

      setChecking(false);
    };

    if (!authLoading) {
      checkAdmin();
    }
  }, [user, authLoading]);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success("Đã sao chép vào bộ nhớ tạm!");
  };

  const sqlSnippet = user ? `INSERT INTO public.user_roles (user_id, role)
VALUES ('${user.id}', 'admin')
ON CONFLICT (user_id, role) DO NOTHING;` : "";

  if (authLoading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-8 font-sans">
      <div className="mx-auto max-w-2xl rounded-2xl border border-border bg-card p-8 shadow-lg">
        <h1 className="mb-6 text-2xl font-bold text-foreground">Kiểm tra quyền Admin</h1>

        <div className="space-y-6">
          {/* User Info */}
          <div className="rounded-xl bg-muted/50 p-4">
            <h2 className="mb-2 text-sm font-semibold uppercase text-muted-foreground">Thông tin người dùng</h2>
            {user ? (
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Trạng thái:</span>
                  <span className="font-medium text-green-600">Đã đăng nhập</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Email:</span>
                  <span className="font-medium text-foreground">{user.email}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">User ID:</span>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs text-foreground bg-muted px-2 py-1 rounded">
                      {user.id}
                    </span>
                    <button
                      onClick={() => copyToClipboard(user.id)}
                      className="text-primary hover:text-primary/80"
                    >
                      <Copy className="h-3 w-3" />
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-sm font-medium text-destructive">Chưa đăng nhập</div>
            )}
          </div>

          {/* Role Status */}
          <div className="rounded-xl border border-border p-6 text-center">
            {checking ? (
              <div className="flex justify-center gap-2 text-muted-foreground">
                <Loader2 className="h-5 w-5 animate-spin" />
                Đang kiểm tra quyền...
              </div>
            ) : isAdmin ? (
              <div className="flex flex-col items-center gap-3">
                <CheckCircle2 className="h-16 w-16 text-green-500" />
                <h3 className="text-xl font-bold text-green-600">Bạn là ADMIN</h3>
                <p className="text-sm text-muted-foreground">
                  Bạn có toàn quyền truy cập trang quản trị.
                </p>
                <div className="mt-2 flex gap-2">
                  {roles.map(role => (
                    <span key={role} className="rounded-full bg-primary/10 px-3 py-1 text-xs font-semibold text-primary capitalize">
                      {role}
                    </span>
                  ))}
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center gap-3">
                <XCircle className="h-16 w-16 text-destructive" />
                <h3 className="text-xl font-bold text-destructive">Bạn KHÔNG PHẢI là Admin</h3>
                <p className="text-sm text-muted-foreground">
                  Các vai trò hiện tại: {roles.length > 0 ? roles.join(", ") : "Không có"}
                </p>
              </div>
            )}
          </div>

          {/* Fix Instructions */}
          {!isAdmin && user && (
            <div className="rounded-xl border border-yellow-200 bg-yellow-50 p-4 dark:border-yellow-900/50 dark:bg-yellow-900/20">
              <h3 className="mb-2 font-bold text-yellow-800 dark:text-yellow-200">Cách khắc phục:</h3>
              <p className="mb-3 text-sm text-yellow-700 dark:text-yellow-300">
                Chạy lệnh SQL này trong Supabase SQL Editor để cấp quyền admin cho tài khoản này:
              </p>
              <div className="relative rounded-lg bg-black/80 p-3">
                <pre className="overflow-x-auto text-xs text-green-400">
                  {sqlSnippet}
                </pre>
                <button
                  onClick={() => copyToClipboard(sqlSnippet)}
                  className="absolute right-2 top-2 rounded bg-white/10 p-1.5 text-white hover:bg-white/20"
                >
                  <Copy className="h-4 w-4" />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AdminCheck;
