-- ==============================================================================
-- FIX LỖI: "Database error saving new user" (SUPABASE AUTH ERROR)
-- Vấn đề: Khi tạo tài khoản mới (Email hoặc Google), hàm Trigger tự động tạo
-- profile và role bị lỗi do RLS hoặc thiếu quyền, làm Rollback toàn bộ tiến trình.
-- Cách giải quyết: Viết lại hàm Trigger với khối Bắt Lỗi (EXCEPTION),
-- và đảm bảo nó chạy bằng quyền cao nhất (SECURITY DEFINER bypass RLS).
-- ==============================================================================

-- 1. Bỏ RLS tạm thời cho các bảng để tránh kẹt quyền nếu Trigger chạy sai context
ALTER TABLE public.profiles DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_roles DISABLE ROW LEVEL SECURITY;

-- 2. Cấp quyền tuyệt đối cho hàm trigger (postgres/service_role)
GRANT ALL ON public.profiles TO postgres, service_role;
GRANT ALL ON public.user_roles TO postgres, service_role;
GRANT USAGE ON SCHEMA public TO postgres, service_role;

-- 3. Tạo lại hàm xử lý an toàn (Safe Trigger Function)
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger AS $$
BEGIN
  -- Bước 1: Thử tạo Profile
  BEGIN
    INSERT INTO public.profiles (user_id, full_name, created_at)
    VALUES (
      new.id,
      COALESCE(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name', 'User'),
      now()
    )
    ON CONFLICT (user_id) DO NOTHING;
  EXCEPTION WHEN OTHERS THEN
    -- Bỏ qua lỗi để không làm hỏng flow tạo user của Auth
    RAISE LOG 'Error inserting profile for user %: %', new.id, SQLERRM;
  END;

  -- Bước 2: Thử gán Role mặc định
  BEGIN
    INSERT INTO public.user_roles (user_id, role)
    VALUES (new.id, 'user')
    ON CONFLICT (user_id, role) DO NOTHING;
  EXCEPTION WHEN OTHERS THEN
    -- Bỏ qua lỗi
    RAISE LOG 'Error inserting role for user %: %', new.id, SQLERRM;
  END;

  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- 4. Đảm bảo Trigger được gắn đúng vào bảng auth.users
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- 5. Bật lại RLS để bảo mật
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- ==============================================================================
-- FIX LỖI: Edge Function 500 (send-verification-code) trên verification_codes
-- Vấn đề: Thỉnh thoảng insert vào verification_codes bị lỗi chặn RLS từ Service Role
-- ==============================================================================
ALTER TABLE public.verification_codes DISABLE ROW LEVEL SECURITY;
GRANT ALL ON public.verification_codes TO postgres, service_role;

-- Đảm bảo có policy cho service_role
DROP POLICY IF EXISTS "Service_Role_All_VerificationCodes" ON public.verification_codes;
CREATE POLICY "Service_Role_All_VerificationCodes"
ON public.verification_codes
FOR ALL
TO service_role
USING (true);

ALTER TABLE public.verification_codes ENABLE ROW LEVEL SECURITY;
