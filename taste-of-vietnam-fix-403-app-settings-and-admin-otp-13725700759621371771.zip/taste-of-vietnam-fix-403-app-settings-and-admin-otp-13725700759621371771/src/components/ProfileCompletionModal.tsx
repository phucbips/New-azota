import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { User, Phone, MapPin, Loader2, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";
import { z } from "zod";

const profileSchema = z.object({
  full_name: z.string().trim().min(1, "Vui lòng nhập họ tên").max(100),
  phone: z.string().trim().regex(/^0\d{9}$/, "Số điện thoại không hợp lệ (VD: 0912345678)"),
  default_address: z.string().trim().min(5, "Vui lòng nhập địa chỉ").max(300),
});

interface Props {
  open: boolean;
  onClose: () => void;
}

const ProfileCompletionModal = ({ open, onClose }: Props) => {
  const { user } = useAuth();
  const [fullName, setFullName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (user) {
      setFullName(user.user_metadata?.full_name || "");
    }
  }, [user]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const result = profileSchema.safeParse({ full_name: fullName, phone, default_address: address });
    if (!result.success) {
      const fieldErrors: Record<string, string> = {};
      result.error.errors.forEach((err) => {
        if (err.path[0]) fieldErrors[err.path[0] as string] = err.message;
      });
      setErrors(fieldErrors);
      return;
    }
    setErrors({});
    setLoading(true);
    try {
      const { error } = await supabase
        .from("profiles")
        .update({
          full_name: fullName.trim(),
          phone: phone.trim(),
          default_address: address.trim(),
        })
        .eq("user_id", user!.id);
      if (error) throw error;
      toast.success("Cập nhật thông tin thành công!");
      onClose();
    } catch (err) {
      console.error(err);
      toast.error("Có lỗi xảy ra!");
    } finally {
      setLoading(false);
    }
  };

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-foreground/40 backdrop-blur-sm"
            onClick={onClose}
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="fixed inset-x-4 top-[10%] z-50 mx-auto max-w-md rounded-2xl border border-border bg-card p-6 shadow-2xl md:p-8"
          >
            <div className="mb-6 flex items-center justify-between">
              <div>
                <h2 className="font-display text-xl font-extrabold text-foreground">
                  Hoàn tất hồ sơ
                </h2>
                <p className="mt-1 text-sm text-muted-foreground">
                  Điền thông tin để đặt hàng nhanh hơn
                </p>
              </div>
              <button onClick={onClose} className="rounded-full p-2 hover:bg-muted">
                <X className="h-5 w-5 text-muted-foreground" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              {[
                { key: "full_name", label: "Họ tên", icon: User, value: fullName, setter: setFullName, placeholder: "Nguyễn Văn A", type: "text" },
                { key: "phone", label: "Số điện thoại", icon: Phone, value: phone, setter: setPhone, placeholder: "0912345678", type: "tel" },
                { key: "default_address", label: "Địa chỉ mặc định", icon: MapPin, value: address, setter: setAddress, placeholder: "Số nhà, đường, phường, quận, TP", type: "text" },
              ].map(({ key, label, icon: Icon, value, setter, placeholder, type }) => (
                <div key={key}>
                  <label className="mb-1.5 block text-sm font-semibold text-foreground">{label}</label>
                  <div className="relative">
                    <Icon className="absolute left-3.5 top-3.5 h-4 w-4 text-muted-foreground" />
                    <input
                      type={type}
                      placeholder={placeholder}
                      value={value}
                      onChange={(e) => { setter(e.target.value); if (errors[key]) setErrors((p) => ({ ...p, [key]: "" })); }}
                      className={`w-full rounded-xl border ${errors[key] ? "border-destructive" : "border-border"} bg-background px-4 py-3 pl-11 text-sm text-foreground outline-none transition-colors placeholder:text-muted-foreground focus:border-primary focus:ring-2 focus:ring-primary/20`}
                    />
                  </div>
                  {errors[key] && <p className="mt-1 text-xs text-destructive">{errors[key]}</p>}
                </div>
              ))}
              <button
                type="submit"
                disabled={loading}
                className="w-full rounded-full bg-primary px-6 py-3 text-sm font-bold text-primary-foreground transition-transform hover:scale-[1.02] disabled:opacity-50"
              >
                {loading ? (
                  <span className="flex items-center justify-center gap-2">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Đang lưu...
                  </span>
                ) : "Lưu thông tin"}
              </button>
            </form>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

export default ProfileCompletionModal;
