import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Trophy, Star, TrendingUp, Heart, Loader2, Check, LogIn } from "lucide-react";
import { useNavigate } from "react-router-dom";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { CornerVine, MotifDivider } from "@/components/decorations/VietnameseMotifs";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { CURRENT_MONTH, formatPrice } from "@/data/mockMenu";
import GiftBoxAnimation from "@/components/GiftBoxAnimation";

interface VoteResult {
  cookie_name: string;
  vote_count: number;
}

interface MenuItem {
  id: string;
  cookie_name: string;
  image_url: string | null;
  price: number;
}

const MEDAL_COLORS = ["text-yellow-500", "text-gray-400", "text-amber-600"];
const MEDAL_BG = ["bg-yellow-50 border-yellow-200", "bg-gray-50 border-gray-200", "bg-amber-50 border-amber-200"];

const Ranking = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [votes, setVotes] = useState<VoteResult[]>([]);
  const [loading, setLoading] = useState(true);
  const [totalOrders, setTotalOrders] = useState(0);
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);

  // Vote state
  const [selectedCookie, setSelectedCookie] = useState<string | null>(null);
  const [hasVotedThisMonth, setHasVotedThisMonth] = useState(false);
  const [isVoting, setIsVoting] = useState(false);
  const [myVote, setMyVote] = useState<string | null>(null);

  // Gift box
  const [showGift, setShowGift] = useState(false);
  const [giftVoucher, setGiftVoucher] = useState<any>(null);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);

      // Fetch menu items
      const { data: menuData } = await supabase
        .from("monthly_menu")
        .select("id, cookie_name, image_url, price")
        .eq("is_active", true)
        .order("display_order");
      if (menuData) setMenuItems(menuData);

      // Fetch vote counts
      const { data: voteData } = await supabase
        .from("votes")
        .select("cookie_name");

      const countMap: Record<string, number> = {};
      voteData?.forEach((v) => {
        countMap[v.cookie_name] = (countMap[v.cookie_name] || 0) + 1;
      });

      const allCookies = (menuData || []).map((c) => ({
        cookie_name: c.cookie_name,
        vote_count: countMap[c.cookie_name] || 0,
      }));
      allCookies.sort((a, b) => b.vote_count - a.vote_count);
      setVotes(allCookies);

      // Fetch total orders
      const { count } = await supabase
        .from("orders")
        .select("*", { count: "exact", head: true });
      setTotalOrders(count || 0);

      // Check if user already voted this month
      if (user) {
        const { data: existingVote } = await supabase
          .from("votes")
          .select("cookie_name")
          .eq("user_id", user.id)
          .eq("month_year", CURRENT_MONTH)
          .maybeSingle();
        if (existingVote) {
          setHasVotedThisMonth(true);
          setMyVote(existingVote.cookie_name);
        }
      }

      setLoading(false);
    };

    fetchData();
  }, [user]);

  const handleVote = async () => {
    if (!selectedCookie || !user) return;
    setIsVoting(true);
    try {
      const cookieName = menuItems.find((c) => c.id === selectedCookie)?.cookie_name;
      if (!cookieName) return;

      const { error } = await supabase.from("votes").insert({
        cookie_name: cookieName,
        month_year: CURRENT_MONTH,
        order_code: `VOTE-${user.id.slice(0, 8)}`,
        user_id: user.id,
      });
      if (error) {
        if (error.code === "23505") {
          // Already voted (unique constraint)
          setHasVotedThisMonth(true);
          setMyVote(cookieName);
        }
        throw error;
      }

      setHasVotedThisMonth(true);
      setMyVote(cookieName);

      // Update local vote counts
      setVotes((prev) =>
        prev
          .map((v) =>
            v.cookie_name === cookieName ? { ...v, vote_count: v.vote_count + 1 } : v
          )
          .sort((a, b) => b.vote_count - a.vote_count)
      );

      // Try to claim a voucher
      await claimVoucher();
    } catch (err: any) {
      if (err.code !== "23505") {
        console.error("Vote error:", err);
      }
    } finally {
      setIsVoting(false);
    }
  };

  const claimVoucher = async () => {
    if (!user) return;
    try {
      const now = new Date();
      // Get available reward voucher templates (only reward type, active, within date range)
      const { data: templates } = await supabase
        .from("voucher_templates")
        .select("*")
        .eq("is_active", true)
        .eq("distribution_type", "reward");

      // Filter by date validity client-side
      const validTemplates = (templates || []).filter((t: any) => {
        if (t.valid_from && new Date(t.valid_from) > now) return false;
        if (t.valid_until && new Date(t.valid_until) < now) return false;
        return true;
      });

      if (validTemplates.length === 0) {
        setShowGift(true);
        setGiftVoucher(null);
        return;
      }

      // Pick random template
      const template = validTemplates[Math.floor(Math.random() * validTemplates.length)] as any;

      // Generate unique code
      const code = `NC-${template.type === "percent" ? "P" : "F"}${template.value}-${Date.now().toString(36).toUpperCase().slice(-6)}`;

      // Use valid_until from template as expiry, fallback to end of next month
      const expiresAt = template.valid_until
        ? template.valid_until
        : new Date(now.getFullYear(), now.getMonth() + 2, 0).toISOString();

      const { data: voucher, error } = await supabase
        .from("user_vouchers")
        .insert({
          user_id: user.id,
          voucher_template_id: template.id,
          code,
          expires_at: expiresAt,
        })
        .select("*")
        .single();

      if (error) {
        console.error("Voucher claim error:", error);
        setShowGift(true);
        setGiftVoucher(null);
        return;
      }

      setGiftVoucher({
        code: voucher.code,
        name: template.name,
        type: template.type,
        value: template.value,
        min_order_amount: template.min_order_amount,
        expires_at: voucher.expires_at,
      });
      setShowGift(true);
    } catch (err) {
      console.error("Claim voucher error:", err);
      setShowGift(true);
      setGiftVoucher(null);
    }
  };

  const maxVotes = Math.max(...votes.map((v) => v.vote_count), 1);

  const getCookieImage = (name: string) => {
    const cookie = menuItems.find((c) => c.cookie_name === name);
    return cookie?.image_url || "/placeholder.svg";
  };

  const getCookiePrice = (name: string) => {
    const cookie = menuItems.find((c) => c.cookie_name === name);
    return cookie?.price || 0;
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="relative pt-16">
        <CornerVine className="absolute left-0 top-16 h-32 w-32 md:h-44 md:w-44" position="top-left" />
        <CornerVine className="absolute right-0 top-16 h-32 w-32 md:h-44 md:w-44" position="top-right" />

        <div className="container mx-auto px-4 py-10 md:py-16">
          {/* Header */}
          <div className="mb-10 text-center">
            <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-full bg-primary/10">
              <Trophy className="h-7 w-7 text-primary" />
            </div>
            <h1 className="font-display text-4xl font-extrabold text-foreground md:text-5xl">
              Bảng xếp hạng
            </h1>
            <p className="mt-2 text-muted-foreground">
              Vị cookie được yêu thích nhất tháng này
            </p>
          </div>

          {/* Stats */}
          <div className="mx-auto mb-10 grid max-w-md grid-cols-2 gap-4">
            <div className="rounded-2xl border border-border bg-card p-4 text-center">
              <TrendingUp className="mx-auto mb-1 h-5 w-5 text-primary" />
              <p className="text-2xl font-bold text-foreground">{totalOrders}</p>
              <p className="text-xs text-muted-foreground">Đơn hàng</p>
            </div>
            <div className="rounded-2xl border border-border bg-card p-4 text-center">
              <Heart className="mx-auto mb-1 h-5 w-5 text-destructive" />
              <p className="text-2xl font-bold text-foreground">
                {votes.reduce((sum, v) => sum + v.vote_count, 0)}
              </p>
              <p className="text-xs text-muted-foreground">Lượt bình chọn</p>
            </div>
          </div>

          {/* Vote Section */}
          <div className="mx-auto mb-10 max-w-2xl">
            <div className="rounded-2xl border border-primary/20 bg-primary/5 p-6">
              <div className="mb-4 flex items-center gap-2">
                <Star className="h-5 w-5 text-primary" />
                <h2 className="font-display text-lg font-bold text-foreground">
                  Bình chọn vị yêu thích
                </h2>
              </div>

              {!user ? (
                <div className="text-center py-4">
                  <p className="mb-3 text-sm text-muted-foreground">Đăng nhập để bình chọn và nhận voucher!</p>
                  <button
                    onClick={() => navigate("/auth?redirect=/ranking")}
                    className="inline-flex items-center gap-2 rounded-full bg-primary px-6 py-2.5 text-sm font-bold text-primary-foreground"
                  >
                    <LogIn className="h-4 w-4" />
                    Đăng nhập
                  </button>
                </div>
              ) : hasVotedThisMonth ? (
                <motion.div
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="rounded-xl bg-primary/10 p-4"
                >
                  <div className="flex items-center gap-2 text-sm font-semibold text-primary">
                    <Check className="h-5 w-5" />
                    Bạn đã bình chọn cho <span className="font-extrabold">{myVote}</span> tháng này! 🎉
                  </div>
                  <p className="mt-2 text-xs text-muted-foreground">
                    Bạn có thể bình chọn lại vào tháng sau 📅
                  </p>
                </motion.div>
              ) : (
                <div className="space-y-2">
                  <p className="mb-3 text-sm text-muted-foreground">
                    Chọn 1 vị cookie yêu thích nhất. Mỗi tài khoản được vote 1 lần/tháng và nhận voucher!
                  </p>
                  {menuItems.map((cookie) => (
                    <button
                      key={cookie.id}
                      onClick={() => setSelectedCookie(cookie.id)}
                      className={`flex w-full items-center gap-3 rounded-xl border p-3 text-left transition-all ${
                        selectedCookie === cookie.id
                          ? "border-primary bg-card ring-1 ring-primary/30"
                          : "border-border bg-card hover:border-muted-foreground/30"
                      }`}
                    >
                      {cookie.image_url ? (
                        <img src={cookie.image_url} alt={cookie.cookie_name} className="h-10 w-10 rounded-lg object-cover" />
                      ) : (
                        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-muted text-lg">🍪</div>
                      )}
                      <span className="flex-1 text-sm font-semibold text-foreground">{cookie.cookie_name}</span>
                      <div className={`flex h-5 w-5 items-center justify-center rounded-full border-2 transition-colors ${
                        selectedCookie === cookie.id ? "border-primary bg-primary" : "border-muted-foreground/30"
                      }`}>
                        {selectedCookie === cookie.id && <Check className="h-3 w-3 text-primary-foreground" />}
                      </div>
                    </button>
                  ))}
                  <button
                    onClick={handleVote}
                    disabled={!selectedCookie || isVoting}
                    className="mt-3 w-full rounded-full bg-primary px-6 py-3 text-sm font-bold text-primary-foreground transition-transform hover:scale-[1.02] disabled:opacity-50"
                  >
                    {isVoting ? (
                      <span className="flex items-center justify-center gap-2">
                        <Loader2 className="h-4 w-4 animate-spin" />
                        Đang gửi...
                      </span>
                    ) : (
                      "Gửi bình chọn & nhận voucher 🎁"
                    )}
                  </button>
                </div>
              )}
            </div>
          </div>

          {loading ? (
            <div className="flex justify-center py-20">
              <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
            </div>
          ) : (
            <div className="mx-auto max-w-2xl space-y-4">
              {votes.map((item, index) => (
                <motion.div
                  key={item.cookie_name}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className={`flex items-center gap-4 rounded-2xl border p-4 transition-all ${
                    index < 3 ? MEDAL_BG[index] : "border-border bg-card"
                  } ${myVote === item.cookie_name ? "ring-2 ring-primary/30" : ""}`}
                >
                  {/* Rank */}
                  <div className="flex h-10 w-10 flex-shrink-0 items-center justify-center">
                    {index < 3 ? (
                      <Trophy className={`h-7 w-7 ${MEDAL_COLORS[index]}`} />
                    ) : (
                      <span className="text-lg font-bold text-muted-foreground">#{index + 1}</span>
                    )}
                  </div>

                  {/* Cookie image */}
                  <img
                    src={getCookieImage(item.cookie_name)}
                    alt={item.cookie_name}
                    className="h-14 w-14 flex-shrink-0 rounded-xl object-cover"
                  />

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <h3 className="font-display text-sm font-bold text-foreground md:text-base">
                      {item.cookie_name}
                      {myVote === item.cookie_name && (
                        <span className="ml-2 text-xs text-primary">⭐ Lựa chọn của bạn</span>
                      )}
                    </h3>
                    <p className="text-xs text-primary font-semibold">
                      {formatPrice(getCookiePrice(item.cookie_name))}
                    </p>
                    {/* Progress bar */}
                    <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-muted">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${(item.vote_count / maxVotes) * 100}%` }}
                        transition={{ delay: index * 0.1 + 0.3, duration: 0.6 }}
                        className="h-full rounded-full bg-primary"
                      />
                    </div>
                  </div>

                  {/* Vote count */}
                  <div className="flex flex-col items-center gap-1">
                    <Star className="h-4 w-4 text-primary" />
                    <span className="text-sm font-bold text-foreground">{item.vote_count}</span>
                  </div>
                </motion.div>
              ))}

              {votes.length === 0 && (
                <div className="rounded-2xl border border-border bg-card p-10 text-center">
                  <p className="text-muted-foreground">Chưa có lượt bình chọn nào. Hãy bình chọn cho vị yêu thích!</p>
                </div>
              )}
            </div>
          )}

          <MotifDivider className="mx-auto mt-12 max-w-xs" />
        </div>
      </main>
      <Footer />

      {/* Gift Box Animation */}
      <GiftBoxAnimation
        open={showGift}
        voucher={giftVoucher}
        onClose={() => setShowGift(false)}
      />
    </div>
  );
};

export default Ranking;
