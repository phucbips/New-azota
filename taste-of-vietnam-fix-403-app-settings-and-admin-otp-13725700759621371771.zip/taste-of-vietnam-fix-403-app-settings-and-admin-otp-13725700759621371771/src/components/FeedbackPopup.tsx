import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Star, X, MessageSquare, Loader2, Check } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";

const FeedbackPopup = () => {
  const { user } = useAuth();
  const [open, setOpen] = useState(false);
  const [order, setOrder] = useState<{ order_code: string; customer_name: string } | null>(null);
  const [rating, setRating] = useState(0);
  const [hover, setHover] = useState(0);
  const [comment, setComment] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);
  const [dontShowAgain, setDontShowAgain] = useState(false);

  useEffect(() => {
    if (!user) return;

    // Check if permanently dismissed
    const dismissed = localStorage.getItem(`feedback_dismissed_${user.id}`);
    if (dismissed) return;

    const checkOrders = async () => {
      // Find delivered orders without feedback
      const { data: deliveredOrders } = await supabase
        .from("orders")
        .select("order_code, customer_name")
        .eq("user_id", user.id)
        .eq("status", "delivered")
        .order("created_at", { ascending: false })
        .limit(10);

      if (!deliveredOrders || deliveredOrders.length === 0) return;

      // Check which ones already have feedback
      const codes = deliveredOrders.map((o) => o.order_code);
      const { data: existingFeedback } = await supabase
        .from("feedback")
        .select("order_code")
        .in("order_code", codes);

      const feedbackCodes = new Set((existingFeedback || []).map((f) => f.order_code));
      const unfeedbackedOrder = deliveredOrders.find((o) => !feedbackCodes.has(o.order_code));

      if (unfeedbackedOrder) {
        // Check session dismiss
        const sessionDismissed = sessionStorage.getItem(`feedback_popup_dismissed_${unfeedbackedOrder.order_code}`);
        if (!sessionDismissed) {
          setOrder(unfeedbackedOrder);
          // Small delay so it doesn't pop immediately
          setTimeout(() => setOpen(true), 2000);
        }
      }
    };

    checkOrders();
  }, [user]);

  const handleClose = () => {
    setOpen(false);
    if (order) {
      sessionStorage.setItem(`feedback_popup_dismissed_${order.order_code}`, "1");
    }
    if (dontShowAgain && user) {
      localStorage.setItem(`feedback_dismissed_${user.id}`, "1");
    }
  };

  const handleSubmit = async () => {
    if (!order || rating === 0) {
      toast.error("Vui lòng chọn số sao!");
      return;
    }
    setSubmitting(true);
    try {
      const { error } = await supabase.from("feedback").insert({
        order_code: order.order_code,
        customer_name: order.customer_name,
        rating,
        comment: comment.trim() || null,
        user_id: user?.id || null,
      } as any);
      if (error) throw error;
      setDone(true);
      toast.success("Cảm ơn bạn đã đánh giá! 💛");
      setTimeout(() => setOpen(false), 2000);
    } catch (err) {
      console.error("Feedback error:", err);
      toast.error("Không thể gửi đánh giá, thử lại sau!");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <AnimatePresence>
      {open && order && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] flex items-center justify-center bg-black/40 p-4"
          onClick={(e) => { if (e.target === e.currentTarget) handleClose(); }}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: 20 }}
            className="relative w-full max-w-md rounded-2xl border border-border bg-card p-6 shadow-xl"
          >
            {/* Close button */}
            <button
              onClick={handleClose}
              className="absolute right-3 top-3 rounded-full p-1.5 text-muted-foreground hover:bg-muted hover:text-foreground"
            >
              <X className="h-5 w-5" />
            </button>

            {done ? (
              <div className="py-8 text-center">
                <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
                  <Check className="h-8 w-8 text-primary" />
                </div>
                <h3 className="font-display text-xl font-bold text-foreground">Cảm ơn bạn!</h3>
                <p className="mt-2 text-sm text-muted-foreground">Đánh giá của bạn giúp chúng mình cải thiện hơn 💛</p>
              </div>
            ) : (
              <>
                <div className="mb-5 flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                    <MessageSquare className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-display text-lg font-bold text-foreground">Đánh giá đơn hàng</h3>
                    <p className="text-xs text-muted-foreground">Đơn #{order.order_code}</p>
                  </div>
                </div>

                {/* Star rating */}
                <div className="mb-4">
                  <p className="mb-2 text-sm font-semibold text-foreground">Bạn hài lòng thế nào?</p>
                  <div className="flex gap-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        onClick={() => setRating(star)}
                        onMouseEnter={() => setHover(star)}
                        onMouseLeave={() => setHover(0)}
                        className="p-0.5 transition-transform hover:scale-110"
                      >
                        <Star
                          className={`h-8 w-8 ${
                            star <= (hover || rating)
                              ? "fill-primary text-primary"
                              : "text-muted-foreground/30"
                          }`}
                        />
                      </button>
                    ))}
                  </div>
                </div>

                {/* Comment */}
                <textarea
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  placeholder="Nhận xét thêm (tùy chọn)..."
                  rows={3}
                  className="mb-4 w-full rounded-xl border border-border bg-background px-3 py-2 text-sm text-foreground outline-none placeholder:text-muted-foreground focus:border-primary"
                />

                {/* Don't show again */}
                <label className="mb-4 flex items-center gap-2 text-xs text-muted-foreground cursor-pointer">
                  <input
                    type="checkbox"
                    checked={dontShowAgain}
                    onChange={(e) => setDontShowAgain(e.target.checked)}
                    className="h-4 w-4 rounded border-border accent-primary"
                  />
                  Không hiển thị lại
                </label>

                <button
                  onClick={handleSubmit}
                  disabled={submitting || rating === 0}
                  className="w-full rounded-full bg-primary px-6 py-3 text-sm font-bold text-primary-foreground transition-transform hover:scale-[1.02] disabled:opacity-50"
                >
                  {submitting ? (
                    <span className="flex items-center justify-center gap-2">
                      <Loader2 className="h-4 w-4 animate-spin" />
                      Đang gửi...
                    </span>
                  ) : (
                    "Gửi đánh giá ⭐"
                  )}
                </button>
              </>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default FeedbackPopup;
