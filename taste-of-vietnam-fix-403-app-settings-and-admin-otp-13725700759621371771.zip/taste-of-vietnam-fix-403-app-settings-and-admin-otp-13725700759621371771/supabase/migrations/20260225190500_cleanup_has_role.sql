-- Cleanup old function signature to prevent overload ambiguity
DROP FUNCTION IF EXISTS public.has_role(uuid, public.app_role);

-- Ensure the text-based version is the one being used and granted
GRANT EXECUTE ON FUNCTION public.has_role(uuid, text) TO public;
