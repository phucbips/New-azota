import { useEffect, useState } from "react";
import { MapContainer, TileLayer, Marker, useMap, useMapEvents } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { ExternalLink, Maximize2, Minimize2 } from "lucide-react";
import type { GeoCoords } from "@/hooks/useGeolocation";

// Fix default marker icon
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png",
  iconUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png",
  shadowUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png",
});

const MapUpdater = ({ coords }: { coords: GeoCoords }) => {
  const map = useMap();
  useEffect(() => {
    map.setView([coords.lat, coords.lng], 16);
  }, [coords.lat, coords.lng, map]);
  return null;
};

const MapClickHandler = ({ onMapClick }: { onMapClick?: (coords: GeoCoords) => void }) => {
  useMapEvents({
    click(e) {
      onMapClick?.({ lat: e.latlng.lat, lng: e.latlng.lng });
    },
  });
  return null;
};

// Invalidate map size when expanded/collapsed
const MapResizer = ({ expanded }: { expanded: boolean }) => {
  const map = useMap();
  useEffect(() => {
    setTimeout(() => map.invalidateSize(), 300);
  }, [expanded, map]);
  return null;
};

interface AddressMapProps {
  coords: GeoCoords;
  className?: string;
  onMapClick?: (coords: GeoCoords) => void;
}

const AddressMap = ({ coords, className = "", onMapClick }: AddressMapProps) => {
  const [expanded, setExpanded] = useState(false);
  const googleMapsUrl = `https://www.google.com/maps/search/?api=1&query=${coords.lat},${coords.lng}`;

  return (
    <div
      className={`mt-2 overflow-hidden rounded-xl border border-border transition-all duration-300 ${
        expanded ? "fixed inset-4 z-50 mt-0 shadow-2xl" : className
      }`}
    >
      {/* Backdrop */}
      {expanded && (
        <div
          className="fixed inset-0 z-[-1] bg-black/50"
          onClick={() => setExpanded(false)}
        />
      )}

      {onMapClick && (
        <p className="bg-muted px-3 py-1.5 text-xs text-muted-foreground text-center">
          👆 Nhấn vào bản đồ để chọn vị trí chính xác
        </p>
      )}

      <div className={`w-full transition-all duration-300 ${expanded ? "h-[calc(100%-80px)]" : "h-48"}`}>
        <MapContainer
          center={[coords.lat, coords.lng]}
          zoom={16}
          scrollWheelZoom={expanded}
          className="h-full w-full"
          style={{ height: "100%", width: "100%", cursor: onMapClick ? "crosshair" : undefined }}
        >
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
          <Marker position={[coords.lat, coords.lng]} />
          <MapUpdater coords={coords} />
          <MapResizer expanded={expanded} />
          {onMapClick && <MapClickHandler onMapClick={onMapClick} />}
        </MapContainer>
      </div>

      <div className="flex items-center justify-between bg-card px-3 py-2">
        <p className="text-[10px] text-muted-foreground font-mono select-all">
          {coords.lat.toFixed(6)}, {coords.lng.toFixed(6)}
        </p>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setExpanded((v) => !v)}
            className="flex items-center gap-1.5 rounded-lg bg-secondary px-3 py-1.5 text-xs font-semibold text-secondary-foreground transition-colors hover:bg-secondary/80"
          >
            {expanded ? <Minimize2 className="h-3.5 w-3.5" /> : <Maximize2 className="h-3.5 w-3.5" />}
            {expanded ? "Thu nhỏ" : "Phóng to"}
          </button>
          <a
            href={googleMapsUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 rounded-lg bg-primary/10 px-3 py-1.5 text-xs font-semibold text-primary transition-colors hover:bg-primary/20"
          >
            <ExternalLink className="h-3.5 w-3.5" />
            Mở Google Maps
          </a>
        </div>
      </div>
    </div>
  );
};

export default AddressMap;
