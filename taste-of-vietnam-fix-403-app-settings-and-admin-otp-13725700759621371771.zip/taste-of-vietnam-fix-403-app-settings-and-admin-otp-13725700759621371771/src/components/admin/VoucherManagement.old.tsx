import { useState, useEffect } from "react";
import { PlusCircle, Trash2, Loader2, Ticket, CalendarIcon, Copy } from "lucide-react";
import { format } from "date-fns";
import { supabase } from "@/integrations/supabase/client";
import { formatPrice } from "@/data/mockMenu";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Button } from "@/components/ui/button";

interface VoucherTemplate {
  id: string;
  name: string;
  type: string;
  value: number;
  min_order_amount: number;
  max_quantity: number;
  month_year: string;
  is_active: boolean;
  created_at: string;
  distribution_type: string;
  valid_from: string | null;
  valid_until: string | null;
  promo_code: string | null;
}

const generatePromoCode = () => {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let code = "PROMO-";
  for (let i = 0; i < 6; i++) code += chars.charAt(Math.floor(Math.random() * chars.length));
  return code;
};

const VoucherManagement = () => {
  const [templates, setTemplates] = useState<VoucherTemplate[]>([]);
  const [usageCounts, setUsageCounts] = useState<Record<string, number>>({});
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({
    name: "",
    type: "percent" as "percent" | "fixed",
    value: 10,
    min_order_amount: 0,
    max_quantity: 100,
    distribution_type: "reward" as "reward" | "promo",
    valid_from: null as Date | null,
    valid_until: null as Date | null,
    promo_code: "",
  });
  const [saving, setSaving] = useState(false);

  const fetchTemplates = async () => {
    setLoading(true);
    const { data } = await supabase
      .from("voucher_templates")
      .select("*")
      .order("created_at", { ascending: false });
    if (data) {
      const tpls = data as unknown as VoucherTemplate[];
      setTemplates(tpls);
      // Fetch usage counts for all templates
      const ids = tpls.map((t) => t.id);
      if (ids.length > 0) {
        const { data: vouchers } = await supabase
          .from("user_vouchers")
          .select("voucher_template_id")
          .in("voucher_template_id", ids)
          .eq("is_used", true);
        const counts: Record<string, number> = {};
        (vouchers || []).forEach((v: any) => {
          counts[v.voucher_template_id] = (counts[v.voucher_template_id] || 0) + 1;
        });
        setUsageCounts(counts);
      }
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchTemplates();
  }, []);

  const handleCreate = async () => {
    if (!form.name.trim()) {
      toast.error("Vui lòng nhập tên voucher");
      return;
    }
    if (!form.valid_from || !form.valid_until) {
      toast.error("Vui lòng chọn ngày hiệu lực và hết hạn");
      return;
    }
    if (form.valid_until <= form.valid_from) {
      toast.error("Ngày hết hạn phải sau ngày hiệu lực");
      return;
    }
    if (form.distribution_type === "promo" && !form.promo_code.trim()) {
      toast.error("Vui lòng nhập mã promo");
      return;
    }
    setSaving(true);

    const monthYear = format(form.valid_from, "MM/yyyy");

    const { error } = await supabase.from("voucher_templates").insert({
      name: form.name.trim(),
      type: form.type,
      value: form.value,
      min_order_amount: form.min_order_amount,
      max_quantity: form.max_quantity,
      month_year: monthYear,
      distribution_type: form.distribution_type,
      valid_from: form.valid_from.toISOString(),
      valid_until: form.valid_until.toISOString(),
      promo_code: form.distribution_type === "promo" ? form.promo_code.trim().toUpperCase() : null,
    } as any);
    if (error) {
      if (error.code === "23505") {
        toast.error("Mã promo đã tồn tại, vui lòng chọn mã khác");
      } else {
        toast.error("Lỗi tạo voucher template");
      }
    } else {
      toast.success("Tạo voucher template thành công!");
      setShowForm(false);
      setForm({
        name: "", type: "percent", value: 10, min_order_amount: 0, max_quantity: 100,
        distribution_type: "reward", valid_from: null, valid_until: null, promo_code: "",
      });
      fetchTemplates();
    }
    setSaving(false);
  };

  const handleDelete = async (id: string) => {
    const used = usageCounts[id] || 0;
    const msg = used > 0
      ? `Voucher này đã có ${used} lượt sử dụng. Xóa sẽ xóa luôn dữ liệu liên quan. Tiếp tục?`
      : "Xóa voucher template này?";
    if (!confirm(msg)) return;

    // 1. Xóa user_vouchers liên quan trước
    const { error: uvError } = await supabase
      .from("user_vouchers")
      .delete()
      .eq("voucher_template_id", id);
    if (uvError) {
      toast.error("Lỗi xóa voucher người dùng: " + uvError.message);
      return;
    }

    // 2. Xóa voucher template
    const { error } = await supabase.from("voucher_templates").delete().eq("id", id);
    if (error) {
      toast.error("Lỗi xóa template: " + error.message);
    } else {
      toast.success("Đã xóa voucher template");
      fetchTemplates();
    }
  };

  const toggleActive = async (id: string, current: boolean) => {
    await supabase.from("voucher_templates").update({ is_active: !current } as any).eq("id", id);
    setTemplates((prev) => prev.map((t) => t.id === id ? { ...t, is_active: !current } : t));
  };

  const copyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    toast.success("Đã copy mã: " + code);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">
          Quản lý voucher: Promo (phát mã) và Reward (phần thưởng vote).
        </p>
        <button
          onClick={() => setShowForm(!showForm)}
          className="flex items-center gap-2 rounded-xl bg-primary px-4 py-2.5 text-sm font-bold text-primary-foreground"
        >
          <PlusCircle className="h-4 w-4" />
          Thêm mới
        </button>
      </div>

      {showForm && (
        <div className="rounded-2xl border border-primary/20 bg-primary/5 p-6 space-y-4">
          <h3 className="font-display text-base font-bold text-foreground">Tạo Voucher Template</h3>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            {/* Distribution type */}
            <div>
              <label className="mb-1 block text-xs font-semibold text-muted-foreground">Loại phát</label>
              <select
                value={form.distribution_type}
                onChange={(e) => {
                  const dt = e.target.value as "reward" | "promo";
                  setForm((p) => ({
                    ...p,
                    distribution_type: dt,
                    promo_code: dt === "promo" ? generatePromoCode() : "",
                  }));
                }}
                className="w-full rounded-xl border border-border bg-background px-3 py-2 text-sm outline-none focus:border-primary"
              >
                <option value="reward">🎁 Phần thưởng Vote (Reward)</option>
                <option value="promo">📢 Phát mã (Promo)</option>
              </select>
            </div>
            {/* Name */}
            <div>
              <label className="mb-1 block text-xs font-semibold text-muted-foreground">Tên</label>
              <input
                value={form.name}
                onChange={(e) => setForm((p) => ({ ...p, name: e.target.value }))}
                placeholder="VD: Giảm 10% đơn từ 100k"
                className="w-full rounded-xl border border-border bg-background px-3 py-2 text-sm outline-none focus:border-primary"
              />
            </div>
            {/* Promo code (only for promo) */}
            {form.distribution_type === "promo" && (
              <div>
                <label className="mb-1 block text-xs font-semibold text-muted-foreground">Mã Promo</label>
                <div className="flex gap-2">
                  <input
                    value={form.promo_code}
                    onChange={(e) => setForm((p) => ({ ...p, promo_code: e.target.value.toUpperCase() }))}
                    placeholder="VD: WELCOME2024"
                    className="flex-1 rounded-xl border border-border bg-background px-3 py-2 text-sm outline-none focus:border-primary font-mono"
                  />
                  <button
                    type="button"
                    onClick={() => setForm((p) => ({ ...p, promo_code: generatePromoCode() }))}
                    className="rounded-xl border border-border bg-background px-3 py-2 text-xs text-muted-foreground hover:bg-muted"
                  >
                    Random
                  </button>
                </div>
              </div>
            )}
            {/* Type */}
            <div>
              <label className="mb-1 block text-xs font-semibold text-muted-foreground">Loại giảm</label>
              <select
                value={form.type}
                onChange={(e) => setForm((p) => ({ ...p, type: e.target.value as any }))}
                className="w-full rounded-xl border border-border bg-background px-3 py-2 text-sm outline-none focus:border-primary"
              >
                <option value="percent">Giảm %</option>
                <option value="fixed">Giảm cố định (VNĐ)</option>
              </select>
            </div>
            {/* Value */}
            <div>
              <label className="mb-1 block text-xs font-semibold text-muted-foreground">
                Giá trị ({form.type === "percent" ? "%" : "VNĐ"})
              </label>
              <input
                type="number"
                value={form.value}
                onChange={(e) => setForm((p) => ({ ...p, value: Number(e.target.value) }))}
                className="w-full rounded-xl border border-border bg-background px-3 py-2 text-sm outline-none focus:border-primary"
              />
            </div>
            {/* Min order */}
            <div>
              <label className="mb-1 block text-xs font-semibold text-muted-foreground">Đơn tối thiểu (VNĐ)</label>
              <input
                type="number"
                value={form.min_order_amount}
                onChange={(e) => setForm((p) => ({ ...p, min_order_amount: Number(e.target.value) }))}
                className="w-full rounded-xl border border-border bg-background px-3 py-2 text-sm outline-none focus:border-primary"
              />
            </div>
            {/* Max quantity */}
            <div>
              <label className="mb-1 block text-xs font-semibold text-muted-foreground">Số lượng tối đa</label>
              <input
                type="number"
                value={form.max_quantity}
                onChange={(e) => setForm((p) => ({ ...p, max_quantity: Number(e.target.value) }))}
                className="w-full rounded-xl border border-border bg-background px-3 py-2 text-sm outline-none focus:border-primary"
              />
            </div>
            {/* Valid from - Date Picker */}
            <div>
              <label className="mb-1 block text-xs font-semibold text-muted-foreground">Hiệu lực từ</label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal rounded-xl",
                      !form.valid_from && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {form.valid_from ? format(form.valid_from, "dd/MM/yyyy") : "Chọn ngày"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={form.valid_from || undefined}
                    onSelect={(date) => setForm((p) => ({ ...p, valid_from: date || null }))}
                    initialFocus
                    className={cn("p-3 pointer-events-auto")}
                  />
                </PopoverContent>
              </Popover>
            </div>
            {/* Valid until - Date Picker */}
            <div>
              <label className="mb-1 block text-xs font-semibold text-muted-foreground">Hết hạn ngày</label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal rounded-xl",
                      !form.valid_until && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {form.valid_until ? format(form.valid_until, "dd/MM/yyyy") : "Chọn ngày"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={form.valid_until || undefined}
                    onSelect={(date) => setForm((p) => ({ ...p, valid_until: date || null }))}
                    disabled={(date) => form.valid_from ? date <= form.valid_from : false}
                    initialFocus
                    className={cn("p-3 pointer-events-auto")}
                  />
                </PopoverContent>
              </Popover>
            </div>
          </div>
          <div className="flex gap-3">
            <button
              onClick={handleCreate}
              disabled={saving}
              className="rounded-xl bg-primary px-6 py-2.5 text-sm font-bold text-primary-foreground disabled:opacity-50"
            >
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : "Tạo"}
            </button>
            <button
              onClick={() => setShowForm(false)}
              className="rounded-xl border border-border px-6 py-2.5 text-sm font-semibold text-foreground"
            >
              Hủy
            </button>
          </div>
        </div>
      )}

      {loading ? (
        <div className="flex justify-center py-10">
          <Loader2 className="h-6 w-6 animate-spin text-primary" />
        </div>
      ) : templates.length === 0 ? (
        <div className="rounded-2xl border border-border bg-card p-10 text-center text-muted-foreground">
          <Ticket className="mx-auto mb-3 h-10 w-10 text-muted-foreground/50" />
          <p>Chưa có voucher template nào</p>
        </div>
      ) : (
        <div className="space-y-3">
          {templates.map((t) => {
            const used = usageCounts[t.id] || 0;
            return (
              <div
                key={t.id}
                className={`rounded-2xl border p-4 transition-all ${
                  t.is_active ? "border-border bg-card" : "border-border bg-muted/50 opacity-60"
                }`}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-display text-sm font-bold text-foreground">{t.name}</h4>
                      <span className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${
                        t.distribution_type === "promo"
                          ? "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300"
                          : "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300"
                      }`}>
                        {t.distribution_type === "promo" ? "📢 Promo" : "🎁 Reward"}
                      </span>
                    </div>
                    <div className="mt-1 flex flex-wrap gap-2 text-xs">
                      <span className="rounded-full bg-primary/10 px-2 py-0.5 font-semibold text-primary">
                        {t.type === "percent" ? `Giảm ${t.value}%` : `Giảm ${formatPrice(t.value)}`}
                      </span>
                      <span className="rounded-full bg-muted px-2 py-0.5 text-muted-foreground">
                        Đơn từ {formatPrice(t.min_order_amount)}
                      </span>
                      {t.valid_from && t.valid_until && (
                        <span className="rounded-full bg-muted px-2 py-0.5 text-muted-foreground">
                          {format(new Date(t.valid_from), "dd/MM/yyyy")} → {format(new Date(t.valid_until), "dd/MM/yyyy")}
                        </span>
                      )}
                      <span className={`rounded-full px-2 py-0.5 font-semibold ${
                        used >= t.max_quantity
                          ? "bg-destructive/10 text-destructive"
                          : "bg-muted text-muted-foreground"
                      }`}>
                        Đã dùng: {used}/{t.max_quantity}
                      </span>
                      {t.promo_code && (
                        <button
                          onClick={() => copyCode(t.promo_code!)}
                          className="flex items-center gap-1 rounded-full bg-blue-50 px-2 py-0.5 font-mono text-blue-700 hover:bg-blue-100 dark:bg-blue-900/30 dark:text-blue-300"
                        >
                          <Copy className="h-3 w-3" />
                          {t.promo_code}
                        </button>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => toggleActive(t.id, t.is_active)}
                      className={`rounded-full px-3 py-1 text-xs font-semibold ${
                        t.is_active ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground"
                      }`}
                    >
                      {t.is_active ? "Đang bật" : "Đã tắt"}
                    </button>
                    <button
                      onClick={() => handleDelete(t.id)}
                      className="rounded-lg p-1.5 text-muted-foreground hover:bg-destructive/10 hover:text-destructive"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default VoucherManagement;
