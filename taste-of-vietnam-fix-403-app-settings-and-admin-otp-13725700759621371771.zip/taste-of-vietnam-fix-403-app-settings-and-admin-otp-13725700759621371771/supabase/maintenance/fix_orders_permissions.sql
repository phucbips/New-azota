-- ==============================================================================
-- BẢO MẬT & KHÔI PHỤC RLS CHO BẢNG ORDERS & ORDER_ITEMS (VERSION 2 - AN TOÀN)
-- Sửa lỗi: "permission denied for table orders" nhưng không rò rỉ dữ liệu (Data Leakage)
-- ==============================================================================

-- 1. Cấp lại quyền (Grants) cho Khách và Người dùng đăng nhập
GRANT SELECT, INSERT, UPDATE ON public.orders TO anon, authenticated;
GRANT SELECT, INSERT ON public.order_items TO anon, authenticated;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO anon, authenticated;

-- 2. Bật Row Level Security (RLS)
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;

-- 3. Xóa các Policy cũ để tránh xung đột
DO $$
BEGIN
    EXECUTE 'DROP POLICY IF EXISTS "Public_Select_Orders" ON public.orders';
    EXECUTE 'DROP POLICY IF EXISTS "Auth_Select_Own_Orders" ON public.orders';
    EXECUTE 'DROP POLICY IF EXISTS "Public_Insert_Orders" ON public.orders';
    EXECUTE 'DROP POLICY IF EXISTS "Public_Update_Orders" ON public.orders';
    EXECUTE 'DROP POLICY IF EXISTS "Admin_All_Orders" ON public.orders';

    EXECUTE 'DROP POLICY IF EXISTS "Public_Select_OrderItems" ON public.order_items';
    EXECUTE 'DROP POLICY IF EXISTS "Auth_Select_Own_OrderItems" ON public.order_items';
    EXECUTE 'DROP POLICY IF EXISTS "Public_Insert_OrderItems" ON public.order_items';
    EXECUTE 'DROP POLICY IF EXISTS "Admin_All_OrderItems" ON public.order_items';
EXCEPTION WHEN OTHERS THEN
END
$$;

-- ==============================================================================
-- 4. BẢNG `orders`
-- ==============================================================================
-- a) Select: Chỉ cho phép người dùng xem đơn hàng của CHÍNH HỌ.
-- (Ngăn chặn việc dùng mã đơn hàng để cào dữ liệu của người khác).
CREATE POLICY "Auth_Select_Own_Orders"
ON public.orders FOR SELECT TO authenticated
USING (auth.uid() = user_id);

-- b) Insert: Bất kỳ ai cũng có thể tạo đơn hàng mới (Kể cả khách vãng lai không đăng nhập)
CREATE POLICY "Public_Insert_Orders"
ON public.orders FOR INSERT WITH CHECK (true);

-- c) Update: Ai cũng có thể update đơn hàng của họ (Ví dụ: khách tự hủy đơn chưa thanh toán - nếu logic FE có gọi)
CREATE POLICY "Public_Update_Orders"
ON public.orders FOR UPDATE USING (
    -- Cho phép update nếu họ là chủ đơn hàng, hoặc đơn hàng vô danh (user_id IS NULL)
    -- Nếu web có tracking vô danh bằng session, FE phải tự đảm bảo bảo mật.
    auth.uid() = user_id OR user_id IS NULL
);

-- d) Admin Full Access: Admin quản lý tất cả
CREATE POLICY "Admin_All_Orders"
ON public.orders FOR ALL TO authenticated
USING (public.has_role(auth.uid(), 'admin'::text));

-- ==============================================================================
-- 5. BẢNG `order_items`
-- ==============================================================================
-- a) Select: Giống orders, chỉ xem item của đơn hàng thuộc về mình
CREATE POLICY "Auth_Select_Own_OrderItems"
ON public.order_items FOR SELECT TO authenticated
USING (
    EXISTS (
        SELECT 1 FROM public.orders
        WHERE orders.id = order_items.order_id
        AND orders.user_id = auth.uid()
    )
);

-- b) Insert: Bất kỳ ai cũng có thể thêm món vào đơn
CREATE POLICY "Public_Insert_OrderItems"
ON public.order_items FOR INSERT WITH CHECK (true);

-- c) Admin Full Access
CREATE POLICY "Admin_All_OrderItems"
ON public.order_items FOR ALL TO authenticated
USING (public.has_role(auth.uid(), 'admin'::text));
