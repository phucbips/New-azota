import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";

export interface Profile {
  id: string;
  user_id: string;
  full_name: string | null;
  phone: string | null;
  default_address: string | null;
}

export const useProfile = () => {
  const { user } = useAuth();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [needsCompletion, setNeedsCompletion] = useState(false);

  const fetchProfile = async () => {
    if (!user) {
      setProfile(null);
      setLoading(false);
      return;
    }
    const { data, error } = await supabase
      .from("profiles")
      .select("*")
      .eq("user_id", user.id)
      .maybeSingle();

    if (!error && data) {
      setProfile(data);
      setNeedsCompletion(!data.phone || !data.default_address);
    } else if (!data) {
      // User has no profile record yet - Auto create it!
      const fallbackName = user.user_metadata?.full_name || user.user_metadata?.name || user.email?.split("@")[0] || "Người dùng mới";
      const { data: newProfile, error: insertError } = await supabase
        .from("profiles")
        .insert({
          user_id: user.id,
          full_name: fallbackName
        } as any)
        .select()
        .maybeSingle();

      if (newProfile && !insertError) {
        setProfile(newProfile);
        setNeedsCompletion(true); // Still needs phone/address
      } else {
        setNeedsCompletion(true);
      }
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchProfile();
  }, [user]);

  return { profile, loading, needsCompletion, refetch: fetchProfile };
};
