import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { createHmac } from "node:crypto";
import { getRequiredEnv, corsHeaders } from "../_shared/utils.ts";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { orderCode, amount, description, items, returnUrl, cancelUrl } =
      await req.json();

    if (!orderCode || !amount) {
      return new Response(
        JSON.stringify({ error: "Missing orderCode or amount" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Try to read PayOS config from app_settings table first, fallback to env
    const serviceClient = createClient(
      getRequiredEnv("SUPABASE_URL"),
      getRequiredEnv("SUPABASE_SERVICE_ROLE_KEY")
    );

    const { data: settingsData } = await serviceClient
      .from("app_settings")
      .select("key, value")
      .in("key", ["PAYOS_CLIENT_ID", "PAYOS_API_KEY", "PAYOS_CHECKSUM_KEY"]);

    const settingsMap: Record<string, string> = {};
    if (settingsData) {
      for (const s of settingsData) {
        settingsMap[s.key] = s.value;
      }
    }

    const clientId = settingsMap["PAYOS_CLIENT_ID"] || getRequiredEnv("PAYOS_CLIENT_ID");
    const apiKey = settingsMap["PAYOS_API_KEY"] || getRequiredEnv("PAYOS_API_KEY");
    const checksumKey = settingsMap["PAYOS_CHECKSUM_KEY"] || getRequiredEnv("PAYOS_CHECKSUM_KEY");

    // Generate orderCode as number (last 8 digits of timestamp)
    const orderCodeNum = Number(String(Date.now()).slice(-8));

    // Create checksum: amount, cancelUrl, description, orderCode, returnUrl
    const checksumData = `amount=${amount}&cancelUrl=${cancelUrl}&description=${description}&orderCode=${orderCodeNum}&returnUrl=${returnUrl}`;
    const signature = createHmac("sha256", checksumKey)
      .update(checksumData)
      .digest("hex");

    const body = {
      orderCode: orderCodeNum,
      amount,
      description: description || `Nova Cookie ${orderCode}`,
      items: items || [],
      returnUrl,
      cancelUrl,
      signature,
    };

    const response = await fetch(
      "https://api-merchant.payos.vn/v2/payment-requests",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-client-id": clientId,
          "x-api-key": apiKey,
        },
        body: JSON.stringify(body),
      }
    );

    const result = await response.json();

    if (result.code !== "00") {
      console.error("PayOS error:", result);
      return new Response(JSON.stringify({ error: result.desc || "PayOS error", details: result }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ ...result.data, orderCodeNum }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("Error:", error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
