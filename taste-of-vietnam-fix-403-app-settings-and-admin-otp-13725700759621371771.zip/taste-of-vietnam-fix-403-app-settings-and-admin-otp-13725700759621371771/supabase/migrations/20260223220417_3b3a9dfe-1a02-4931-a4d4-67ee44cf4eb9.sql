
-- Add payment_deadline column for 10-minute transfer timeout
ALTER TABLE public.orders ADD COLUMN payment_deadline timestamp with time zone DEFAULT NULL;

-- Add payment_status to track if transfer orders are paid
ALTER TABLE public.orders ADD COLUMN payment_status text NOT NULL DEFAULT 'pending';
