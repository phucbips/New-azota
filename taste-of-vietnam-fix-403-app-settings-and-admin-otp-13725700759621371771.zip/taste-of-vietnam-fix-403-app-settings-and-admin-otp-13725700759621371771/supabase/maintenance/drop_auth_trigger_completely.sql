-- ==============================================================================
-- GIẢI PHÁP TỐI THƯỢNG: XÓA BỎ HOÀN TOÀN TRIGGER TRÊN BẢNG AUTH.USERS
-- ==============================================================================
-- Nguyên nhân: Dù đã bọc Exception, một số dự án Supabase bị kẹt cấu hình ở schema "auth"
-- khiến Postgres từ chối gọi bất kỳ trigger nào cập nhật sang schema "public",
-- dẫn đến lỗi "Database error saving new user" liên tục khi đăng nhập Google/Tạo tài khoản.
--
-- Cách giải quyết: Chúng ta sẽ DROP hoàn toàn trigger này.
-- Việc tạo thông tin Profile sẽ được đẩy về phía Frontend (App sẽ tự động tạo khi user đăng nhập).

-- 1. Xóa Trigger
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;

-- 2. Xóa Function
DROP FUNCTION IF EXISTS public.handle_new_user() CASCADE;

-- 3. Đảm bảo User có thể TỰ TẠO Profile và Role từ Frontend (Bật RLS mở Insert cho chính họ)
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- 3a. Quyền cho Profiles
DROP POLICY IF EXISTS "User_Insert_Own_Profile" ON public.profiles;
CREATE POLICY "User_Insert_Own_Profile"
ON public.profiles
FOR INSERT
WITH CHECK (auth.uid() = user_id);

-- 3b. Quyền cho User Roles (Cho phép user tự Insert quyền 'user' nếu họ chưa có quyền nào)
DROP POLICY IF EXISTS "User_Insert_Own_Role" ON public.user_roles;
CREATE POLICY "User_Insert_Own_Role"
ON public.user_roles
FOR INSERT
WITH CHECK (
    auth.uid() = user_id AND
    role = 'user' -- Bắt buộc chỉ được nhận quyền 'user' cơ bản
);
