-- ==============================================================================
-- BẢN VÁ TỐI THƯỢNG: CỦNG CỐ QUYỀN ADMIN & BAKER
-- Chạy đoạn mã này trong Supabase SQL Editor để fix toàn bộ lỗi quyền 403
-- ==============================================================================

-- 1. ĐẢM BẢO HÀM HAS_ROLE HOẠT ĐỘNG HOÀN HẢO (KHÔNG DROP ĐỂ TRÁNH LỖI)
-- Hàm gốc nhận Enum (Dành cho nội bộ DB)
CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM public.user_roles ur
    WHERE ur.user_id = _user_id AND ur.role = _role
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Hàm overload nhận Text (Dành cho Frontend, API, Edge Functions gọi vào)
CREATE OR REPLACE FUNCTION public.has_role(user_id uuid, role_name text)
RETURNS boolean AS $$
BEGIN
  -- Ép kiểu an toàn từ Text sang Enum, gọi lại hàm gốc
  RETURN public.has_role(user_id, role_name::public.app_role);
EXCEPTION WHEN invalid_text_representation THEN
  RETURN false;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO public;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, text) TO public;

-- 2. RESET VÀ CẤP QUYỀN CHO ADMIN VÀ BAKER TRÊN CÁC BẢNG QUAN TRỌNG
-- Sử dụng 'admin'::app_role (ép kiểu cứng) để đảm bảo không lỗi type.

-- Bảng Orders (Đơn hàng)
DROP POLICY IF EXISTS "Admins can update orders" ON public.orders;
CREATE POLICY "Admins can update orders" ON public.orders FOR UPDATE TO authenticated
USING (public.has_role(auth.uid(), 'admin'::app_role) OR public.has_role(auth.uid(), 'baker'::app_role));

DROP POLICY IF EXISTS "Admins can view all orders" ON public.orders;
CREATE POLICY "Admins can view all orders" ON public.orders FOR SELECT TO authenticated
USING (public.has_role(auth.uid(), 'admin'::app_role) OR public.has_role(auth.uid(), 'baker'::app_role));

-- Bảng Monthly Menu (Menu)
DROP POLICY IF EXISTS "Bakers can update menu" ON public.monthly_menu;
CREATE POLICY "Bakers can update menu" ON public.monthly_menu FOR UPDATE TO authenticated
USING (public.has_role(auth.uid(), 'admin'::app_role) OR public.has_role(auth.uid(), 'baker'::app_role));

DROP POLICY IF EXISTS "Bakers can insert menu" ON public.monthly_menu;
CREATE POLICY "Bakers can insert menu" ON public.monthly_menu FOR INSERT TO authenticated
WITH CHECK (public.has_role(auth.uid(), 'admin'::app_role) OR public.has_role(auth.uid(), 'baker'::app_role));

DROP POLICY IF EXISTS "Admins can delete menu" ON public.monthly_menu;
CREATE POLICY "Admins can delete menu" ON public.monthly_menu FOR DELETE TO authenticated
USING (public.has_role(auth.uid(), 'admin'::app_role));

-- Bảng Financial Transactions (Tài chính)
DROP POLICY IF EXISTS "Admins can select financial_transactions" ON public.financial_transactions;
CREATE POLICY "Admins can select financial_transactions" ON public.financial_transactions FOR SELECT TO authenticated
USING (public.has_role(auth.uid(), 'admin'::app_role));

DROP POLICY IF EXISTS "Admins can insert financial_transactions" ON public.financial_transactions;
CREATE POLICY "Admins can insert financial_transactions" ON public.financial_transactions FOR INSERT TO authenticated
WITH CHECK (public.has_role(auth.uid(), 'admin'::app_role));

DROP POLICY IF EXISTS "Admins can update financial_transactions" ON public.financial_transactions;
CREATE POLICY "Admins can update financial_transactions" ON public.financial_transactions FOR UPDATE TO authenticated
USING (public.has_role(auth.uid(), 'admin'::app_role));

DROP POLICY IF EXISTS "Admins can delete financial_transactions" ON public.financial_transactions;
CREATE POLICY "Admins can delete financial_transactions" ON public.financial_transactions FOR DELETE TO authenticated
USING (public.has_role(auth.uid(), 'admin'::app_role));

-- Bảng App Settings (Cài đặt)
DROP POLICY IF EXISTS "Admins can manage settings" ON public.app_settings;
CREATE POLICY "Admins can manage settings" ON public.app_settings FOR ALL TO authenticated
USING (public.has_role(auth.uid(), 'admin'::app_role));

-- Bảng User Roles (Quản lý User)
DROP POLICY IF EXISTS "Admins can manage all roles" ON public.user_roles;
CREATE POLICY "Admins can manage all roles" ON public.user_roles FOR ALL TO authenticated
USING (public.has_role(auth.uid(), 'admin'::app_role));

-- Bảng Order Surcharges (Phụ phí)
DROP POLICY IF EXISTS "Admins can insert surcharges" ON public.order_surcharges;
CREATE POLICY "Admins can insert surcharges" ON public.order_surcharges FOR INSERT TO authenticated
WITH CHECK (public.has_role(auth.uid(), 'admin'::app_role));

DROP POLICY IF EXISTS "Admins can update surcharges" ON public.order_surcharges;
CREATE POLICY "Admins can update surcharges" ON public.order_surcharges FOR UPDATE TO authenticated
USING (public.has_role(auth.uid(), 'admin'::app_role));

DROP POLICY IF EXISTS "Admins can delete surcharges" ON public.order_surcharges;
CREATE POLICY "Admins can delete surcharges" ON public.order_surcharges FOR DELETE TO authenticated
USING (public.has_role(auth.uid(), 'admin'::app_role));

-- Bảng Voucher Templates
DROP POLICY IF EXISTS "Admins can insert voucher templates" ON public.voucher_templates;
CREATE POLICY "Admins can insert voucher templates" ON public.voucher_templates FOR INSERT TO authenticated
WITH CHECK (public.has_role(auth.uid(), 'admin'::app_role));

DROP POLICY IF EXISTS "Admins can update voucher templates" ON public.voucher_templates;
CREATE POLICY "Admins can update voucher templates" ON public.voucher_templates FOR UPDATE TO authenticated
USING (public.has_role(auth.uid(), 'admin'::app_role));

DROP POLICY IF EXISTS "Admins can delete voucher templates" ON public.voucher_templates;
CREATE POLICY "Admins can delete voucher templates" ON public.voucher_templates FOR DELETE TO authenticated
USING (public.has_role(auth.uid(), 'admin'::app_role));

-- Bảng User Vouchers
DROP POLICY IF EXISTS "Admins can view all vouchers" ON public.user_vouchers;
CREATE POLICY "Admins can view all vouchers" ON public.user_vouchers FOR SELECT TO authenticated
USING (public.has_role(auth.uid(), 'admin'::app_role));

DROP POLICY IF EXISTS "Admins can manage vouchers" ON public.user_vouchers;
CREATE POLICY "Admins can manage vouchers" ON public.user_vouchers FOR ALL TO authenticated
USING (public.has_role(auth.uid(), 'admin'::app_role));

-- Reload lại toàn bộ cấu hình Supabase
NOTIFY pgrst, 'reload config';
