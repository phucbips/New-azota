import { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import {
  Cookie, Package, Plus, Pencil, Trash2, Loader2, Save, X,
  Image as ImageIcon, ChefHat, Clock, Truck, CheckCircle2, Upload, Crop
} from "lucide-react";
import ImageCropper from "@/components/ImageCropper";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useRole } from "@/hooks/useRole";
import { formatPrice, CURRENT_MONTH } from "@/data/mockMenu";
import {
  SidebarProvider, Sidebar, SidebarContent, SidebarGroup,
  SidebarGroupLabel, SidebarGroupContent, SidebarMenu,
  SidebarMenuItem, SidebarMenuButton, SidebarTrigger
} from "@/components/ui/sidebar";

const STATUS_MAP: Record<string, { label: string; icon: React.ElementType; color: string }> = {
  pending: { label: "Chờ xác nhận", icon: Clock, color: "text-yellow-600 bg-yellow-50" },
  preparing: { label: "Đang chuẩn bị", icon: ChefHat, color: "text-orange-500 bg-orange-50" },
  delivering: { label: "Đang giao", icon: Truck, color: "text-blue-500 bg-blue-50" },
  delivered: { label: "Đã giao", icon: CheckCircle2, color: "text-primary bg-primary/10" },
};

interface MenuItem {
  id: string;
  cookie_name: string;
  description: string | null;
  origin: string | null;
  price: number;
  image_url: string | null;
  stock: number;
  month_year: string;
  display_order: number;
  is_active: boolean;
}

type Tab = "menu" | "orders";

const BakerDashboard = () => {
  const { user, loading: authLoading } = useAuth();
  const { isBaker, isAdmin, loading: roleLoading } = useRole();
  const navigate = useNavigate();
  const [tab, setTab] = useState<Tab>("menu");
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [editItem, setEditItem] = useState<Partial<MenuItem> | null>(null);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [dragging, setDragging] = useState(false);
  const [cropSrc, setCropSrc] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const startCrop = (file: File) => {
    if (!file.type.startsWith("image/")) return;
    const reader = new FileReader();
    reader.onload = () => setCropSrc(reader.result as string);
    reader.readAsDataURL(file);
  };

  const handleCroppedImage = async (blob: Blob) => {
    setCropSrc(null);
    setUploading(true);
    try {
      const formData = new FormData();
      formData.append("file", blob, "cropped.jpg");

      const { data, error } = await supabase.functions.invoke("upload-cloudinary", {
        body: formData,
      });

      if (error) throw error;

      const { url } = data;
      setEditItem((prev) => prev ? { ...prev, image_url: url } : prev);
    } catch (err) {
      console.error("Upload error:", err);
    } finally {
      setUploading(false);
    }
  };

  const deleteMenuItem = async (id: string) => {
    if (!confirm("Bạn có chắc muốn xóa bánh này khỏi menu?")) return;
    const { error } = await supabase.from("monthly_menu").delete().eq("id", id);
    if (!error) {
      setMenuItems((prev) => prev.filter((m) => m.id !== id));
    }
  };

  useEffect(() => {
    if (!authLoading && !roleLoading) {
      if (!user) navigate("/auth");
      else if (!isBaker && !isAdmin) navigate("/");
    }
  }, [user, isBaker, isAdmin, authLoading, roleLoading, navigate]);

  const fetchMenu = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("monthly_menu")
      .select("*")
      .order("display_order");
    if (!error && data) setMenuItems(data as MenuItem[]);
    setLoading(false);
  };

  const fetchOrders = async () => {
    const { data } = await supabase
      .from("orders")
      .select("*")
      .in("status", ["pending", "preparing"])
      .order("created_at", { ascending: false });
    if (data) setOrders(data);
  };

  useEffect(() => {
    if (isBaker || isAdmin) {
      fetchMenu();
      fetchOrders();
    }
  }, [isBaker, isAdmin]);

  const saveItem = async () => {
    if (!editItem) return;
    setSaving(true);
    try {
      if (editItem.id) {
        const { error } = await supabase
          .from("monthly_menu")
          .update({
            cookie_name: editItem.cookie_name,
            description: editItem.description,
            origin: editItem.origin,
            price: editItem.price,
            image_url: editItem.image_url,
            stock: editItem.stock,
            month_year: editItem.month_year,
            display_order: editItem.display_order,
            is_active: editItem.is_active,
          } as any)
          .eq("id", editItem.id);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from("monthly_menu")
          .insert({
            cookie_name: editItem.cookie_name || "Cookie mới",
            description: editItem.description || "",
            origin: editItem.origin || "",
            price: editItem.price || 25000,
            image_url: editItem.image_url || null,
            stock: editItem.stock || 50,
            month_year: editItem.month_year || CURRENT_MONTH,
            display_order: editItem.display_order || menuItems.length,
            is_active: editItem.is_active ?? true,
          } as any);
        if (error) throw error;
      }
      setEditItem(null);
      fetchMenu();
    } catch (err) {
      console.error(err);
    } finally {
      setSaving(false);
    }
  };

  const updateStock = async (id: string, newStock: number) => {
    await supabase.from("monthly_menu").update({ stock: Math.max(0, newStock) }).eq("id", id);
    setMenuItems((prev) => prev.map((m) => m.id === id ? { ...m, stock: Math.max(0, newStock) } : m));
  };

  const updateOrderStatus = async (orderId: string, status: string) => {
    await supabase.from("orders").update({ status }).eq("id", orderId);
    fetchOrders();
  };

  if (authLoading || roleLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <>
      {cropSrc && (
        <ImageCropper
          imageSrc={cropSrc}
          onCropDone={handleCroppedImage}
          onCancel={() => setCropSrc(null)}
          aspect={1}
        />
      )}
      <SidebarProvider>
      <div className="flex min-h-screen w-full bg-background">
        <Sidebar className="w-60 border-r border-border" collapsible="icon">
          <SidebarContent className="pt-4">
            <div className="mb-6 px-4">
              <h2 className="font-display text-lg font-extrabold text-foreground">Baker</h2>
              <p className="text-xs text-muted-foreground">Nova Cookie</p>
            </div>
            <SidebarGroup>
              <SidebarGroupLabel>Quản lý</SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  <SidebarMenuItem>
                    <SidebarMenuButton
                      onClick={() => setTab("menu")}
                      className={`cursor-pointer ${tab === "menu" ? "bg-primary/10 text-primary font-medium" : ""}`}
                    >
                      <Cookie className="mr-2 h-4 w-4" />
                      <span>Menu & Kho</span>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                  <SidebarMenuItem>
                    <SidebarMenuButton
                      onClick={() => setTab("orders")}
                      className={`cursor-pointer ${tab === "orders" ? "bg-primary/10 text-primary font-medium" : ""}`}
                    >
                      <Package className="mr-2 h-4 w-4" />
                      <span>Đơn cần làm</span>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
            <div className="mt-auto px-4 py-4">
              <button onClick={() => navigate("/")} className="text-xs text-muted-foreground hover:text-foreground">
                ← Về trang chủ
              </button>
            </div>
          </SidebarContent>
        </Sidebar>

        <main className="flex-1 p-6 md:p-8">
          <div className="mb-6 flex items-center gap-3">
            <SidebarTrigger />
            <h1 className="font-display text-2xl font-extrabold text-foreground">
              {tab === "menu" ? "Menu & Kho bánh" : "Đơn cần làm"}
            </h1>
          </div>

          {/* Menu Tab */}
          {tab === "menu" && (
            <div className="space-y-4">
              <button
                onClick={() => setEditItem({ month_year: CURRENT_MONTH, price: 25000, stock: 50, is_active: true, display_order: menuItems.length })}
                className="flex items-center gap-2 rounded-full bg-primary px-5 py-2.5 text-sm font-bold text-primary-foreground hover:scale-105 transition-transform"
              >
                <Plus className="h-4 w-4" /> Thêm bánh mới
              </button>

              {/* Edit Modal */}
              {editItem && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="rounded-2xl border border-primary/20 bg-card p-6"
                >
                  <div className="mb-4 flex items-center justify-between">
                    <h3 className="font-display text-lg font-bold">{editItem.id ? "Sửa bánh" : "Thêm bánh mới"}</h3>
                    <button onClick={() => setEditItem(null)}><X className="h-5 w-5 text-muted-foreground" /></button>
                  </div>
                  <div className="grid gap-4 sm:grid-cols-2">
                    {[
                      { key: "cookie_name", label: "Tên bánh", type: "text" },
                      { key: "origin", label: "Xuất xứ", type: "text" },
                      { key: "price", label: "Giá bán (VNĐ)", type: "number" },
                      { key: "stock", label: "Số lượng", type: "number" },
                      { key: "month_year", label: "Tháng (MM/YYYY)", type: "text", placeholder: "03/2026" },
                    ].map((f) => (
                      <div key={f.key}>
                        <label className="mb-1 block text-xs font-semibold text-muted-foreground">{f.label}</label>
                        <input
                          type={f.type}
                          value={(editItem as any)[f.key] ?? ""}
                          placeholder={(f as any).placeholder}
                          onChange={(e) => setEditItem({ ...editItem, [f.key]: f.type === "number" ? Number(e.target.value) : e.target.value })}
                          className="w-full rounded-xl border border-border bg-background px-3 py-2 text-sm outline-none focus:border-primary"
                        />
                      </div>
                    ))}
                    {/* Image Upload with Drag & Drop */}
                    <div className="sm:col-span-2">
                      <label className="mb-1 block text-xs font-semibold text-muted-foreground">Ảnh bánh (chọn vùng crop trước khi upload)</label>
                      <div
                        onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
                        onDragLeave={() => setDragging(false)}
                        onDrop={(e) => {
                          e.preventDefault();
                          setDragging(false);
                          const file = e.dataTransfer.files?.[0];
                          if (file) startCrop(file);
                        }}
                        className={`flex items-center gap-4 rounded-2xl border-2 border-dashed p-4 transition-colors ${
                          dragging ? "border-primary bg-primary/5" : "border-border"
                        }`}
                      >
                        {editItem.image_url ? (
                          <img src={editItem.image_url} alt="Preview" className="h-20 w-20 rounded-xl object-cover border border-border" />
                        ) : (
                          <div className="flex h-20 w-20 items-center justify-center rounded-xl bg-muted text-2xl">🍪</div>
                        )}
                        <div className="flex flex-1 flex-col items-center gap-2 text-center">
                          <Upload className={`h-6 w-6 ${dragging ? "text-primary" : "text-muted-foreground"}`} />
                          <p className="text-xs text-muted-foreground">
                            {dragging ? "Thả ảnh vào đây!" : "Kéo thả ảnh vào đây hoặc"}
                          </p>
                          <input
                            ref={fileInputRef}
                            type="file"
                            accept="image/*"
                            className="hidden"
                            onChange={(e) => {
                              const file = e.target.files?.[0];
                              if (file) startCrop(file);
                            }}
                          />
                          <button
                            type="button"
                            onClick={() => fileInputRef.current?.click()}
                            disabled={uploading}
                            className="flex items-center gap-2 rounded-xl border border-border bg-background px-4 py-2 text-sm font-medium hover:bg-muted transition-colors"
                          >
                            {uploading ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
                            {uploading ? "Đang tải..." : "Chọn ảnh"}
                          </button>
                        </div>
                      </div>
                      {editItem.image_url && (
                        <button
                          type="button"
                          onClick={() => setEditItem({ ...editItem, image_url: null })}
                          className="mt-1 text-xs text-destructive hover:underline"
                        >
                          Xóa ảnh
                        </button>
                      )}
                    </div>
                    <div className="sm:col-span-2">
                      <label className="mb-1 block text-xs font-semibold text-muted-foreground">Mô tả</label>
                      <textarea
                        value={editItem.description ?? ""}
                        onChange={(e) => setEditItem({ ...editItem, description: e.target.value })}
                        rows={2}
                        className="w-full rounded-xl border border-border bg-background px-3 py-2 text-sm outline-none focus:border-primary"
                      />
                    </div>
                    <div className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={editItem.is_active ?? true}
                        onChange={(e) => setEditItem({ ...editItem, is_active: e.target.checked })}
                        className="rounded"
                      />
                      <label className="text-sm text-foreground">Đang bán</label>
                    </div>
                  </div>
                  <button
                    onClick={saveItem}
                    disabled={saving}
                    className="mt-4 flex items-center gap-2 rounded-full bg-primary px-6 py-2.5 text-sm font-bold text-primary-foreground"
                  >
                    {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                    Lưu
                  </button>
                </motion.div>
              )}

              {loading ? (
                <div className="flex justify-center py-20"><Loader2 className="h-6 w-6 animate-spin text-primary" /></div>
              ) : (
                <div className="space-y-3">
                  {menuItems.map((item) => (
                    <div key={item.id} className="flex items-center gap-4 rounded-2xl border border-border bg-card p-4">
                      {item.image_url ? (
                        <img src={item.image_url} alt={item.cookie_name} className="h-16 w-16 rounded-xl object-cover" />
                      ) : (
                        <div className="flex h-16 w-16 items-center justify-center rounded-xl bg-muted text-2xl">🍪</div>
                      )}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <h3 className="font-display font-bold text-foreground">{item.cookie_name}</h3>
                          {!item.is_active && <span className="rounded bg-muted px-2 py-0.5 text-xs text-muted-foreground">Ẩn</span>}
                        </div>
                        <p className="text-xs text-muted-foreground">{item.origin} · {item.month_year}</p>
                        <p className="font-bold text-primary">{formatPrice(item.price)}</p>
                      </div>
                      {/* Stock control */}
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => updateStock(item.id, item.stock - 1)}
                          className="rounded-full border border-border p-1 hover:bg-muted"
                        >
                          <span className="block h-4 w-4 text-center text-sm leading-4">−</span>
                        </button>
                        <span className={`w-10 text-center font-bold ${item.stock <= 5 ? "text-destructive" : "text-foreground"}`}>
                          {item.stock}
                        </span>
                        <button
                          onClick={() => updateStock(item.id, item.stock + 1)}
                          className="rounded-full border border-border p-1 hover:bg-muted"
                        >
                          <span className="block h-4 w-4 text-center text-sm leading-4">+</span>
                        </button>
                      </div>
                      <button
                        onClick={() => setEditItem(item)}
                        className="rounded-lg p-2 text-muted-foreground hover:bg-muted hover:text-foreground"
                      >
                        <Pencil className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => deleteMenuItem(item.id)}
                        className="rounded-lg p-2 text-muted-foreground hover:bg-destructive/10 hover:text-destructive"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Orders Tab */}
          {tab === "orders" && (
            <div className="space-y-3">
              {orders.length === 0 ? (
                <div className="rounded-2xl border border-border bg-card p-10 text-center text-muted-foreground">
                  Không có đơn cần xử lý 🎉
                </div>
              ) : (
                orders.map((order) => {
                  const status = STATUS_MAP[order.status] || STATUS_MAP.pending;
                  const StatusIcon = status.icon;
                  return (
                    <div key={order.id} className="rounded-2xl border border-border bg-card p-4">
                      <div className="flex items-center justify-between mb-2">
                        <div>
                          <span className="font-mono text-sm font-bold">{order.order_code}</span>
                          <span className={`ml-2 inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-semibold ${status.color}`}>
                            <StatusIcon className="h-3 w-3" />{status.label}
                          </span>
                        </div>
                        <span className="font-bold text-primary">{formatPrice(order.total)}</span>
                      </div>
                      <p className="text-sm text-muted-foreground">{order.customer_name} · {order.phone}</p>
                      <div className="mt-3 flex gap-2">
                        {order.status === "pending" && (
                          <button
                            onClick={() => updateOrderStatus(order.id, "preparing")}
                            className="rounded-full bg-secondary px-4 py-1.5 text-xs font-bold text-secondary-foreground"
                          >
                            Bắt đầu làm
                          </button>
                        )}
                        {order.status === "preparing" && (
                          <button
                            onClick={() => updateOrderStatus(order.id, "delivering")}
                            className="rounded-full bg-primary px-4 py-1.5 text-xs font-bold text-primary-foreground"
                          >
                            Giao hàng
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          )}
        </main>
      </div>
    </SidebarProvider>
    </>
  );
};

export default BakerDashboard;
