# Supabase Maintenance Scripts

Thư mục này chứa các kịch bản SQL (SQL Scripts) dùng để bảo trì, sửa lỗi và thiết lập lại cơ sở dữ liệu trên Supabase SQL Editor. Các file này được thiết kế để chạy thủ công khi có sự cố về phân quyền (RLS), triggers hoặc lỗi hệ thống.

## Danh sách các file quan trọng

1. **`master_rls_policies.sql`** (⭐ Khuyên dùng)
   - **Tác dụng:** Đây là file "Master". Nó sẽ xóa sạch mọi Policy cũ rác và xây dựng lại từ đầu hệ thống ma trận quyền (Role Matrix) cho toàn bộ ứng dụng (Guest, User, Baker, Admin). Giải quyết 99% các lỗi "Permission Denied" hoặc "403 Forbidden" mà vẫn đảm bảo bảo mật tuyệt đối (chống rò rỉ dữ liệu).

2. **`auto_confirm_users.sql`**
   - **Tác dụng:** Chứa trigger tự động xác nhận email (`email_confirmed_at = now()`) khi có người dùng mới đăng ký. Dùng để khắc phục lỗi "Email not confirmed" khi dự án sử dụng hệ thống gửi mã OTP tùy chỉnh thay vì link mặc định của Supabase.

3. **`fix_constraint_verification_codes.sql`**
   - **Tác dụng:** Dùng để sửa lỗi 500 khi đăng ký do Postgres Check Constraint cũ chặn type `signup_verify`.

4. **`drop_auth_trigger_completely.sql`**
   - **Tác dụng:** Giải pháp tối hậu cho lỗi "Database error saving new user". Script này sẽ xóa hoàn toàn trigger tạo Profile của DB, nhường việc tạo Profile lại cho phía Frontend xử lý an toàn hơn.

*(Các file nuke/fix rời rạc khác được giữ lại làm tài liệu tham khảo hoặc dùng khi cần sửa lỗi cục bộ).*
